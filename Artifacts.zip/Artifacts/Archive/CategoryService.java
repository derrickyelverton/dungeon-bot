package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Card;
import com.saturnnight.dungeonbot.jpa.Category;
import com.saturnnight.dungeonbot.repository.CategoryRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class CategoryService {

	@Autowired
	CategoryRepository categoryRepository;
	
	public Category findById(final Long id) {
		return categoryRepository.findOne(id);
	}

	public Page<Category> findAll(final String sort, final int offset, final int count) {
		return categoryRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Category save(Category category) {
		return categoryRepository.save(category);
	}

	public void delete(long id) {
		categoryRepository.delete(id);
	}	
	
		
}
