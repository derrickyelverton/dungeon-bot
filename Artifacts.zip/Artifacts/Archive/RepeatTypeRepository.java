package com.saturnnight.dungeonbot.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.saturnnight.dungeonbot.jpa.RepeatType;

@Repository
public interface RepeatTypeRepository extends JpaRepository<RepeatType, Long> {
	
    public Page<RepeatType> findAll(Pageable page);
    
}
