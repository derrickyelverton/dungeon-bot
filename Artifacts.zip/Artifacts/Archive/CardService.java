package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Canvas;
import com.saturnnight.dungeonbot.jpa.Card;
import com.saturnnight.dungeonbot.repository.CardRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class CardService {

	@Autowired
	CardRepository cardRepository;
	
	public Card findById(final long id) {
		return cardRepository.findOne(id);
	}

	public Page<Card> findAll(final String sort, final int offset, final int count) {
		return cardRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Card save(Card card) {
		return cardRepository.save(card);
	}

	public void delete(long id) {
		cardRepository.delete(id);
	}	
	
		
}
