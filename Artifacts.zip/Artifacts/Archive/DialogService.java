package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Dialog;
import com.saturnnight.dungeonbot.repository.DialogRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class DialogService {

	@Autowired
	DialogRepository dialogRepository;
	
	public Dialog findById(final Long id) {
		return dialogRepository.findOne(id);
	}

	public Page<Dialog> findAll(final String sort, final int offset, final int count) {
		return dialogRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Dialog save(Dialog dialog) {
		return dialogRepository.save(dialog);
	}

	public void delete(long id) {
		dialogRepository.delete(id);
	}	
	
		
}
