package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Canvas;
import com.saturnnight.dungeonbot.service.CanvasService;

@RestController
@RequestMapping(value = "/canvass")
@PreAuthorize("isAuthenticated()")
public class CanvasController {

	@Autowired
	CanvasService canvasService;

	@RequestMapping(method = RequestMethod.POST)
	public Canvas createCanvas(@RequestBody Canvas canvas) {
		return canvasService.save(canvas);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Canvas updateCanvas(@PathVariable("id") String id, @RequestBody Canvas canvas) {
		return canvasService.save(canvas);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteCanvas(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			canvasService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete canvas.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete canvas.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Canvas getCanvas(@PathVariable("id") long id) {
		return this.canvasService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Canvas> getCanvass( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Canvas> canvassPageList = canvasService.findAll(sort, offset, count);
		return canvassPageList;
	}

}
