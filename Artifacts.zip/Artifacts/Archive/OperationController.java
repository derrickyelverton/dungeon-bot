package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Operation;
import com.saturnnight.dungeonbot.service.OperationService;

@RestController
@RequestMapping(value = "/operations")
@PreAuthorize("isAuthenticated()")
public class OperationController {

	@Autowired
	OperationService operationService;

	@RequestMapping(method = RequestMethod.POST)
	public Operation createOperation(@RequestBody Operation operation) {
		return operationService.save(operation);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Operation updateOperation(@PathVariable("id") String id, @RequestBody Operation operation) {
		return operationService.save(operation);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteOperation(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			operationService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete operation.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete operation.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Operation getOperation(@PathVariable("id") long id) {
		return this.operationService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Operation> getOperations( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Operation> operationsPageList = operationService.findAll(sort, offset, count);
		return operationsPageList;
	}

}
