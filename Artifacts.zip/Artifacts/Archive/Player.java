package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PLAYER")
public class Player implements Serializable {

	private static final long serialVersionUID = 2438784504500093485L;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "PLAYER_DECK")
	private List<Deck> decks;

	@Column(name = "DESCRIPTION")
	private String description;

	@Id
	@Column(name = "ID")
	private Long id;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "IMAGE_ID")
	private Image image;

	@Column(name = "NAME")
	private String name;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "POSITION_ID", nullable = true)
	private Position position;

	@Column(name = "TITLE")
	private String title;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "USER_ID")
	private User user;

	public Date getCreatedOn() {
		return createdOn;
	}

	public List<Deck> getDecks() {
		return decks;
	}

	public String getDescription() {
		return description;
	}

	public Long getId() {
		return id;
	}

	public Image getImage() {
		return image;
	}		

	public String getName() {
		return name;
	}			
	
	public Position getPosition() {
		return position;
	}

	public String getTitle() {
		return title;
	}

	public User getUser() {
		return user;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setDecks(List<Deck> decks) {
		this.decks = decks;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
}
