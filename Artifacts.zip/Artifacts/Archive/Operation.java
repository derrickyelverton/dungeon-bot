package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OPERATION")
public class Operation implements Serializable {
	
	private static final long serialVersionUID = 2217500310601819937L;

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "IS_ACTIVE")
	private boolean isActive;

	@Column(name = "VERSION")
	private String version;

	@Column(name = "VALUE")
	private String value;
	
	@Column(name = "NAME")
	private String name;
	
	@Column(name = "Operation")
	private String operation;
	
	@Column(name = "Sign")
	private String sign;
}
