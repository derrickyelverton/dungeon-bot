package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Attribute;
import com.saturnnight.dungeonbot.repository.AttributeRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class AttributeService {

	@Autowired
	AttributeRepository attributeRepository;
	
	public Attribute findById(final Long id) {
		return attributeRepository.findOne(id);
	}

	public Page<Attribute> findAll(final String sort, final int offset, final int count) {
		return attributeRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Attribute save(Attribute attribute) {
		return attributeRepository.save(attribute);
	}

	public void delete(Long id) {
		attributeRepository.delete(id);
	}	
	
		
}
