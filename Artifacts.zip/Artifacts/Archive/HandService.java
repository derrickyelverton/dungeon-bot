package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Hand;
import com.saturnnight.dungeonbot.repository.HandRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class HandService {

	@Autowired
	HandRepository handRepository;
	
	public Hand findById(final long id) {
		return handRepository.findOne(id);
	}

	public Page<Hand> findAll(final String sort, final int offset, final int count) {
		return handRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Hand save(Hand hand) {
		return handRepository.save(hand);
	}

	public void delete(long id) {
		handRepository.delete(id);
	}
		
}
