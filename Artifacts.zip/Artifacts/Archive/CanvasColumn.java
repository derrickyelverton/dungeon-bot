package com.saturnnight.cardgame.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CANVAS_COLUMN")
public class CanvasColumn implements Serializable {

	private static final long serialVersionUID = 3708972179424384736L;

	@Id
	@Column(name = "COLUMN_ID")
	private Long id;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "COLUMN_SCENES_ID")
	private List<Scene> scenes;

	public Long getId() {
		return id;
	}

	public List<Scene> getScenes() {
		return scenes;
	}


	public void setId(Long id) {
		this.id = id;
	}

	public void setScenes(List<Scene> scenes) {
		this.scenes = scenes;
	}
	
}
