package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Profile;
import com.saturnnight.dungeonbot.repository.ProfileRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class ProfileService {

	@Autowired
	ProfileRepository profileRepository;
	
	public Profile findById(final long id) {
		return profileRepository.findOne(id);
	}

	public Page<Profile> findAll(final String sort, final int offset, final int count) {
		return profileRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Profile save(Profile profile) {
		return profileRepository.save(profile);
	}

	public void delete(long id) {
		profileRepository.delete(id);
	}	
	
		
}
