package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Operation;
import com.saturnnight.dungeonbot.repository.OperationRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class OperationService {

	@Autowired
	OperationRepository operationRepository;
	
	public Operation findById(final long id) {
		return operationRepository.findOne(id);
	}

	public Page<Operation> findAll(final String sort, final int offset, final int count) {
		return operationRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Operation save(Operation operation) {
		return operationRepository.save(operation);
	}

	public void delete(long id) {
		operationRepository.delete(id);
	}	
	
		
}
