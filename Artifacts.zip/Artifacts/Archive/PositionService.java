package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Position;
import com.saturnnight.dungeonbot.repository.PositionRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class PositionService {

	@Autowired
	PositionRepository positionRepository;
	
	public Position findById(final long id) {
		return positionRepository.findOne(id);
	}

	public Page<Position> findAll(final String sort, final int offset, final int count) {
		return positionRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Position save(Position position) {
		return positionRepository.save(position);
	}

	public void delete(long id) {
		positionRepository.delete(id);
	}	
	
		
}
