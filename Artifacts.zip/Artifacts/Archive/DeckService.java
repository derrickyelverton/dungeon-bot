package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.repository.DeckRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class DeckService {

	@Autowired
	DeckRepository deckRepository;
	
	public Deck findById(final long id) {
		return deckRepository.findOne(id);
	}

	public Page<Deck> findAll(final String sort, final int offset, final int count) {
		return deckRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Deck save(Deck deck) {
		return deckRepository.save(deck);
	}

	public void delete(long id) {
		deckRepository.delete(id);
	}	
	
		
}
