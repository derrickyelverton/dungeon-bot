package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EVENT_TYPE")
public class EventType implements Serializable {

	private static final long serialVersionUID = 1878000155868285071L;

	@Column(name = "ABBREVIATION")
	private String abbreviation;

	@Column(name = "CATEGORY")
	private int category;

	@Column(name = "COLOR")
	private String color;

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "NAME")
	private String name;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "VALUE")
	private String value;
	
	public String getAbbreviation() {
		return abbreviation;
	}

	public int getCategory() {
		return category;
	}

	public String getColor() {
		return color;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
