var BATTLECHASERS = {};

BATTLECHASERS = {
		
    userLocation          : null,
    radiusMap             : [5, 10, 25, 50, 100],
    radius                : 10,
    geoCoder              : new google.maps.Geocoder(),
    markerCount           : 0,
    markerMap             : [],
    infoWindowList        : [],
  
    mapStyler             : [
        {
            "elementType": "geometry",
            "stylers": [
                { 
                    "visibility": "on" 
                }
            ]
        }
    ],
    
    init: function() {
    		BATTLECHASERS.getUserLocation();
    		BATTLECHASERS.initializeView();
    },
    
    lookupCall : function(url,header,handler) {
	    $.get({
            url: url, 
            headers: header,
            success: handler
        });        
    },
    
    initializeView : function() { 
		BATTLECHASERS.infoWindowList = [];

        document.getElementById('map').className = 'state';
        var container = document.getElementById('chasers');
        container.innerHTML = "";    

        if (BATTLECHASERS.radius == 10) {
            zoomTo =  11;
        }
        else if (BATTLECHASERS.radius == 25) {
            zoomTo =  10;
        }
        else if (BATTLECHASERS.radius == 50) {
            zoomTo =  9;
        }
        else if (BATTLECHASERS.radius == 100) {
        		zoomTo =  7;
        }

        BATTLECHASERS.userLocation = BATTLECHASERS.userLocation.coords;
		var userLatitudeLongitude = new google.maps.LatLng(BATTLECHASERS.userLocation.coords.latitude, BATTLECHASERS.userLocation.coords.longitude);    

        var myOptions = {           
            center: userLatitudeLongitude,
            minZoom: 3,
            maxZoom: 15,
            zoom: zoomTo,
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false
        };
        map = new google.maps.Map(document.getElementById("map"),myOptions);  

        infowindow = new google.maps.InfoWindow();
        marker = new google.maps.Marker({
          map: map,
          icon: '/google_mpas_lib/image/markericon.png'
          
        });

		if (BATTLECHASERS.place != null && BATTLECHASERS.place != undefined && BATTLECHASERS.place.geometry != undefined && BATTLECHASERS.place.geometry.viewport) {
              map.fitBounds(BATTLECHASERS.place.geometry.viewport);
        }

        //autocomplete = new google.maps.places.Autocomplete( (document.getElementById('zip-search-item')), { types: ['(cities)'], componentRestrictions: {country: "us"} } );
        //google.maps.event.addListener(autocomplete, 'place_changed', function() { BATTLECHASERS.onAutocompletePlaceChanged(); } );        
        //autocomplete.bindTo('bounds', map);
    },    
    
    getUserLocation: function() {
        if (navigator.geolocation) {
            // attempt to get users position from the browser
            navigator.geolocation.getCurrentPosition(LOCATIONFINDER.setUserLocation, LOCATIONFINDER.setUserLocationError);
        } 
        else {
            var container = document.getElementById('chasers');
            container.innerHTML = "Geolocation is not supported by this browser. Unable to obtain your latitude and longitude to find locations near you.  Please update your browser and enable location services for www.nemours.org for a better user experience.  Thank you!";
        }
    },
    
    setUserLocation: function(position) {
		BATTLECHASERS.userSharedGeoLocation = true;
        // location services are enabled in the browser
        // set the users location
		BATTLECHASERS.userLocation = position;
		BATTLECHASERS.reverseGeocoding(position.coords.latitude, position.coords.longitude);
    },    
    
    geolocateUserLocation: function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                var circle = new google.maps.Circle({
                    center: geolocation,
                    radius: position.coords.accuracy
                });
               autocomplete.setBounds(circle.getBounds());
           });
        }
    }, 
    
    setUserLocationError: function(error) {
        var container = document.getElementById('chasers');
        // if the user has not started interacting with the map display the location error message
        if (container.innerHTML == '') {
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    container.innerHTML = "Geolocation is supported by this browser; however, User denied the request for Geolocation."
                    break;
                case error.POSITION_UNAVAILABLE:
                    container.innerHTML = "Geolocation is supported by this browser; however, Location information is unavailable."
                    break;
                case error.TIMEOUT:
                    container.innerHTML = "Geolocation is supported by this browser; however, The request to get user location timed out."
                    break;
                case error.UNKNOWN_ERROR:
                    container.innerHTML = "Geolocation is supported by this browser; however, An unknown error occurred."
                    break;
            }        
        }
    },    
    
    setParameter: function(name,value) {
        if (window.history.pushState) {
           //prevents browser from storing history with each change:

           var url = window.location.href;
           if (url.indexOf(name)>0) {
               //replace value with new value
			   var paramValue = url.substring(url.indexOf(name+'='));
               if (paramValue.indexOf("&")>0) {
                   paramValue = paramValue.substring(0,paramValue.indexOf("&"));
                   url = url.replace(paramValue, name+'='+value);
               }
               else {
                   url = url.replace(paramValue, name+'='+value);
               }

               window.history.pushState('battlechasers', 'Saturn Night - Battle Chasers', url);
           }    
           else if (url.indexOf('?')>0) {
               window.history.pushState('battlechasers', 'Saturn Night - Battle Chasers', url+'&'+name+'='+value);
           }
           else {
               window.history.pushState('battlechasers', 'Saturn Night - Battle Chasers', url+'?'+name+'='+value);
           }
        }        
    },

    removeParameter: function(name) {
        if (window.history.pushState) {
           //prevents browser from storing history with each change:

           var url = window.location.href;
           if (url.indexOf(name)>0) {
               //replace value with new value
			   var paramValue = url.substring(url.indexOf(name+'='));
               if (paramValue.indexOf("&")>0) {
                   paramValue = paramValue.substring(0,paramValue.indexOf("&"));
                   url = url.replace(paramValue, '');
               }
               else {
                   url = url.replace(paramValue, '');
               }

               window.history.pushState('battlechasers', 'Saturn Night - Battle Chasers', url);
           }    
        }        
    },

    getParameterByName: function(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },    
    
    onAutocompletePlaceChanged: function() {
      	var place = autocomplete.getPlace();

        if (place != null && place != undefined && place.name != undefined && place.name.length == 5 && !isNaN(LOCATIONFINDER.place.name)) {
        	    BATTLECHASERS.lookupLatLong(place.name);
        }
        else if (place != null && place != undefined && place.formatted_address != undefined) {
            var locationSearchPosition = new google.maps.LatLng(place.geometry.location.lat(), place.geometry.location.lng());
			var state = place.formatted_address.split(', ')[1];
            //stateLookup(state);
        }
    },    
    
    lookupLatLong: function(placeName) {
    		BATTLECHASERS.geoCoder.geocode( { 'address': placeName }, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                var latLong = {};
                latLong.latitude  = eval(results[0].geometry.location.lat());
                latLong.longitude = eval(results[0].geometry.location.lng());
            }
            else {
                console.log("Unable to Find Location:" +location);
            }
        });
    },    
    
	createLatLng : function ( latitude, longitude ) {
	    return new google.maps.LatLng(latitude,longitude);
	},
	
	getLat : function(latLong) {
	    return latLong.lat();
	},
	
	getLong: function(latLong) {
		return latLong.lng();        
	},
	
    reverseGeocoding: function(lat, long) {
        var found = false;
        var shortName = '';
        var latlng = new google.maps.LatLng(lat, long);
        BATTLECHASERS.geoCoder.geocode({ 'latLng': latlng, 'region': 'US' }, function (results, status) {
            if (status == 'OK' && results && results.length > 0) {
                for (var r = 0;r < results.length; r ++) {
                    for (var c = 0; c < results[r].address_components.length; c ++) {
                        if (results[r].address_components[c].types[0] == 'administrative_area_level_1') {
                            shortName = results[r].address_components[c].short_name;
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        break;
                    }
                }
                if (found) {
                		BATTLECHASERS.initializeView();
                		//BATTLECHASERS.handleLookup(shortName);
                }
            }
        });
    },
	
	getDistance: function(lat, long, compareLat, compareLong) {
	    var d2r = 0.0174532925199433;
	    var dlong = (compareLong - long) * d2r;
	    var dlat = (compareLat - lat) * d2r;
	    var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
	    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
	    var d = 3956 * c; 
	    return d;        
	},

    getDistanceFromUser: function(compareLat, compareLong) {
        if (BATTLECHASERS.userLocation.lat) {
        		BATTLECHASERS.userLocation.latitude = eval(BATTLECHASERS.userLocation.lat());
        }
        if (BATTLECHASERS.userLocation.lng) {
        		BATTLECHASERS.userLocation.longitude = eval(BATTLECHASERS.userLocation.lng());
        }

        var d2r = 0.0174532925199433;
        var lat = (BATTLECHASERS.userLocation.latitude)?BATTLECHASERS.userLocation.latitude:BATTLECHASERS.userLocation.coords.latitude;
        var lng = (BATTLECHASERS.userLocation.longitude)?BATTLECHASERS.userLocation.longitude:BATTLECHASERS.userLocation.coords.longitude;
        var dlong = (compareLong - lng) * d2r;
        var dlat = (compareLat - lat) * d2r;
        var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        var d = 3956 * c; 
        return d;        
    },	
    
    createMapMarker : function(container, location) {
    		BATTLECHASERS.markerCount = BATTLECHASERS.markerCount + 1;

        var geoLoc = BATTLECHASERS.createLatLng(location.latitude,location.longitude);

        var infoWindow = new google.maps.InfoWindow({
          content: ''
        });

        BATTLECHASERS.createMarkerWithLabel(geoLoc, 'mapLocationLabel', location.title, BATTLECHASERS.markerCount, null, infoWindow, location.type );
        BATTLECHASERS.markerMap.push(BATTLECHASERS.markerCount, location);
        
    },
    
    createMarkerWithLabel : function(latLng, labelClass, title, content, funct, infoWindow, locationType) {
       
    	    var labelStyling = {opacity: 0.75};
        var zIndex = BATTLECHASERS.markerCount;
        if (!isNaN(content)) {
            var zIndex = content*5;
            labelStyling['z-index'] = zIndex;
        }

        var newmarker = new MarkerWithLabel({
            position: latLng,
            map: map,
            labelContent: content,
            labelClass: labelClass,
            labelAnchor: new google.maps.Point(22,0),
            labelStyle: labelStyling,
            labelInBackground: false
        });
        
        newmarker.setZIndex(zIndex);
      	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-location-list-white-pin.png');
    
        if (funct) {
            google.maps.event.addListener(newmarker, 'click', funct);
        }
        else if (infoWindow) {
            newmarker.addListener('click', function() {
              for (var w=0;w<BATTLECHASERS.infoWindowList.length;w++) {
            	  	  BATTLECHASERS.infoWindowList[w].close();
              }
              infoWindow.open(map, newmarker);
            });
            BATTLECHASERS.infoWindowList.push(infoWindow);
        }
    },    
    
    convertToMarkerWithLabel: function(location, title, content, funct) {
        try {
        		BATTLECHASERS.geoCoder.geocode( { 'address': location }, function (results, status) {
                try {
                    if (status == google.maps.GeocoderStatus.OK) {
                        BATTLECHASERS.createMarkerWithLabel(results[0].geometry.location, 'mapLocationLabel', title, content, funct, null, null);
                    }
                    else {
                        console.log("Unable to Find Location:" +location);
                    }
                }
                catch (Exception) {
                }
            });
        }
        catch (Exception) {
        }
    },

    bubbleSort: function(array) {
  		var swapped;
  		do {
    		swapped = false;
    		for(var i = 0; i < array.length; i++) {
	            if(array[i] && array[i + 1] && array[i] > array[i + 1]) {
			        swap(array, i, i + 1);
        			swapped = true;
     			 }
		    }
  		} while(swapped);
  		return array;
	},
	
    sortLocationsByDistance: function(chasersList) {
        if (chasersList.length > 1) {
			var swapped;
            do {
                swapped = false;
                for (var i=0; i < chasersList.length-1; i++) {
                    var distanceFromUser = BATTLECHASERS.getDistanceFromUser(chasersList[i].locationLatitude, chasersList[i].locationLongitude);
                    chasersList[i].distanceFromUser = distanceFromUser;
                    if (distanceFromUser > BATTLECHASERS.getDistanceFromUser(chasersList[i+1].locationLatitude,chasersList[i+1].locationLongitude)) {
                        var temp = chasersList[i];
                        chasersList[i] = chasersList[i+1];
                        chasersList[i+1] = temp;
                        swapped = true;
                    }
                }
            } while (swapped);
            var distanceFromUser = BATTLECHASERS.getDistanceFromUser(chasersList[chasersList.length-1].locationLatitude, chasersList[chasersList.length-1].locationLongitude);
            chasersList[chasersList.length-1].distanceFromUser = distanceFromUser;

        }
        else {
            if (chasersList[0].locationLatitude && chasersList[0].locationLongitude) {
              var distanceFromUser = LOCATIONFINDER.getDistanceFromUser(chasersList[0].locationLatitude, chasersList[0].locationLongitude);
              chasersList[0].distanceFromUser = distanceFromUser;
            }
            else {
              chasersList[0].distanceFromUser = 1;
            }
        }
        return chasersList;
    }	
    
};



      var map;
      var marker;
      var markerCluster;
      var markers;
      var infoWindow;
      var marker2;
      var infoWindow2;
      var geocoder;
      var infoWindow3;
      var infoWindow4;
      
      var elevator;
      
      var directionsService;
      var directionsDisplay;
      
      var control;
      
      var infoWindow5;
      var service;
      
      // The location of Uluru
      var uluru = {lat: -25.344, lng: 131.036};

      var SYDNEY = {lat: -33.8798, lng: 151.2089};
      var OPERA_HOUSE = {lat: -33.8570, lng: 151.2150};

      
      // Create an array of alphabetical characters used to label the markers.
      var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      
      
      var locations = [
          {lat: -31.563910, lng: 147.154312},
          {lat: -33.718234, lng: 150.363181},
          {lat: -33.727111, lng: 150.371124},
          {lat: -33.848588, lng: 151.209834},
          {lat: -33.851702, lng: 151.216968},
          {lat: -34.671264, lng: 150.863657},
          {lat: -35.304724, lng: 148.662905},
          {lat: -36.817685, lng: 175.699196},
          {lat: -36.828611, lng: 175.790222},
          {lat: -37.750000, lng: 145.116667},
          {lat: -37.759859, lng: 145.128708},
          {lat: -37.765015, lng: 145.133858},
          {lat: -37.770104, lng: 145.143299},
          {lat: -37.773700, lng: 145.145187},
          {lat: -37.774785, lng: 145.137978},
          {lat: -37.819616, lng: 144.968119},
          {lat: -38.330766, lng: 144.695692},
          {lat: -39.927193, lng: 175.053218},
          {lat: -41.330162, lng: 174.865694},
          {lat: -42.734358, lng: 147.439506},
          {lat: -42.734358, lng: 147.501315},
          {lat: -42.735258, lng: 147.438000},
          {lat: -43.999792, lng: 170.463352}
        ];
      
      
      var initMap = function() {
    	  
        geocoder = new google.maps.Geocoder();
    	  
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          zoom: 8
        });

        infoWindow = new google.maps.InfoWindow;
        infoWindow2 = new google.maps.InfoWindow;
        infoWindow3 = new google.maps.InfoWindow;
        infoWindow4 = new google.maps.InfoWindow;
        
        directionsService = new google.maps.DirectionsService;
        directionsDisplay = new google.maps.DirectionsRenderer;
        
        document.getElementById('submit').addEventListener('click', function() {
            geocodeAddress(geocoder, map);
        });
        
        document.getElementById('submit2').addEventListener('click', function() {
            geocodeLatLng(geocoder, map, infoWindow3);
         });
       

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };

            infoWindow.setPosition(pos);
            infoWindow.setContent('Location found.');
            infoWindow.open(map);
            map.setCenter(pos);
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
        
        
        marker = new google.maps.Marker({position: uluru, map: map});


        // Add some markers to the map.
        // Note: The code uses the JavaScript Array.prototype.map() method to
        // create an array of markers based on a given "locations" array.
        // The map() method here has nothing to do with the Google Maps API.
        markers = locations.map(function(location, i) {
          return new google.maps.Marker({
            position: location,
            label: labels[i % labels.length]
          });
        });


        // Add a marker clusterer to manage the markers.
        markerCluster = new MarkerClusterer(map, markers, {imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m'});
       
        
        // Create a <script> tag and set the USGS URL as the source.
        var script = document.createElement('script');
        // This example uses a local copy of the GeoJSON stored at
        // http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojsonp
        script.src = 'https://developers.google.com/maps/documentation/javascript/examples/json/earthquake_GeoJSONP.js';
        //script.src = 'http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojsonp';
        document.getElementsByTagName('head')[0].appendChild(script);
       
        

        map.data.setStyle(function(feature) {
          var magnitude = feature.getProperty('mag');
          return {
            icon: getCircle(magnitude)
          };
        });
        
        // Create a marker. Markers behave smoothly with the beta renderer.
        marker2 = new google.maps.Marker({position: OPERA_HOUSE, map: map});

        // Create info window content.
        var content = document.createElement('div');
        content.textContent = 'new renderer ';
        var zoomInButton = document.createElement('button');
        zoomInButton.textContent = 'zoom in';
        content.appendChild(zoomInButton);

        // Create open an info window attached to the marker.
        infoWindow2 = new google.maps.InfoWindow({content: content});
        infoWindow2.open(map, marker2);

        // When the zoom-in button is clicked, zoom in and pan to the Opera House.
        // The zoom and pan animations are smoother with the new renderer.
        zoomInButton.onclick = function() {
          map.setZoom(Math.max(15, map.getZoom() + 1));
          map.panTo(OPERA_HOUSE);
        };
        
        directionsDisplay.setMap(map);

        var onChangeHandler = function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
        };
        document.getElementById('start').addEventListener('change', onChangeHandler);
        document.getElementById('end').addEventListener('change', onChangeHandler);
         
        directionsDisplay.setMap(map);
        directionsDisplay.setPanel(document.getElementById('right-panel'));

        control = document.getElementById('floating-panel');
        control.style.display = 'block';
        map.controls[google.maps.ControlPosition.TOP_CENTER].push(control);
        
        elevator = new google.maps.ElevationService;
                
        
        map.addListener('click', function(event) {
            displayLocationElevation(event.latLng, elevator, infoWindow4);
          });

        maxZoomService = new google.maps.MaxZoomService();

        infoWindow5 = new google.maps.InfoWindow();
        service = new google.maps.places.PlacesService(map);
        service.nearbySearch({
          location: pyrmont,
          radius: 500,
          type: ['store']
        }, callback);

      }; 
      
      function showMaxZoom(e) {
          maxZoomService.getMaxZoomAtLatLng(e.latLng, function(response) {
            if (response.status !== 'OK') {
              infoWindow.setContent('Error in MaxZoomService');
            } else {
              infoWindow.setContent(
                  'The maximum zoom at this location is: ' + response.zoom);
            }
            infoWindow.setPosition(e.latLng);
            infoWindow.open(map);
          });
        }

      
      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
          directionsService.route({
            origin: document.getElementById('start').value,
            destination: document.getElementById('end').value,
            travelMode: 'DRIVING'
          }, function(response, status) {
            if (status === 'OK') {
              directionsDisplay.setDirections(response);
            } else {
              window.alert('Directions request failed due to ' + status);
            }
          });
        }
      
      
      function getCircle(magnitude) {
          return {
            path: google.maps.SymbolPath.CIRCLE,
            fillColor: 'red',
            fillOpacity: .2,
            scale: Math.pow(2, magnitude) / 2,
            strokeColor: 'white',
            strokeWeight: .5
          };
        }

        function eqfeed_callback(results) {
          map.data.addGeoJson(results);
        }
      
      
      // Loop through the results array and place a marker for each
      // set of coordinates.
      window.eqfeed_callback = function(results) {
        for (var i = 0; i < results.features.length; i++) {
          var coords = results.features[i].geometry.coordinates;
          var latLng = new google.maps.LatLng(coords[1],coords[0]);
          var marker = new google.maps.Marker({
            position: latLng,
            map: map
          });
        }
      }
      

      function eqfeed_callback(results) {
        var heatmapData = [];
        for (var i = 0; i < results.features.length; i++) {
          var coords = results.features[i].geometry.coordinates;
          var latLng = new google.maps.LatLng(coords[1], coords[0]);
          heatmapData.push(latLng);
        }
        var heatmap = new google.maps.visualization.HeatmapLayer({
          data: heatmapData,
          dissipating: false,
          map: map
        });
      }
      
      function geocodeAddress(geocoder, resultsMap) {
          var address = document.getElementById('address').value;
          geocoder.geocode({'address': address}, function(results, status) {
            if (status === 'OK') {
              resultsMap.setCenter(results[0].geometry.location);
              var marker = new google.maps.Marker({
                map: resultsMap,
                position: results[0].geometry.location
              });
            } else {
              alert('Geocode was not successful for the following reason: ' + status);
            }
          });
        }

      /*  RESTRICTION 
      
      function geocodeAddress(geocoder, map) {
          geocoder.geocode({
            componentRestrictions: {
              country: 'AU',
              postalCode: '2000'
            }
          }, function(results, status) {
            if (status === 'OK') {
              map.setCenter(results[0].geometry.location);
              new google.maps.Marker({
                map: map,
                position: results[0].geometry.location
              });
            } else {
              window.alert('Geocode was not successful for the following reason: ' +
                  status);
            }
          });
        }
      */
      
      function geocodeLatLng(geocoder, map, infowindow) {
          var input = document.getElementById('latlng').value;
          var latlngStr = input.split(',', 2);
          var latlng = {lat: parseFloat(latlngStr[0]), lng: parseFloat(latlngStr[1])};
          geocoder.geocode({'location': latlng}, function(results, status) {
            if (status === 'OK') {
              if (results[0]) {
                map.setZoom(11);
                var marker = new google.maps.Marker({
                  position: latlng,
                  map: map
                });
                infoWindow3.setContent(results[0].formatted_address);
                infoWindow3.open(map, marker);
              } else {
                window.alert('No results found');
              }
            } else {
              window.alert('Geocoder failed due to: ' + status);
            }
          });
      }
      
      function displayLocationElevation(location, elevator, infowindow) {
          // Initiate the location request
          elevator.getElevationForLocations({
            'locations': [location]
          }, function(results, status) {
            infowindow.setPosition(location);
            if (status === 'OK') {
              // Retrieve the first result
              if (results[0]) {
                // Open the infowindow indicating the elevation at the clicked position.
                infowindow.setContent('The elevation at this point <br>is ' +
                    results[0].elevation + ' meters.');
              } else {
                infowindow.setContent('No results found');
              }
            } else {
              infowindow.setContent('Elevation service failed due to: ' + status);
            }
          });
        }
      
      function callback(results, status) {
          if (status === google.maps.places.PlacesServiceStatus.OK) {
            for (var i = 0; i < results.length; i++) {
              createMarker(results[i]);
            }
          }
        }

        function createMarker(place) {
          var placeLoc = place.geometry.location;
          var marker = new google.maps.Marker({
            map: map,
            position: place.geometry.location
          });

          google.maps.event.addListener(marker, 'click', function() {
            infowindow5.setContent(place.name);
            infowindow5.open(map, this);
          });

        }
        
      
     /*
      function eqfeed_callback(results) {
    	    var heatmapData = [];
    	    for (var i = 0; i &lt; results.features.length; i++) {
    	      var coords = results.features[i].geometry.coordinates;
    	      var latLng = new google.maps.LatLng(coords[1], coords[0]);
    	      var magnitude = results.features[i].properties.mag;
    	      var weightedLoc = {
    	        location: latLng,
    	        weight: Math.pow(2, magnitude)
    	      };
    	      heatmapData.push(weightedLoc);
    	    }
    	    var heatmap = new google.maps.visualization.HeatmapLayer({
    	      data: heatmapData,
    	      dissipating: false,
    	      map: map
    	    });
    	  }
*/
