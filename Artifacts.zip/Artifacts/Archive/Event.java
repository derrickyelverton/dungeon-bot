package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "EVENT")
@SequenceGenerator(name = "SEQ_EVENT_GENERATOR", sequenceName = "SEQ_EVENT", initialValue = 1, allocationSize = 1)
public class Event implements Serializable {

	private static final long serialVersionUID = -2714864730654819826L;

	@Temporal(TemporalType.DATE)	
	@Column(name = "EVENT_DATE")
	private Date date;

	@ManyToOne(optional = false)
	@JoinColumn(name = "EVENT_TYPE_ID")	
	private EventType eventType;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_EVENT_GENERATOR")
	@Column(name = "ID")
	private Long id;

	@OneToOne(optional = false)
	@JoinColumn(name = "PLAYER_ONE_ID")	
	private Player playerOne;

	@OneToOne(optional = false)
	@JoinColumn(name = "PLAYER_TWO_ID")	
	private Player playerTwo;

	@OneToOne(optional = false)
	@JoinColumn(name = "PLAYER_ONE_CARD_ID")	
	private Card playerOneCard;

	@OneToOne(optional = false)
	@JoinColumn(name = "PLAYER_TWO_CARD_ID")	
	private Card playerTwoCard;

	public Date getDate() {
		return date;
	}

	public EventType getEventType() {
		return eventType;
	}

	public Long getId() {
		return id;
	}

	public Player getPlayerOne() {
		return playerOne;
	}

	public Card getPlayerOneCard() {
		return playerOneCard;
	}

	public Player getPlayerTwo() {
		return playerTwo;
	}

	public Card getPlayerTwoCard() {
		return playerTwoCard;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	public void setEventType(EventType eventType) {
		this.eventType = eventType;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setPlayerOne(Player playerOne) {
		this.playerOne = playerOne;
	}

	public void setPlayerOneCard(Card playerOneCard) {
		this.playerOneCard = playerOneCard;
	}
	
	public void setPlayerTwo(Player playerTwo) {
		this.playerTwo = playerTwo;
	}

	public void setPlayerTwoCard(Card playerTwoCard) {
		this.playerTwoCard = playerTwoCard;
	}

	
	
}
