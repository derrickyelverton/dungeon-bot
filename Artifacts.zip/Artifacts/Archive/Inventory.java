package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "INVENTORY")
public class Inventory implements Serializable {
	
	private static final long serialVersionUID = 2789274131032744522L;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "BACKGROUND_ID")
	private Background background;
	
	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;	

	@Column(name = "GOLD")
	private Long gold;	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(name = "INVENTORY_ITEMS")
	private List<Sprite> items;
	
	public Background getBackground() {
		return background;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getGold() {
		return gold;
	}

	public Long getId() {
		return id;
	}

	public List<Sprite> getItems() {
		return items;
	}

	public void setBackground(Background background) {
		this.background = background;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setGold(Long gold) {
		this.gold = gold;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setItems(List<Sprite> items) {
		this.items = items;
	}

}
