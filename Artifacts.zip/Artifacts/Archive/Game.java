package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "GAME")
public class Game implements Serializable {

	private static final long serialVersionUID = -4180543192034806208L;

	@OneToOne(optional = false)
	@JoinColumn(name = "CANVAS_ID")	
	private Canvas canvas;

	@Column(name = "DESCRIPTION")
	private String description;
	
	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "NAME")
	private String name;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date startedOn;

	public Canvas getCanvas() {
		return canvas;
	}

	public String getDescription() {
		return description;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public Date getStartedOn() {
		return startedOn;
	}

	public void setCanvas(Canvas canvas) {
		this.canvas = canvas;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setStartedOn(Date startedOn) {
		this.startedOn = startedOn;
	}
	
}
