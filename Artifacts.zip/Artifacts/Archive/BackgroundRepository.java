package com.saturnnight.dungeonbot.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.saturnnight.dungeonbot.jpa.Background;

@Repository
public interface BackgroundRepository extends JpaRepository<Background, Long> {
	
    public Page<Background> findAll(Pageable page);
    
}
