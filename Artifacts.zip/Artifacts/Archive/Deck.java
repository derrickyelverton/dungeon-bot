package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "DECK")
public class Deck implements Serializable {

	private static final long serialVersionUID = -2987371679414590338L;

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "NAME")
	private boolean name;

	@Column(name = "DESCRIPTION")
	private boolean description;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PLAYER_ID")
	private Player player;

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "IMAGE_ID")
	private Image image;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "DECK_CARD")
	private List<Card> cards;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;
	
	public List<Card> getCards() {
		return cards;
	}		
	
	public Date getCreatedOn() {
		return createdOn;
	}		

	public Long getId() {
		return id;
	}		
	
	public Image getImage() {
		return image;
	}

	public Player getPlayer() {
		return player;
	}

	public boolean isDescription() {
		return description;
	}

	public boolean isName() {
		return name;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setDescription(boolean description) {
		this.description = description;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public void setName(boolean name) {
		this.name = name;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

}
