package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CANVAS")
public class Canvas implements Serializable {

	private static final long serialVersionUID = -4417161781735003145L;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_BACKGROUNDS")
	private List<Background> backgrounds;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_BADGUYS")
	private List<Sprite> badGuys;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;
		
	@Column(name = "MODE")
	private String gameMode;

	@Column(name = "NAME")
	private String gameName;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_HEATMAPS_BACKGROUND")
	private List<Background> heatMaps;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HERO")
	private Sprite hero;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_HEROS")
	private List<Sprite> heros;
	
	@Id
	@Column(name = "ID")
	private Long id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_ITEMS_SPRITE")
	private List<Sprite> items;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_ROWS")
	private List<Row> rows;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "CANVAS_STORES")
	private List<Store> stores;

	public List<Background> getBackgrounds() {
		return backgrounds;
	}

	public List<Sprite> getBadGuys() {
		return badGuys;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public String getGameMode() {
		return gameMode;
	}

	public String getGameName() {
		return gameName;
	}

	public List<Background> getHeatMaps() {
		return heatMaps;
	}

	public Sprite getHero() {
		return hero;
	}

	public List<Sprite> getHeros() {
		return heros;
	}

	public Long getId() {
		return id;
	}

	public List<Sprite> getItems() {
		return items;
	}

	public List<Row> getRows() {
		return rows;
	}

	public Date getStartedOn() {
		return createdOn;
	}

	public List<Store> getStores() {
		return stores;
	}

	public void setBackgrounds(List<Background> backgrounds) {
		this.backgrounds = backgrounds;
	}

	public void setBadGuys(List<Sprite> badGuys) {
		this.badGuys = badGuys;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setGameMode(String gameMode) {
		this.gameMode = gameMode;
	}
	
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	
	public void setHeatMaps(List<Background> heatMaps) {
		this.heatMaps = heatMaps;
	}
	
	public void setHero(Sprite hero) {
		this.hero = hero;
	}
	
	public void setHeros(List<Sprite> heros) {
		this.heros = heros;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setItems(List<Sprite> items) {
		this.items = items;
	}

	public void setRows(List<Row> rows) {
		this.rows = rows;
	}

	public void setStores(List<Store> stores) {
		this.stores = stores;
	}	
	
}
