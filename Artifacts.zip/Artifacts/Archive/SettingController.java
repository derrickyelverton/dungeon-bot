package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Setting;
import com.saturnnight.dungeonbot.service.SettingService;

@RestController
@RequestMapping(value = "/settings")
public class SettingController {

	@Autowired
	SettingService settingService;

	@RequestMapping(method = RequestMethod.POST)
	public Setting createSetting(@RequestBody Setting setting) {
		return settingService.save(setting);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Setting updateSetting(@PathVariable("id") String id, @RequestBody Setting setting) {
		return settingService.save(setting);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteSetting(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			settingService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete setting.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete setting.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Setting getSetting(@PathVariable("id") long id) {
		return settingService.findById(id);
	}


}
