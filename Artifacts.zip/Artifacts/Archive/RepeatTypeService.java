package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.RepeatType;
import com.saturnnight.dungeonbot.repository.RepeatTypeRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class RepeatTypeService {

	@Autowired
	RepeatTypeRepository repeatTypeRepository;

	public RepeatType findById(final long id) {
		return repeatTypeRepository.findOne(id);
	}

	public Page<RepeatType> findAll(final String sort, final int offset, final int count) {
		return repeatTypeRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}
	
	public RepeatType save(RepeatType repeatType) {
		return repeatTypeRepository.save(repeatType);
	}

	public void delete(long id) {
		repeatTypeRepository.delete(id);
	}	
		
}
