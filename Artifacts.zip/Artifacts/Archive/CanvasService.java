package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Canvas;
import com.saturnnight.dungeonbot.repository.CanvasRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class CanvasService {

	@Autowired
	CanvasRepository canvasRepository;
	
	public Canvas findById(final long id) {
		return canvasRepository.findOne(id);
	}

	public Page<Canvas> findAll(final String sort, final int offset, final int count) {
		return canvasRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Canvas save(Canvas card) {
		return canvasRepository.save(card);
	}

	public void delete(long id) {
		canvasRepository.delete(id);
	}	
	
		
}
