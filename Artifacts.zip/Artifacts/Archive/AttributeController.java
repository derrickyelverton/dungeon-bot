package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Attribute;
import com.saturnnight.dungeonbot.service.AttributeService;

@RestController
@RequestMapping(value = "/attributes")
@PreAuthorize("isAuthenticated()")
public class AttributeController {

	@Autowired
	AttributeService attributeService;

	@RequestMapping(method = RequestMethod.POST)
	public Attribute createAttribute(@RequestBody Attribute attribute) {
		return attributeService.save(attribute);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Attribute updateAttribute(@PathVariable("id") String id, @RequestBody Attribute attribute) {
		return attributeService.save(attribute);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteAttribute(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			attributeService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete attribute.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete attribute.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Attribute getAttribute(@PathVariable("id") long id) {
		return this.attributeService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Attribute> getAttributes( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Attribute> attributesPageList = attributeService.findAll(sort, offset, count);
		return attributesPageList;
	}

}
