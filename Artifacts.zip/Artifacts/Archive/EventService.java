package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Event;
import com.saturnnight.dungeonbot.repository.EventRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class EventService {

	@Autowired
	EventRepository eventRepository;
	
	public Event findById(final long id) {
		return eventRepository.findOne(id);
	}

	public Page<Event> findAll(final String sort, final int offset, final int count) {
		return eventRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Event save(Event event) {
		return eventRepository.save(event);
	}

	public void delete(long id) {
		eventRepository.delete(id);
	}	
	
		
}
