package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.EventType;
import com.saturnnight.dungeonbot.service.EventTypeService;

@RestController
@RequestMapping(value = "/eventtypes")
public class EventTypeController {

	@Autowired
	EventTypeService eventTypeService;

	@RequestMapping(method = RequestMethod.POST)
	public EventType createEventType(@RequestBody EventType eventType) {
		return eventTypeService.save(eventType);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public EventType updateEventType(@PathVariable("id") String id, @RequestBody EventType eventType) {
		return eventTypeService.save(eventType);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteEventType(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			eventTypeService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete eventType.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete eventType.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public EventType getEventType(@PathVariable("id") long id) {
		return eventTypeService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<EventType> getEventTypes( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<EventType> eventTypePageList = null;
		eventTypePageList = eventTypeService.findAll(sort, offset, count);
		return eventTypePageList;
	}

}
