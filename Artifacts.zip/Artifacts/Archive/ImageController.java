package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Image;
import com.saturnnight.dungeonbot.service.ImageService;

@RestController
@RequestMapping(value = "/images")
@PreAuthorize("isAuthenticated()")
public class ImageController {

	@Autowired
	ImageService imageService;

	@RequestMapping(method = RequestMethod.POST)
	public Image createImage(@RequestBody Image image) {
		return imageService.save(image);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Image updateImage(@PathVariable("id") String id, @RequestBody Image image) {
		return imageService.save(image);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteImage(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			imageService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete image.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete image.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Image getImage(@PathVariable("id") long id) {
		return this.imageService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Image> getImages( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Image> imagesPageList = imageService.findAll(sort, offset, count);
		return imagesPageList;
	}

}
