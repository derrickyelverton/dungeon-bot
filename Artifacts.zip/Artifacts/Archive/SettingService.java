package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Setting;
import com.saturnnight.dungeonbot.repository.SettingRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class SettingService {

	@Autowired
	SettingRepository settingRepository;

	public Setting findById(final long id) {
		return settingRepository.findOne(id);
	}

	public Page<Setting> findAll(final String sort, final int offset, final int count) {
		return settingRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Setting save(Setting setting) {
		return settingRepository.save(setting);
	}

	public void delete(long id) {
		settingRepository.delete(id);
	}	
		
}
