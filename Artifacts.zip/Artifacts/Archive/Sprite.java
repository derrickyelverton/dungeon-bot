package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SPRITE")
public class Sprite implements Serializable {

	private static final long serialVersionUID = -8908810621676882293L;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "DURATION")
	private Long duration;

	@Column(name = "TOTAL_EXPERIENCE")
	private Long totalExperience;
	
	@Column(name = "EXPERIENCE")
	private Long experience;

	@Column(name = "FRAMES")
	private Long frames;
	@Column(name = "GOLD")
	private Long gold;

	@Column(name = "HEALTH")
	private Long health;

	@Column(name = "HEALTH_OVERLAY_SHOWN")
	private boolean healthOverlayShown;
	
	@Column(name = "HEIGHT")
	private Long height;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "INVENTORY_ID")
	private Inventory inventory;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "POSITION_ID")
	private Position position;
		
	@Column(name = "IS_GOLD")
	private Long isGold;

	@Column(name = "LEVEL")
	private Long level;

	@Column(name = "NAME")
	private String name;

	@Column(name = "OFFSET_X")
	private Long offsetX;

	@Column(name = "OFFSET_Y")
	private Long offsetY;

	@Column(name = "SOURCE")
	private String source;

	@Column(name = "SPRITE_TYPE")
	private Long spriteType;

	@Column(name = "START_POSITION_X")
	private Long startPositionX;

	@Column(name = "START_POSITION_Y")
	private Long startPositionY;

	@Column(name = "START_POSITION_LATITUDE")
	private Long startPositionLatitude;

	@Column(name = "START_POSITION_LONGITUDE")
	private Long startPositionLongitude;

	@Column(name = "START_POSITION_ELEVATION")
	private Long startPositionElevation;

	@Column(name = "LATITUDE")
	private Long latitude;

	@Column(name = "LONGITUDE")
	private Long longitude;

	@Column(name = "ELEVATION")
	private Long elevation;

	@Column(name = "WIDTH")
	private Long width;

	public Date getCreatedOn() {
		return createdOn;
	}
	
	public Long getDuration() {
		return duration;
	}

	public Long getElevation() {
		return elevation;
	}

	public Long getExperience() {
		return experience;
	}

	public Long getFrames() {
		return frames;
	}

	public Long getGold() {
		return gold;
	}

	public Long getHealth() {
		return health;
	}

	public Long getHeight() {
		return height;
	}

	public Long getId() {
		return id;
	}

	public Inventory getInventory() {
		return inventory;
	}

	public Long getLatitude() {
		return latitude;
	}

	public Long getLevel() {
		return level;
	}

	public Long getLongitude() {
		return longitude;
	}
	public String getName() {
		return name;
	}

	public Long getOffsetX() {
		return offsetX;
	}

	public Long getOffsetY() {
		return offsetY;
	}

	public String getSource() {
		return source;
	}

	public Long getSpriteType() {
		return spriteType;
	}

	public Long getStartPositionElevation() {
		return startPositionElevation;
	}

	public Long getStartPositionLatitude() {
		return startPositionLatitude;
	}

	public Long getStartPositionLongitude() {
		return startPositionLongitude;
	}

	public Long getStartPositionX() {
		return startPositionX;
	}

	public Long getStartPositionY() {
		return startPositionY;
	}

	public Long getTotalExperience() {
		return totalExperience;
	}

	public Long getWidth() {
		return width;
	}

	public Long isGold() {
		return isGold;
	}

	public boolean isHealthOverlayShown() {
		return healthOverlayShown;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setDuration(Long duration) {
		this.duration = duration;
	}

	public void setElevation(Long elevation) {
		this.elevation = elevation;
	}

	public void setExperience(Long experience) {
		this.experience = experience;
	}

	public void setFrames(Long frames) {
		this.frames = frames;
	}

	public void setGold(Long gold) {
		this.gold = gold;
	}
	public void setHealth(Long health) {
		this.health = health;
	}

	public void setHealthOverlayShown(boolean healthOverlayShown) {
		this.healthOverlayShown = healthOverlayShown;
	}

	public void setHeight(Long height) {
		this.height = height;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}

	public void setIsGold(Long isGold) {
		this.isGold = isGold;
	}

	public void setLatitude(Long latitude) {
		this.latitude = latitude;
	}

	public void setLevel(Long level) {
		this.level = level;
	}
	
	public void setLongitude(Long longitude) {
		this.longitude = longitude;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOffsetX(Long offsetX) {
		this.offsetX = offsetX;
	}

	public void setOffsetY(Long offsetY) {
		this.offsetY = offsetY;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setSpriteType(Long spriteType) {
		this.spriteType = spriteType;
	}

	public void setStartPositionElevation(Long startPositionElevation) {
		this.startPositionElevation = startPositionElevation;
	}

	public void setStartPositionLatitude(Long startPositionLatitude) {
		this.startPositionLatitude = startPositionLatitude;
	}

	public void setStartPositionLongitude(Long startPositionLongitude) {
		this.startPositionLongitude = startPositionLongitude;
	}

	public void setStartPositionX(Long startPositionX) {
		this.startPositionX = startPositionX;
	}

	public void setStartPositionY(Long startPositionY) {
		this.startPositionY = startPositionY;
	}

	public void setTotalExperience(Long totalExperience) {
		this.totalExperience = totalExperience;
	}
	public void setWidth(Long width) {
		this.width = width;
	}	
	
}
