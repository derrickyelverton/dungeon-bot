var LOCATIONFINDER = {};

LOCATIONFINDER = {
    userSharedGeoLocation : false,
    locationSearchPosition: null,
    userSelectedDepartments: null,
    map                   : null,
    infowindow            : null,
    marker                : null,
    autocomplete          : null,
    //stateZip            : null,
    place                 : null,
    zipToSortBy           : null,
    zipToSortByLatLong    : null,
    distanceArray         : null,
    hits                  : null,
    geoCoder              : new google.maps.Geocoder(),
    markerMap             : [],
    markerCount           : 0,
    currentStateLookup    : null,
    userSelectedLocation  : null,
    currentState          : null,
    currentZoomLevel      : null,
    showAll               : true,
    showPrimaryCare       : false,
    showUrgentCare        : false,
    showSpecialtyCare     : false,
    showHospitalER        : false,
    showCollaborating     : false,
    infoWindowList        : [],
    radius                : 100,

    mapStyler             : [
        {
            "elementType": "geometry",
            "stylers": [
                { 
                    "visibility": "on" 
                }
            ]
        }
    ],

    init: function() {
		LOCATIONFINDER.showPrimaryCare = showPrimaryCare;
		LOCATIONFINDER.showUrgentCare = showUrgentCare;
		LOCATIONFINDER.showSpecialtyCare = showSpecialtyCare;
		LOCATIONFINDER.showHospitalER = showHospitalER;
		LOCATIONFINDER.showCollaborating = showCollaborating;
        if (!LOCATIONFINDER.showPrimaryCare && !LOCATIONFINDER.showUrgentCare && !LOCATIONFINDER.showSpecialtyCare && !LOCATIONFINDER.showHospitalER && !LOCATIONFINDER.showCollaborating) {
            LOCATIONFINDER.showAll = true;
        }
        else {
            LOCATIONFINDER.showAll = false;
        }

        //location search field
        var searchInputField = document.getElementById('zip-search-item');
        if (searchInputField != null && searchInputField.addEventListener) {
            searchInputField.addEventListener('click', LOCATIONFINDER.onClickSearchField, false);
        }
        else if (searchInputField != null && searchInputField.attachEvent) {
            searchInputField.attachEvent('onclick', LOCATIONFINDER.onClickSearchField);
        }    

        if (searchInputField != null && searchInputField.addEventListener) {
            searchInputField.addEventListener('keyup', LOCATIONFINDER.onKeyUpSearchField, false);
        }
        else if (searchInputField != null && searchInputField.attachEvent) {
            searchInputField.attachEvent('onkeyup', LOCATIONFINDER.onKeyUpSearchField);
        }    

        // search icon click
        /*
        var searchInputField = document.getElementById('zipfield');
        if (searchInputField.addEventListener) {
            searchInputField.addEventListener('click', LOCATIONFINDER.onSearchIconClick, false);
        }
        else if (searchInputField.attachEvent) {
            searchInputField.attachEvent('onclick', LOCATIONFINDER.onSearchIconClick);
        } 
        */

        // hide show map
        var hideShowMapButton = document.getElementById('hideShowMap');
        if (hideShowMapButton != null && hideShowMapButton.addEventListener) {
            hideShowMapButton.addEventListener('click', LOCATIONFINDER.onClickHideShowMap, false);
        }
        else if (hideShowMapButton != null && hideShowMapButton.attachEvent) {
            hideShowMapButton.attachEvent('onclick', LOCATIONFINDER.onClickHideShowMap);
        }    


        $('.searchIcon').on('click', LOCATIONFINDER.onSearchIconClick);

        // setup check boxes
        $('.iconCareTypeCheckBox').on('click', LOCATIONFINDER.onCareTypeCheckBoxClick);
        $('.iconSpecialtyCheckBox').on('click', LOCATIONFINDER.onSpecialtyCheckBoxClick);

        $('.filter-nav-tabs li').on('click', LOCATIONFINDER.hideShowTab);

        $('.dropdown-menu li.radius').on('click', LOCATIONFINDER.raduisChange);

        $('.removeSpecialtyFilters').on('click', LOCATIONFINDER.onRemoveSpecialtyFilters);

        if (document.getElementById('map_canvas') != null && document.getElementById('map_canvas') != undefined) {
            var department = LOCATIONFINDER.getParameterByName("department");
            if (department != null && department != undefined) {
               LOCATIONFINDER.userSelectedDepartments = department;
		       $('#specialtyPanel').animate({
                   'scrollTop':   ($('#'+department+'SelectionLabel').offset().top-400)
               }, 500);
            }            

            // setup window resize for destop incase they hide the map and then resize back to full screen
            $( window ).resize(LOCATIONFINDER.onResize);


            if (activeRadiusParam != null && activeRadiusParam != 'null' && activeRadiusParam != '') {
				LOCATIONFINDER.radius = activeRadiusParam;
                if (LOCATIONFINDER.radius == 100) {
                    $( "#radius-search-item" ).text('Search up to ' + LOCATIONFINDER.radius + ' miles or greater');
                }
                else {
                    $( "#radius-search-item" ).text('Search within ' + LOCATIONFINDER.radius + ' miles');
                }
            }
            else {
				LOCATIONFINDER.radius = 100;
            }

            if (activeZipCodeParam != null && activeZipCodeParam != 'null' && activeZipCodeParam != '') {
                document.getElementById('zip-search-item').value = activeZipCodeParam;
                LOCATIONFINDER.onSearchIconClick();
            }
            else {
                LOCATIONFINDER.getUserLocation();
                LOCATIONFINDER.initializeCountryView();
    
                LOCATIONFINDER.handleStateLookup("US-All");
            }
        }
    },

    setParameter: function(name,value) {
        if (window.history.pushState) {
           //prevents browser from storing history with each change:

           var url = window.location.href;
           if (url.indexOf(name)>0) {
               //replace value with new value
			   var paramValue = url.substring(url.indexOf(name+'='));
               if (paramValue.indexOf("&")>0) {
                   paramValue = paramValue.substring(0,paramValue.indexOf("&"));
                   url = url.replace(paramValue, name+'='+value);
               }
               else {
                   url = url.replace(paramValue, name+'='+value);
               }

               window.history.pushState('locationFinder', 'Nemours - Location Finder', url);
           }    
           else if (url.indexOf('?')>0) {
               window.history.pushState('locationFinder', 'Nemours - Location Finder', url+'&'+name+'='+value);
           }
           else {
               window.history.pushState('locationFinder', 'Nemours - Location Finder', url+'?'+name+'='+value);
           }
        }        
    },


    removeParameter: function(name) {
        if (window.history.pushState) {
           //prevents browser from storing history with each change:

           var url = window.location.href;
           if (url.indexOf(name)>0) {
               //replace value with new value
			   var paramValue = url.substring(url.indexOf(name+'='));
               if (paramValue.indexOf("&")>0) {
                   paramValue = paramValue.substring(0,paramValue.indexOf("&"));
                   url = url.replace(paramValue, '');
               }
               else {
                   url = url.replace(paramValue, '');
               }

               window.history.pushState('locationFinder', 'Nemours - Location Finder', url);
           }    
        }        
    },

    getParameterByName: function(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    },

    raduisChange: function(event) { 
		LOCATIONFINDER.radius = $(event.currentTarget)[0].id;       
        if (LOCATIONFINDER.radius == 100) {
	        $( "#radius-search-item" ).text('Search up to ' + LOCATIONFINDER.radius + ' miles or greater');
        }
        else {
	        $( "#radius-search-item" ).text('Search within ' + LOCATIONFINDER.radius + ' miles');
        }
        LOCATIONFINDER.setParameter('radius',LOCATIONFINDER.radius);
        if (LOCATIONFINDER.currentStateLookup && LOCATIONFINDER.hits) {
            LOCATIONFINDER.initializeStateView( LOCATIONFINDER.currentStateLookup, LOCATIONFINDER.currentZoomLevel );
            LOCATIONFINDER.displayStateLookupResults(LOCATIONFINDER.hits);
        }
    },


    //TAB CONTROL 
    hideShowTab: function(event) { 
        if (event.type == "click" && !$(event.currentTarget).hasClass('active')) {
            $(".filter-nav-tabs li").each(function(){
                $(this).removeClass("active");
            });
            $(event.currentTarget).addClass('active');
            var panelName = $(event.currentTarget)[0].id.replace('Tab','Panel');
            $(".filter-tab-content .panel").each(function(){
                $(this).removeClass("active");
                if ($(this)[0].id == panelName) {
					$(this).addClass("active");
                }
            });
        }
    },    

    onResize: function(e) {
        //on resizing desktop larger if map was hidden, show it
        if (e.target.outerWidth >= 768 && document.getElementById('hideShowMap').children[0].className.indexOf('showMap') >= 0) {
            LOCATIONFINDER.onClickHideShowMap();
        }
    },

    onCareTypeCheckBoxClick: function(e) {
        // remove specialty filters
        $(".iconSpecialtyCheckBox.active").each(function(){
            $(this).removeClass("active");
        });
        $("input:checkbox[name='specialtygroup']").each(function(){
            $(this).prop('checked', false);
            $(this).removeAttr('checked');
        });
        LOCATIONFINDER.userSelectedDepartments = null;
        activeDepartmentLabel = '';

		// set selected care type
        if (e.currentTarget.className.indexOf('active') >=0) {
            e.currentTarget.className = e.currentTarget.className.replace('active','');
        }
        else {
            e.currentTarget.className = e.currentTarget.className + ' active';
        }

        if (e.currentTarget.nextSibling.data == 'Primary Care') {
			LOCATIONFINDER.showPrimaryCare = !LOCATIONFINDER.showPrimaryCare;
            LOCATIONFINDER.setParameter('careType','primary');
        }
        else if (e.currentTarget.nextSibling.data == 'Urgent Care') {
			LOCATIONFINDER.showUrgentCare = !LOCATIONFINDER.showUrgentCare;
            LOCATIONFINDER.setParameter('careType','urgent');
        }
        else if (e.currentTarget.nextSibling.data == 'Specialty Care') {
			LOCATIONFINDER.showSpecialtyCare = !LOCATIONFINDER.showSpecialtyCare;
            LOCATIONFINDER.setParameter('careType','specialty');
        }
        else if (e.currentTarget.nextSibling.data == 'Hospital/Emergency Room (ER)') {
			LOCATIONFINDER.showHospitalER = !LOCATIONFINDER.showHospitalER;
            LOCATIONFINDER.setParameter('careType','hospital');
        }
        else if (e.currentTarget.nextSibling.data == 'Collaborating Hospital') {
			LOCATIONFINDER.showCollaborating = !LOCATIONFINDER.showCollaborating;
            LOCATIONFINDER.setParameter('careType','collaborating');
        }
        if (!LOCATIONFINDER.showPrimaryCare && !LOCATIONFINDER.showUrgentCare && !LOCATIONFINDER.showSpecialtyCare && !LOCATIONFINDER.showHospitalER && !LOCATIONFINDER.showCollaborating) {
            LOCATIONFINDER.showAll = true;
            LOCATIONFINDER.removeParameter('careType');
        }
        else {
            LOCATIONFINDER.showAll = false;
        }
        if (LOCATIONFINDER.currentStateLookup && LOCATIONFINDER.hits) {
		    LOCATIONFINDER.initializeStateView( LOCATIONFINDER.currentStateLookup, LOCATIONFINDER.currentZoomLevel );
            LOCATIONFINDER.handleStateLookup( LOCATIONFINDER.currentStateLookup );
 			//LOCATIONFINDER.displayStateLookupResults( LOCATIONFINDER.hits );
        }

    },

    onSpecialtyCheckBoxClick: function(e) {
        // remove care type filters
        $(".iconCareTypeCheckBox.active").each(function(){
            $(this).removeClass("active");
        });
        $("input:checkbox[name='caretypegroup']").each(function(){
            $(this).prop('checked', false);
            $(this).removeAttr('checked');
        });


        if (e.currentTarget.className.indexOf('active') >=0) {
            e.currentTarget.className = e.currentTarget.className.replace('active','');
        }
        else {
            e.currentTarget.className = e.currentTarget.className + ' active';
        }

		LOCATIONFINDER.userSelectedDepartments = null;
        $(".iconSpecialtyCheckBox.active").each(function(){
	        if (LOCATIONFINDER.userSelectedDepartments == null || LOCATIONFINDER.userSelectedDepartments =='') {
	            LOCATIONFINDER.userSelectedDepartments = $(this)[0].parentNode.id.replace('SelectionLabel','');
            }
            else {
	            LOCATIONFINDER.userSelectedDepartments = $(this)[0].parentNode.id.replace('SelectionLabel','') + "," + LOCATIONFINDER.userSelectedDepartments ;
            }
        });        

        if (LOCATIONFINDER.userSelectedDepartments != null && LOCATIONFINDER.userSelectedDepartments !='') {
        	LOCATIONFINDER.setParameter('department',LOCATIONFINDER.userSelectedDepartments);
		}
        else {
        	LOCATIONFINDER.removeParameter('department');
        }

        if (LOCATIONFINDER.currentStateLookup && LOCATIONFINDER.hits) {
		    LOCATIONFINDER.initializeStateView( LOCATIONFINDER.currentStateLookup, LOCATIONFINDER.currentZoomLevel );
            LOCATIONFINDER.handleStateLookup( LOCATIONFINDER.currentStateLookup );
        }

    },    

    onRemoveSpecialtyFilters: function() {
        // set the selected specialty
        $(".iconSpecialtyCheckBox.active").each(function(){
            $(this).removeClass("active");
        });
        $("input:checkbox[name='specialtygroup']").each(function(){
            $(this).prop('checked', false);
            $(this).removeAttr('checked');
        });
        LOCATIONFINDER.userSelectedDepartments = null;
        activeDepartmentLabel = '';
        if (LOCATIONFINDER.currentStateLookup && LOCATIONFINDER.hits) {
		    LOCATIONFINDER.initializeStateView( LOCATIONFINDER.currentStateLookup, LOCATIONFINDER.currentZoomLevel );
            LOCATIONFINDER.handleStateLookup( LOCATIONFINDER.currentStateLookup );
        }
        else {
            LOCATIONFINDER.getUserLocation();
            LOCATIONFINDER.initializeCountryView();
        }
    },

    onClickSearchField: function() {
        var searchInputField = document.getElementById('zip-search-item');
        searchInputField.className = 'zip-search-field active';
        searchInputField.value = '';
    },

    onKeyUpSearchField: function(e) {
        if (e.keyCode == 13) {
            LOCATIONFINDER.latLongLookup(document.getElementById('zip-search-item').value);
        }
    },   

    onSearchIconClick: function(e) {
        LOCATIONFINDER.latLongLookup(document.getElementById('zip-search-item').value);
    },   

    onClickHideShowMap: function(event) {
        if (document.getElementById('hideShowMap').children[0].className.indexOf('hideMap') >= 0) {
			document.getElementById('hideShowMap').children[0].className = document.getElementById('hideShowMap').children[0].className.replace('hideMap','showMap');
            document.getElementById('hideShowMap').children[0].children[0].children[0].innerHTML = 'Show Map';
        }
        else if (document.getElementById('hideShowMap').children[0].className.indexOf('showMap') >= 0) {
            document.getElementById('hideShowMap').children[0].className = document.getElementById('hideShowMap').children[0].className.replace('showMap','hideMap');
            document.getElementById('hideShowMap').children[0].children[0].children[0].innerHTML = 'Hide Map';
        }
        $('.mapcontrol').toggleClass('hidden');
    },

    onAutocompletePlaceChanged: function() {
          LOCATIONFINDER.place = autocomplete.getPlace();

          if (LOCATIONFINDER.place != null && LOCATIONFINDER.place != undefined && LOCATIONFINDER.place.name != undefined && LOCATIONFINDER.place.name.length ==5 && !isNaN(LOCATIONFINDER.place.name)) {
			  LOCATIONFINDER.latLongLookup(LOCATIONFINDER.place.name);
          }
          else if (LOCATIONFINDER.place != null && LOCATIONFINDER.place != undefined && LOCATIONFINDER.place.formatted_address != undefined) {
              LOCATIONFINDER.locationSearchPosition = new google.maps.LatLng(LOCATIONFINDER.place.geometry.location.lat(), LOCATIONFINDER.place.geometry.location.lng());
  			  LOCATIONFINDER.initializeStateView(LOCATIONFINDER.place.formatted_address.split(', ')[1]);
              LOCATIONFINDER.handleStateLookup(LOCATIONFINDER.place.formatted_address.split(', ')[1]);
          }
    },

    performSearch: function(searchValue) {
        if (searchValue && searchValue.length >= 3 && searchValue != '') {
            LOCATIONFINDER.handleZipSearch(searchValue);
	        LOCATIONFINDER.setParameter('zipsearch',searchValue);
		}
        else {
            alert('Please enter a 5 digit Zip Code.');
        }
    },

    initializeCountryView: function() {     
        document.getElementById('map_canvas').className = 'country';

        var container = document.getElementById('locations');
        container.innerHTML = "";    

        var userLatitudeLongitude = new google.maps.LatLng(39, -96);            
        var myOptions = {           
            center: userLatitudeLongitude,
            minZoom: 3,
            maxZoom: 9,
            zoom: 4,
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false
        };
        map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);  

        infowindow = new google.maps.InfoWindow();
        marker = new google.maps.Marker({
          map: map
        });

        autocomplete = new google.maps.places.Autocomplete( (document.getElementById('zip-search-item')), { types: ['(cities)'], componentRestrictions: {country: "us"} } );
        google.maps.event.addListener(autocomplete, 'place_changed', function() { LOCATIONFINDER.onAutocompletePlaceChanged(); } );        
        autocomplete.bindTo('bounds', map);

        for (var i=0;i<states.length;i++) {
            if (states[i][4]>0){
                var gooLatLong = LOCATIONFINDER.createLatLng(states[i][3],states[i][2]);
                var stateId = states[i][1];
                LOCATIONFINDER.createMarkerWithLabel(gooLatLong,'mapLabel',states[i][0],states[i][4], LOCATIONFINDER.countryViewStateClick, null, null );
            }
        }
    },

    countryViewStateClick: function(event) {
        var clicklat = LOCATIONFINDER.getLat(event.latLng);
        var clicklng = LOCATIONFINDER.getLong(event.latLng);
        for (var i=0;i<states.length;i++) {
            if ((states[i][2] == clicklng && states[i][3] == clicklat) || (Math.floor(states[i][2]) == Math.floor(clicklng) && states[i][3] == clicklat) || (states[i][2] == clicklng && Math.floor(states[i][3]) == Math.floor(clicklat)) ) {
              // initialize state that was clicked
                LOCATIONFINDER.zipToSortByLatLong = {};
		      LOCATIONFINDER.zipToSortByLatLong.latitude = states[i][3];
              LOCATIONFINDER.zipToSortByLatLong.longitude = states[i][2];
              LOCATIONFINDER.initializeStateView(states[i][1]);
              LOCATIONFINDER.handleStateLookup(states[i][1]);
              break;
            }
        }            
    },        

    initializeStateView : function(stateLookup) { 
        LOCATIONFINDER.currentStateLookup = stateLookup;
        LOCATIONFINDER.currentState = null;
		LOCATIONFINDER.infoWindowList = [];

        document.getElementById('map_canvas').className = 'state';
        var container = document.getElementById('locations');
        container.innerHTML = "";    

        var zoomTo =  11;
        var state;    

        for (var i=0;i<states.length;i++) {
            if (states[i][1] == stateLookup){
                state = states[i];
                LOCATIONFINDER.currentState = state;
                break;
            }
        }

        if (LOCATIONFINDER.radius == 10) {
            zoomTo =  11;
        }
        else if (LOCATIONFINDER.radius == 25) {
            zoomTo =  10;
        }
        else if (LOCATIONFINDER.radius == 50) {
            zoomTo =  9;
        }
        else if (LOCATIONFINDER.radius == 100) {
            if (stateLookup == 'FL' || stateLookup == 'GA' || stateLookup == 'PA') {
                zoomTo =  7;
            }
            else {
            	zoomTo =  8;
            }
        }


        LOCATIONFINDER.currentZoomLevel = zoomTo;

        var userLatitudeLongitude = new google.maps.LatLng(state[3], state[2]);   
        if (LOCATIONFINDER.locationSearchPosition) {
            LOCATIONFINDER.userSelectedLocation = LOCATIONFINDER.locationSearchPosition;
			userLatitudeLongitude = LOCATIONFINDER.locationSearchPosition;    
        }
        else if (LOCATIONFINDER.zipToSortByLatLong != null ) {
            // if it is a zipcode search get lat long of zip code and use that as the center
            LOCATIONFINDER.userSelectedLocation = LOCATIONFINDER.zipToSortByLatLong;
			userLatitudeLongitude = new google.maps.LatLng(LOCATIONFINDER.zipToSortByLatLong.latitude, LOCATIONFINDER.zipToSortByLatLong.longitude);    
        }
        else if (LOCATIONFINDER.userSharedGeoLocation) {
            LOCATIONFINDER.userSelectedLocation = LOCATIONFINDER.userLocation.coords;
			userLatitudeLongitude = new google.maps.LatLng(LOCATIONFINDER.userLocation.coords.latitude, LOCATIONFINDER.userLocation.coords.longitude);    
        }

        var myOptions = {           
            center: userLatitudeLongitude,
            minZoom: 3,
            maxZoom: 15,
            zoom: zoomTo,
            zoomControl: true,
            mapTypeControl: false,
            scaleControl: true,
            streetViewControl: false,
            rotateControl: false,
            fullscreenControl: false
        };
        map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);  

        infowindow = new google.maps.InfoWindow();
        marker = new google.maps.Marker({
          map: map,
          icon: '/etc/designs/nemoursv2/www/image/markericon.png'
          
        });

		if (LOCATIONFINDER.place != null && LOCATIONFINDER.place != undefined && LOCATIONFINDER.place.geometry != undefined && LOCATIONFINDER.place.geometry.viewport) {
              map.fitBounds(LOCATIONFINDER.place.geometry.viewport);
        }

        autocomplete = new google.maps.places.Autocomplete( (document.getElementById('zip-search-item')), { types: ['(cities)'], componentRestrictions: {country: "us"} } );
        google.maps.event.addListener(autocomplete, 'place_changed', function() { LOCATIONFINDER.onAutocompletePlaceChanged(); } );        
        autocomplete.bindTo('bounds', map);
    },

    handleStateLookup : function( value ) {
        var httpHeader = { "Accept": "application/json" };
        var url = "/content/nemours/wwwv2/test2/jcr:content/center-column-parsys/location_finder.lookup?statelookup=" + value;

        if (LOCATIONFINDER.userSelectedDepartments) {
           url = url + "&department=" + LOCATIONFINDER.userSelectedDepartments;
        }

        LOCATIONFINDER.lookupCall( url, httpHeader, LOCATIONFINDER.handleStateLookupResponse ); // hit server
    },   

    handleStateLookupResponse : function(opts, success, response) {
        if (success) {
            var hits = response.responseText;
            if ( hits ) {
                LOCATIONFINDER.displayStateLookupResults( hits );
            }
        }
    },

    displayStateLookupResults : function( hits ) {
        LOCATIONFINDER.markerMap = [];
        LOCATIONFINDER.markerCount = 0;
        var container = document.getElementById('locations');

        var locationCount = LOCATIONFINDER.processStateResults(hits);
        var countEl = document.createElement('h5');
        countEl.className = 'well-header';
        if (locationCount == 0) {
            countEl.innerHTML = noLocationsFoundText;

        }
        container.appendChild(countEl);

        if (LOCATIONFINDER.currentStateLookup == null) {
            var sortedLocations = [];
            var index = 0;
            var startIndex = 0;
            var endIndex = 0;
            do {
                if (LOCATIONFINDER.locationList[index] && LOCATIONFINDER.locationList[index+1] && (LOCATIONFINDER.locationList[index].locationState != LOCATIONFINDER.locationList[index+1].locationState) ) {
					endIndex = index + 1;
                    Array.prototype.push.apply(sortedLocations, LOCATIONFINDER.bubbleSortLocationTitle(LOCATIONFINDER.locationList.slice(startIndex, endIndex)));
                    startIndex = endIndex;
                    //index = endIndex;
                }
                index = index + 1;

            } while (index < LOCATIONFINDER.locationList.length)
			Array.prototype.push.apply(sortedLocations, LOCATIONFINDER.bubbleSortLocationTitle(LOCATIONFINDER.locationList.slice(startIndex, LOCATIONFINDER.locationList.length)));                
            LOCATIONFINDER.locationList = sortedLocations;
        }
        else {
        	LOCATIONFINDER.sortLocationsByDistance();
        }

        var filteredLocationCount = 0;

        for (var i = 0;i<LOCATIONFINDER.locationList.length;i++) {
            if (LOCATIONFINDER.radius == 100) {
	            LOCATIONFINDER.createLocation(container, LOCATIONFINDER.locationList[i]);
                filteredLocationCount = filteredLocationCount + 1;
            }
            else if (LOCATIONFINDER.locationList[i].distanceFromUser <= LOCATIONFINDER.radius) {
	            LOCATIONFINDER.createLocation(container, LOCATIONFINDER.locationList[i]);
                filteredLocationCount = filteredLocationCount + 1;
            }
        }
        if (filteredLocationCount > 0) {
            countEl.innerHTML = filteredLocationCount + ((activeDepartmentLabel != null && activeDepartmentLabel != undefined && activeDepartmentLabel != '')? ' ' + activeDepartmentLabel :'') + ' Locations';
        }
        else {
            countEl.innerHTML = noLocationsFoundText;
        }
    },

    processStateResults : function(hits) {
        LOCATIONFINDER.hits = hits;
        LOCATIONFINDER.locationList = [];
        var locationCount = 0;
        var locations = LOCATIONFINDER.hits.split('||');
        for (var i = 0;i<locations.length;i++) {
            var data = locations[i].split('!!');
            var location = {
                locationTitle: '',
                locationSubTitle: '',
                locationLatitude: '',
                locationLongitude: '',
                locationBuildingPlaza: '',
                locationStreedAddress: '',
                locationCity: '',
                locationState: '',
                locationZip: '',
                locationViewMapUrl: '',
                locationPhoneNumber: '',
                locationSecondaryPhoneNumber: '',
                locationUrl: '',
                locationType: ''
            };


            for (var j = 0;j<data.length;j++) {
                 if (j==0) {
                    location.locationTitle = data[j];
                 }
                 else if (j==1) {
                    location.locationSubTitle = data[j];
                 }
                 else if (j==2) {
                    location.locationLatitude = data[j];
                 }
                 else if (j==3) {
                    location.locationLongitude = data[j];
                 }
                 else if (j==4) {
                    location.locationBuildingPlaza = data[j];
                 }
                 else if (j==5) {
                    location.locationStreedAddress = data[j];
                 }
                 else if (j==6) {
                    location.locationCity = data[j];
                 }
                 else if (j==7) {
                    location.locationState = data[j];
                 }
                 else if (j==8) {
                    location.locationZip = data[j];
                 }
                 else if (j==9) {
                    location.locationViewMapUrl = data[j];
                 }
                 else if (j==10) {
                    location.locationPhoneNumber = data[j];
                 }
                 else if (j==11) {
                    location.locationSecondaryPhoneNumber = data[j];
                 }
                 else if (j==12) {
                    location.locationUrl = data[j];
                 }
                 else if (j==13) {
                    location.locationType = data[j];
                 }
            }
            if (location.locationTitle != '' && location.locationLatitude != '' && location.locationLongitude != '') {

                if (LOCATIONFINDER.showPrimaryCare && location.locationType == 'primary') {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }
                if (LOCATIONFINDER.showUrgentCare && location.locationType == 'urgent') {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }
                if (LOCATIONFINDER.showSpecialtyCare && location.locationType == 'specialty') {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }
                if (LOCATIONFINDER.showHospitalER && location.locationType == 'hospital-emergency') {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }
                if (LOCATIONFINDER.showCollaborating && location.locationType == 'affiliate') {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }
                if (LOCATIONFINDER.showAll) {
                    LOCATIONFINDER.locationList.push(location);
                    locationCount = locationCount + 1;
                }                
            }
        }
        return locationCount;
    },

    stateViewZipClick : function(event) {
        var latLong = LOCATIONFINDER.createLatLng( LOCATIONFINDER.getLat(event.latLong), LOCATIONFINDER.getLong(event.latLong) );
        LOCATIONFINDER.zipToSortByLatLong = latLong;
        LOCATIONFINDER.geoCoder.geocode( { 'location': latLong}, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                if (results[0].address_components) {
                    for (var i=0;i<results[0].address_components.length;i++) {
                        if (results[0].address_components[i].types[0] == 'postal_code') {
                            LOCATIONFINDER.zipToSortBy = results[0].address_components[i].short_name;
                            LOCATIONFINDER.sortProvidersByDistance();
                            break;                
                        }
                    }
                }
            }
            else {
                console.log("Unable to Find Location:" +location);
            }
        });
    },    

    handleZipSearch : function( value ) {
        var httpHeader = { "Accept": "application/json" };
        var url = "/content/nemours/wwwv2/test2/jcr:content/center-column-parsys/location_finder.lookup?zipsearch=" + value;
        LOCATIONFINDER.lookupCall( url, httpHeader, LOCATIONFINDER.handleZipLookupResponse ); // hit server
    },   

    handleZipLookupResponse : function(opts, success, response) {
        if (success) {
            var hits = eval(response.responseText);
            if ( hits ) {
                LOCATIONFINDER.displayZipLookupResults( hits );
            }
        }
    },

    displayZipLookupResults: function( state ) {
        LOCATIONFINDER.initializeStateView(state[1]);
        LOCATIONFINDER.handleStateLookup(state[1]);
    }, 

    lookupCall : function(url,header,handler) {
	    $.get({
            url: url, 
            headers: header,
            success: handler
        });        
    },

    getUserLocation: function() {
        if (navigator.geolocation) {
            // attempt to get users position from the browser
            navigator.geolocation.getCurrentPosition(LOCATIONFINDER.setUserLocation, LOCATIONFINDER.locationError);
        } 
        else {
            var container = document.getElementById('locations');
            container.innerHTML = "Geolocation is not supported by this browser. Unable to obtain your latitude and longitude to find locations near you.  Please update your browser and enable location services for www.nemours.org for a better user experience.  Thank you!";
        }
    },

    setUserLocation: function(position) {
		LOCATIONFINDER.userSharedGeoLocation = true;
        // location services are enabled in the browser
        // set the users location
		LOCATIONFINDER.userLocation = position;
		LOCATIONFINDER.reverseGeocoding(LOCATIONFINDER.userLocation.coords.latitude,LOCATIONFINDER.userLocation.coords.longitude);
    },

    geolocateUserLocation: function() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                var geolocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                var circle = new google.maps.Circle({
                    center: geolocation,
                    radius: position.coords.accuracy
                });
               autocomplete.setBounds(circle.getBounds());
           });
        }
    }, 

    locationError: function(error) {
        var container = document.getElementById('locations');
        // if the user has not started interacting with the map display the location error message
        if (container.innerHTML == '') {
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    container.innerHTML = "Geolocation is supported by this browser; however, User denied the request for Geolocation."
                    break;
                case error.POSITION_UNAVAILABLE:
                    container.innerHTML = "Geolocation is supported by this browser; however, Location information is unavailable."
                    break;
                case error.TIMEOUT:
                    container.innerHTML = "Geolocation is supported by this browser; however, The request to get user location timed out."
                    break;
                case error.UNKNOWN_ERROR:
                    container.innerHTML = "Geolocation is supported by this browser; however, An unknown error occurred."
                    break;
            }        
        }
    },

    reverseGeocoding: function(lat, long) {
        var found = false;
        var shortName = '';
        var latlng = new google.maps.LatLng(lat, long);
        LOCATIONFINDER.geoCoder.geocode({ 'latLng': latlng, 'region': 'US' }, function (results, status) {
            if (status == 'OK' && results && results.length > 0) {
                for (var r = 0;r < results.length; r ++) {
                    for (var c = 0; c < results[r].address_components.length; c ++) {
                        if (results[r].address_components[c].types[0] == 'administrative_area_level_1') {
                            shortName = results[r].address_components[c].short_name;
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        break;
                    }
                }
                if (found) {
                  LOCATIONFINDER.initializeStateView(shortName);
                  LOCATIONFINDER.handleStateLookup(shortName);

                }
            }
        });
    },

    latLongLookup: function(zip) {
        LOCATIONFINDER.zipToSortBy = zip;
        LOCATIONFINDER.geoCoder.geocode( { 'address': LOCATIONFINDER.zipToSortBy }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    LOCATIONFINDER.zipToSortByLatLong = {};
                    LOCATIONFINDER.zipToSortByLatLong.latitude  = eval(results[0].geometry.location.lat());
                    LOCATIONFINDER.zipToSortByLatLong.longitude = eval(results[0].geometry.location.lng());
                    if (LOCATIONFINDER.zipToSortBy != null && LOCATIONFINDER.zipToSortBy != '') {
                        LOCATIONFINDER.performSearch(document.getElementById('zip-search-item').value);
              	        LOCATIONFINDER.setParameter('zipsearch',document.getElementById('zip-search-item').value);
                    }
                    else if (LOCATIONFINDER.place != null && LOCATIONFINDER.place != undefined && LOCATIONFINDER.place.name != undefined && LOCATIONFINDER.place.name.length ==5 && !isNaN(LOCATIONFINDER.place.name)) {
                        LOCATIONFINDER.handleZipSearch(LOCATIONFINDER.place.name);
              	        LOCATIONFINDER.setParameter('zipsearch',LOCATIONFINDER.place.name);
                    }

                }
                else {
                    console.log("Unable to Find Location:" +location);
                }
        });
    },

    createLatLng : function ( latitude, longitude ) {
        return new google.maps.LatLng(latitude,longitude);
    },

    getLat : function(latLong) {
        return latLong.lat();
    },

    getLong: function(latLong) {
		return latLong.lng();        
    },

    getDistance: function(lat, long, compareLat, compareLong) {
        var d2r = 0.0174532925199433;
        var dlong = (compareLong - long) * d2r;
        var dlat = (compareLat - lat) * d2r;
        var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        var d = 3956 * c; 
        return d;        
    },

    getDistanceFromUser: function(compareLat, compareLong) {
        if (LOCATIONFINDER.userSelectedLocation.lat) {
            LOCATIONFINDER.userSelectedLocation.latitude = eval(LOCATIONFINDER.userSelectedLocation.lat());
        }
        if (LOCATIONFINDER.userSelectedLocation.lng) {
            LOCATIONFINDER.userSelectedLocation.longitude = eval(LOCATIONFINDER.userSelectedLocation.lng());
        }

        var d2r = 0.0174532925199433;
        var lat = (LOCATIONFINDER.userSelectedLocation.latitude)?LOCATIONFINDER.userSelectedLocation.latitude:LOCATIONFINDER.userSelectedLocation.coords.latitude;
        var lng = (LOCATIONFINDER.userSelectedLocation.longitude)?LOCATIONFINDER.userSelectedLocation.longitude:LOCATIONFINDER.userSelectedLocation.coords.longitude;
        var dlong = (compareLong - lng) * d2r;
        var dlat = (compareLat - lat) * d2r;
        var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        var d = 3956 * c; 
        return d;        
    },

    createLocation : function(container, location) {
		var showDistance = (location.distanceFromUser != null && location.distanceFromUser != undefined);

        LOCATIONFINDER.markerCount = LOCATIONFINDER.markerCount + 1;

        var rowEl = document.createElement('div');
        rowEl.className = 'row no-gutters fullHeight';
        container.appendChild(rowEl);

        var iconClass = 'iconMarker';

        if (location.locationType == 'primary') {
            iconClass = 'iconPrimaryCareMarker';
        }
        else if (location.locationType == 'urgent') {
            iconClass = 'iconPrimaryCareMarker';
        }
        else if (location.locationType == 'specialty') {
            iconClass = 'iconPrimaryCareMarker';
        }
        else if (location.locationType == 'hospital-emergency') {
            iconClass = 'iconHospitalMarker';
        }
        else if (location.locationType == 'affiliate') {
            iconClass = 'iconPrimaryCareMarker';
        }
		var iconEl = document.createElement('div');
        iconEl.className = 'col-lg-1 col-md-1 col-sm-1 col-xs-1';
        var iconClassValue = 'iconValue';
        if (LOCATIONFINDER.markerCount>99) {
            iconClassValue = 'vwideIconValue';
        }
        else if (LOCATIONFINDER.markerCount>9) {
            iconClassValue = 'wideIconValue';
        }

        var locationLabelText = LOCATIONFINDER.markerCount;
        if (location.locationType == 'hospital-emergency') {
            locationLabelText = '';
        }

        iconEl.innerHTML = '<span class="marker"><span class="'+iconClass+'"></span><span class=\"' + iconClassValue + '\">' + locationLabelText + '</span></span>';
        rowEl.appendChild(iconEl);

        var locationDiv = document.createElement('div');
        if (showDistance) {
        	locationDiv.className = "location col-lg-10 col-md-10 col-sm-10 col-xs-10";
        }
        else {
            locationDiv.className = "location col-lg-11 col-md-11 col-sm-11 col-xs-11";
        }
        rowEl.appendChild(locationDiv);


        if (location.locationTitle && location.locationTitle != '') {
            var locationTitleEl = document.createElement('div');
            locationTitleEl.className = 'locationTitle';
            locationTitleEl.innerHTML = '<a href="'+location.locationUrl+'" target="_blank">' + location.locationTitle + '</a>';
            locationDiv.appendChild(locationTitleEl);
        }

        if (location.locationSubTitle && location.locationSubTitle != '') {
            var locationSubTitleEl = document.createElement('div');
            locationSubTitleEl.className = 'locationSubTitle';
            locationSubTitleEl.innerHTML = '<h6>' + location.locationSubTitle + '</h6>';
            locationDiv.appendChild(locationSubTitleEl);
        }

        if (location.locationBuildingPlaza != '' || location.locationStreedAddress != '' || location.locationCity != '' || location.locationState != '' || location.locationZip != '') {
        var locationAddressEl = document.createElement('p');
        locationAddressEl.className = 'locationAddress';
        locationAddressEl.innerHTML = 
            ((location.locationBuildingPlaza && location.locationBuildingPlaza != '')?location.locationBuildingPlaza + '<br>':'') +
            ((location.locationStreedAddress && location.locationStreedAddress != '')?location.locationStreedAddress + '<br>':'') +
            ((location.locationCity && location.locationCity != '')?location.locationCity + ', ':'') +
            ((location.locationState && location.locationState != '')?location.locationState + ' ':'') +
            ((location.locationZip && location.locationZip != '')?location.locationZip:'');
            locationDiv.appendChild(locationAddressEl);
        }

        if (location.locationViewMapUrl && location.locationViewMapUrl != '') {
            var viewMapEl = document.createElement('div');
            viewMapEl.className = 'locationViewDirections';
            viewMapEl.innerHTML = '<a target="_blank" href="'+location.locationViewMapUrl+'">Get Directions <i class="glyphicon glyphicon-new-window"></i></a>';
            locationDiv.appendChild(viewMapEl);
        }

        if (location.locationPhoneNumber && location.locationPhoneNumber != '') {
            var phoneNumberEl = document.createElement('p');
            phoneNumberEl.className = 'locationPhoneNumber';
            var callLabel = 'Call: ';
            if (location.locationTitle.indexOf('Specialty')>=0) {
                callLabel = 'Appointments: ';
            }
            phoneNumberEl.innerHTML = callLabel+'<a href="tel:'+location.locationPhoneNumber+'"><span class="call-icon"></span>'+location.locationPhoneNumber+'</a>';
            locationDiv.appendChild(phoneNumberEl);
        }

        if (location.locationSecondaryPhoneNumber && location.locationSecondaryPhoneNumber != '') {
            var phoneNumberSecondaryEl = document.createElement('p');
            phoneNumberSecondaryEl.className = 'locationSecondaryPhoneNumber';
            var callLabel = 'Information: ';
            phoneNumberSecondaryEl.innerHTML = callLabel+'<a href="tel:'+location.locationSecondaryPhoneNumber+'"><span class="call-icon"></span>'+location.locationSecondaryPhoneNumber+'</a>';
            locationDiv.appendChild(phoneNumberSecondaryEl);
        }

        if (showDistance) {
            var distanceEl = document.createElement('div');
            distanceEl.className = 'col-lg-1 col-md-1 col-sm-1 col-xs-1';
            distanceEl.innerHTML = location.distanceFromUser.toFixed(1) + " mi";
            rowEl.appendChild(distanceEl);
        }        

		var hrEl = document.createElement('hr');
        hrEl.className = 'divider';
        container.appendChild(hrEl);


        var geoLoc = LOCATIONFINDER.createLatLng(location.locationLatitude,location.locationLongitude);

        var infoWindow = new google.maps.InfoWindow({
          content: locationDiv.innerHTML
        });

        if (LOCATIONFINDER.currentStateLookup != null) {
        	LOCATIONFINDER.createMarkerWithLabel(geoLoc, 'mapLocationLabel', location.locationTitle, LOCATIONFINDER.markerCount, null, infoWindow, location.locationType );
        	LOCATIONFINDER.markerMap.push(LOCATIONFINDER.markerCount, location.locationTitle);
        }
    },

    createMarkerWithLabel : function(latLng, labelClass, title, content, funct, infoWindow, locationType) {
        if (labelClass == 'mapLabel') {
 			var labelLength = content + " ";
            if (labelLength.trim().length == 2) {
				labelClass = 'wideMapLabel';
            }
            else if (labelLength.trim().length == 3) {
				labelClass = 'vwideMapLabel';
            }
        }
        else if (labelClass == 'mapLocationLabel') {
 			var labelLength = content + " ";
            if (labelLength.trim().length == 2) {
				labelClass = 'wideMapLocationLabel';
            }
            else if (labelLength.trim().length == 3) {
				labelClass = 'vwideMapLocationLabel';
            }
        }
        if (locationType == 'hospital-emergency') {    
            content = '';
        }

        var labelStyling = {opacity: 0.75};
        var zIndex = LOCATIONFINDER.markerCount;
        if (!isNaN(content)) {
            var zIndex = content*5;
            //labelStyling = {opacity: 0.75, zIndex: zIndex };
            labelStyling['z-index'] = zIndex;
        }

        var newmarker = new MarkerWithLabel({
            position: latLng,
            map: map,
            labelContent: content,
            labelClass: labelClass,
            labelAnchor: new google.maps.Point(22,0),
            labelStyle: labelStyling,
            labelInBackground: false
        });
        newmarker.setZIndex(zIndex);

        if (locationType == 'primary') {
           	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-location-list-white-pin.png');
        }
        else if (locationType == 'urgent') {
        	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-location-list-white-pin.png');
        }
        else if (locationType == 'specialty') {
        	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-location-list-white-pin.png');
        }
        else if (locationType == 'hospital-emergency') {
        	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-hospital-location-list-pin.png');
        }
        else if (locationType == 'affiliate') {
        	//newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-pin-white.png');
        	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-location-list-white-pin.png');
        }
        else {
        	newmarker.setIcon('/content/dam/nemours/responsive/image/locationFinder/map-generic-pin-white.png');
        }

        if (funct) {
            google.maps.event.addListener(newmarker, 'click', funct);
        }
        else if (infoWindow) {
            newmarker.addListener('click', function() {
              for (var w=0;w<LOCATIONFINDER.infoWindowList.length;w++) {
                  LOCATIONFINDER.infoWindowList[w].close();
              }
              infoWindow.open(map, newmarker);
            });
            LOCATIONFINDER.infoWindowList.push(infoWindow);
        }
    },

    convertToMarkerWithLabel: function(location, title, content, funct) {
        try {
            LOCATIONFINDER.geoCoder.geocode( { 'address': location }, function (results, status) {
                try {
                    if (status == google.maps.GeocoderStatus.OK) {
                        LOCATIONFINDER.createMarkerWithLabel(results[0].geometry.location, 'mapLocationLabel', title, content, funct, null, null);
                    }
                    else {
                        console.log("Unable to Find Location:" +location);
                    }
                }
                catch (Exception) {
                }
            });
        }
        catch (Exception) {
        }
    },

    bubbleSortLocationTitle: function(array) {
  		var swapped;
  		do {
    		swapped = false;
    		for(var i = 0; i < array.length; i++) {
	            if(array[i] && array[i + 1] && array[i].locationTitle > array[i + 1].locationTitle) {
			        swap(array, i, i + 1);
        			swapped = true;
     			 }
		    }
  		} while(swapped);
  		return array;
	},

    sortLocationsByCityState: function() {
        var swapped;
        do {
            swapped = false;
            for (var i=0; i < LOCATIONFINDER.locationList.length-1; i++) {
                if (LOCATIONFINDER.locationList[i].locationCity > LOCATIONFINDER.locationList[i+1].locationCity) {
                    var temp = LOCATIONFINDER.locationList[i];
                    LOCATIONFINDER.locationList[i] = LOCATIONFINDER.locationList[i+1];
                    LOCATIONFINDER.locationList[i+1] = temp;
                    swapped = true;
                }
            }
        } while (swapped);
    },    

    sortLocationsByDistance: function() {
        if (LOCATIONFINDER.locationList.length > 1) {
			var swapped;
            do {
                swapped = false;
                for (var i=0; i < LOCATIONFINDER.locationList.length-1; i++) {
                    var distanceFromUser = LOCATIONFINDER.getDistanceFromUser(LOCATIONFINDER.locationList[i].locationLatitude, LOCATIONFINDER.locationList[i].locationLongitude);
                    LOCATIONFINDER.locationList[i].distanceFromUser = distanceFromUser;
                    if (distanceFromUser > LOCATIONFINDER.getDistanceFromUser(LOCATIONFINDER.locationList[i+1].locationLatitude,LOCATIONFINDER.locationList[i+1].locationLongitude)) {
                        var temp = LOCATIONFINDER.locationList[i];
                        LOCATIONFINDER.locationList[i] = LOCATIONFINDER.locationList[i+1];
                        LOCATIONFINDER.locationList[i+1] = temp;
                        swapped = true;
                    }
                }
            } while (swapped);
            var distanceFromUser = LOCATIONFINDER.getDistanceFromUser(LOCATIONFINDER.locationList[LOCATIONFINDER.locationList.length-1].locationLatitude, LOCATIONFINDER.locationList[LOCATIONFINDER.locationList.length-1].locationLongitude);
            LOCATIONFINDER.locationList[LOCATIONFINDER.locationList.length-1].distanceFromUser = distanceFromUser;

        }
        else {
            if (LOCATIONFINDER.locationList[0].locationLatitude && LOCATIONFINDER.locationList[0].locationLongitude) {
              var distanceFromUser = LOCATIONFINDER.getDistanceFromUser(LOCATIONFINDER.locationList[0].locationLatitude, LOCATIONFINDER.locationList[0].locationLongitude);
              LOCATIONFINDER.locationList[0].distanceFromUser = distanceFromUser;
            }
            else {
              LOCATIONFINDER.locationList[0].distanceFromUser = 1;
            }
        }
    }

};
