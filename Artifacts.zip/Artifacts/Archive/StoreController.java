package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Store;
import com.saturnnight.dungeonbot.service.StoreService;

@RestController
@RequestMapping(value = "/stores")
@PreAuthorize("isAuthenticated()")
public class StoreController {

	@Autowired
	StoreService storeService;

	@RequestMapping(method = RequestMethod.POST)
	public Store createStore(@RequestBody Store store) {
		return storeService.save(store);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Store updateStore(@PathVariable("id") String id, @RequestBody Store store) {
		return storeService.save(store);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteStore(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			storeService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete store.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete store.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Store getStore(@PathVariable("id") long id) {
		return this.storeService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Store> getStores( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Store> storesPageList = storeService.findAll(sort, offset, count);
		return storesPageList;
	}

}
