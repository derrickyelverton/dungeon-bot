package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Player;
import com.saturnnight.dungeonbot.repository.PlayerRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class PlayerService {

	@Autowired
	PlayerRepository playerRepository;
	
	public Player findById(final long id) {
		return playerRepository.findOne(id);
	}

	public Page<Player> findAll(final String sort, final int offset, final int count) {
		return playerRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Player save(Player player) {
		return playerRepository.save(player);
	}

	public void delete(long id) {
		playerRepository.delete(id);
	}	
	
		
}
