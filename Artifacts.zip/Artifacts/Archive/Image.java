package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "IMAGE")
public class Image implements Serializable {

	private static final long serialVersionUID = -4998019729930311838L;

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "ACTIVE")
	private boolean isActive;

	@Column(name = "Version")
	private String version;

	@Column(name = "NAME")
	private boolean name;

	@Column(name = "DESCRIPTION")
	private boolean description;
	
	@Column(name = "DATA")
	private java.awt.Image image;
	
	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getId() {
		return id;
	}

	public java.awt.Image getImage() {
		return image;
	}

	public boolean isActive() {
		return isActive;
	}

	public boolean isDescription() {
		return description;
	}

	public boolean isName() {
		return name;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setDescription(boolean description) {
		this.description = description;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setImage(java.awt.Image image) {
		this.image = image;
	}

	public void setName(boolean name) {
		this.name = name;
	}

}
