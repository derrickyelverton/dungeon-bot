package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SCENE")
public class Scene implements Serializable {

	private static final long serialVersionUID = 3708972179424384736L;

//	@ManyToMany(fetch = FetchType.EAGER)
//	@JoinTable(name = "SCENE_HEATMAPS")
//	private List<Background> heapMaps;
		
//	@ManyToMany(fetch = FetchType.EAGER)
//	@JoinTable(name = "SCENE_BACKGROUNDS")
//	private List<Background> backgrounds;
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "BACKGROUND_ID")
	private Background background;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "SCENE_BADGUYS")
	private List<Sprite> badguys;	

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;	
	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "HEATMAP_ID")
	private Background heatMap;

	@Id
	@Column(name = "ID")
	private Long id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "SCENE_ITEMS")
	private List<Sprite> items;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "SCENE_STORES")
	private List<Store> stores;
	
	public Background getBackground() {
		return background;
	}

	public List<Sprite> getBadguys() {
		return badguys;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Background getHeatMap() {
		return heatMap;
	}

	public Long getId() {
		return id;
	}

	public List<Sprite> getItems() {
		return items;
	}

	public List<Store> getStores() {
		return stores;
	}

	public void setBackground(Background background) {
		this.background = background;
	}

	public void setBadguys(List<Sprite> badguys) {
		this.badguys = badguys;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setHeatMap(Background heatMap) {
		this.heatMap = heatMap;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setItems(List<Sprite> items) {
		this.items = items;
	}

	public void setStores(List<Store> stores) {
		this.stores = stores;
	}
}
