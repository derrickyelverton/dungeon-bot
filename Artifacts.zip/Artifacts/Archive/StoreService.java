package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Store;
import com.saturnnight.dungeonbot.repository.StoreRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class StoreService {

	@Autowired
	StoreRepository storeRepository;
	
	public Store findById(final long id) {
		return storeRepository.findOne(id);
	}

	public Page<Store> findAll(final String sort, final int offset, final int count) {
		return storeRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Store save(Store store) {
		return storeRepository.save(store);
	}

	public void delete(long id) {
		storeRepository.delete(id);
	}	
	
		
}
