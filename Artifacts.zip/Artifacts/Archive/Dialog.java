package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "DIALOG")
public class Dialog implements Serializable {

	private static final long serialVersionUID = -8908810621676882293L;

	@Column(name = "CONTEXT")
	private String context;
	
	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;
	
	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "MESSAGE")
	private String message;

	@Column(name = "SOURCE")
	private String source;

	@Column(name = "X")
	private Long x;

	@Column(name = "Y")
	private Long y;

	@Column(name = "Z")
	private Long z;

	public String getContext() {
		return context;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getId() {
		return id;
	}

	public String getMessage() {
		return message;
	}

	public String getSource() {
		return source;
	}

	public Long getX() {
		return x;
	}

	public Long getY() {
		return y;
	}

	public Long getZ() {
		return z;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setX(Long x) {
		this.x = x;
	}

	public void setY(Long y) {
		this.y = y;
	}
	public void setZ(Long z) {
		this.z = z;
	}	
	
}
