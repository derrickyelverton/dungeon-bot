package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ROW")
public class Row implements Serializable {

	private static final long serialVersionUID = 3708972179424384736L;

	@Id
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "ROW_NUMBER")
	private Long rowNumber;

	public Long getRowNumber() {
		return rowNumber;
	}

	public void setRowNumber(Long rowNumber) {
		this.rowNumber = rowNumber;
	}

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "ROW_SCENES")
	private List<Scene> scenes;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<Scene> getScenes() {
		return scenes;
	}

	public void setScenes(List<Scene> scenes) {
		this.scenes = scenes;
	}

}
