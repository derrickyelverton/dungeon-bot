package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Background;
import com.saturnnight.dungeonbot.repository.BackgroundRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class BackgroundService {

	@Autowired
	BackgroundRepository backgroundRepository;
	
	public Background findById(final long id) {
		return backgroundRepository.findOne(id);
	}

	public Page<Background> findAll(final String sort, final int offset, final int count) {
		return backgroundRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Background save(Background card) {
		return backgroundRepository.save(card);
	}

	public void delete(long id) {
		backgroundRepository.delete(id);
	}	
	
		
}
