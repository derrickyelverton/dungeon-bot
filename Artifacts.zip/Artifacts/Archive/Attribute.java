package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "ATTRIBUTE")
public class Attribute implements Serializable {

	private static final long serialVersionUID = -5345455519998728687L;

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "ACTIVE")
	private boolean isActive;

	@Column(name = "VERSION")
	private int version;

	@Column(name = "VALUE")
	private String value;
	
	@Column(name = "NAME")
	private String name;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

	public int getVersion() {
		return version;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void setVersion(int version) {
		this.version = version;
	}

}
