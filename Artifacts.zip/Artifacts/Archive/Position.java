package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "POSITION")
public class Position implements Serializable {

	private static final long serialVersionUID = 5915878846563160831L;

	@Column(name = "ELEVATION")
	private Long elevation;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;

	@Column(name = "LATITUDE")	
	private Long latitude;	
	
	@Column(name = "LONGITUDE")
	private Long longitude;

	public Long getElevation() {
		return elevation;
	}

	public void setElevation(Long elevation) {
		this.elevation = elevation;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getLatitude() {
		return latitude;
	}

	public void setLatitude(Long latitude) {
		this.latitude = latitude;
	}

	public Long getLongitude() {
		return longitude;
	}

	public void setLongitude(Long longitude) {
		this.longitude = longitude;
	}

}
