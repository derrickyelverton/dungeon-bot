package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "STORE")
public class Store implements Serializable {

	private static final long serialVersionUID = 1835486130941947373L;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "GOLD")
	private Long gold;

	@Column(name = "HEIGHT")
	private Long height;

	@Id
	@Column(name = "ID")
	private Long id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "STORE_ITEMS_SPRITE")
	private List<Sprite> items;

	@Column(name = "NAME")
	private String name;

	@Column(name = "OFFSET_X")
	private Long offsetX;

	@Column(name = "OFFSET_Y")
	private Long offsetY;

	@Column(name = "SOURCE")
	private String source;

	@Column(name = "SPRITE_TYPE")
	private Long spriteType;

	@Column(name = "START_POSITION_Y")
	private Long startPositionX;

	@Column(name = "START_POSITION_Y")
	private Long startPositionY;

	@Column(name = "WIDTH")
	private Long width;

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getGold() {
		return gold;
	}

	public Long getHeight() {
		return height;
	}

	public Long getId() {
		return id;
	}

	public List<Sprite> getItems() {
		return items;
	}

	public String getName() {
		return name;
	}

	public Long getOffsetX() {
		return offsetX;
	}

	public Long getOffsetY() {
		return offsetY;
	}

	public String getSource() {
		return source;
	}
	public Long getSpriteType() {
		return spriteType;
	}

	public Long getStartPositionX() {
		return startPositionX;
	}
	
	public Long getStartPositionY() {
		return startPositionY;
	}
	
	public Long getWidth() {
		return width;
	}
	
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	public void setGold(Long gold) {
		this.gold = gold;
	}

	public void setHeight(Long height) {
		this.height = height;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public void setItems(List<Sprite> items) {
		this.items = items;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOffsetX(Long offsetX) {
		this.offsetX = offsetX;
	}

	public void setOffsetY(Long offsetY) {
		this.offsetY = offsetY;
	}
	
	public void setSource(String source) {
		this.source = source;
	}
	
	public void setSpriteType(Long spriteType) {
		this.spriteType = spriteType;
	}
	
	public void setStartPositionX(Long startPositionX) {
		this.startPositionX = startPositionX;
	}
	
	public void setStartPositionY(Long startPositionY) {
		this.startPositionY = startPositionY;
	}
	public void setWidth(Long width) {
		this.width = width;
	}	
}
