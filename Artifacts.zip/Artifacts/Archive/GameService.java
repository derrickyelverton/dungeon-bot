package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Game;
import com.saturnnight.dungeonbot.repository.GameRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class GameService {

	@Autowired
	GameRepository gameRepository;
	
	public Game findById(final long id) {
		return gameRepository.findOne(id);
	}

	public Page<Game> findAll(final String sort, final int offset, final int count) {
		return gameRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Game save(Game game) {
		return gameRepository.save(game);
	}

	public void delete(long id) {
		gameRepository.delete(id);
	}	
	
		
}
