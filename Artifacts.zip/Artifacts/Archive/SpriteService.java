package com.saturnnight.dungeonbot.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Inventory;
import com.saturnnight.dungeonbot.jpa.Sprite;
import com.saturnnight.dungeonbot.repository.SpriteRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class SpriteService {

	@Autowired
	SpriteRepository spriteRepository;

	@Autowired
	InventoryService inventoryService;
	
	public Sprite findById(final long id) {
		return spriteRepository.findOne(id);
	}

	public Page<Sprite> findAll(final String sort, final int offset, final int count) {
		return spriteRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Sprite save(Sprite sprite) {
		Sprite result = null;
		try {
			Inventory inventory = new Inventory();
			inventory.setId(null);
			inventory.setGold((long) 0);
			if (sprite.getInventory().getId() > (long)1) {
				Inventory oInventory = inventoryService.findById(sprite.getInventory().getId());
				if (oInventory != null) {
					oInventory.setGold((long) sprite.getInventory().getGold());
					oInventory.setItems(sprite.getInventory().getItems());
				}
			}
			inventoryService.save(inventory);
			result = spriteRepository.save(sprite);
		}
		catch (Exception e) {
			Inventory inventory = new Inventory();
			inventory.setId(null);
			inventory.setGold((long) 0);
			inventory.setItems(new ArrayList<Sprite>());
			inventoryService.save(inventory);
			result = spriteRepository.save(sprite);
		}
		return result;
	}

	public void delete(long id) {
		spriteRepository.delete(id);
	}	
	
		
}
