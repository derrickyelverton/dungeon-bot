package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "PROFILE")
public class Profile implements Serializable {

	private static final long serialVersionUID = 2438784504500093485L;

	@Id
	@Column(name = "ID")
	private Long id;

	@Column(name = "PLAYER_ID")
	private Long playerId;

	@Column(name = "HIT_POINT")
	private Long hitPoint;

	@Column(name = "HAND_COUNT")
	private Long handCount;

	@Column(name = "STONE_COUNT")
	private Long stoneCount;

	@Column(name = "DECK_COUNT")
	private Long deckCount;

	@Column(name = "LIGHT_COUNT")
	private Long lightCount;

	@Column(name = "FIRE_COUNT")
	private Long fireCount;

	@Column(name = "WATER_COUNT")
	private Long waterCount;
	
	@Column(name = "WIND_COUNT")
	private Long windCount;

	@Column(name = "DARK_COUNT")
	private Long darkCount;
	
	@Column(name = "VOID_COUNT")
	private Long voidCount;

	@Column(name = "MOON_COUNT")
	private Long moonCount;

	@Temporal(TemporalType.DATE)	
	@Column(name = "CREATED_ON")
	private Date createdOn;

	public Date getCreatedOn() {
		return createdOn;
	}

	public Long getDarkCount() {
		return darkCount;
	}

	public Long getDeckCount() {
		return deckCount;
	}

	public Long getFireCount() {
		return fireCount;
	}

	public Long getHandCount() {
		return handCount;
	}

	public Long getHitPoint() {
		return hitPoint;
	}

	public Long getId() {
		return id;
	}

	public Long getLightCount() {
		return lightCount;
	}

	public Long getMoonCount() {
		return moonCount;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public Long getStoneCount() {
		return stoneCount;
	}

	public Long getVoidCount() {
		return voidCount;
	}

	public Long getWaterCount() {
		return waterCount;
	}

	public Long getWindCount() {
		return windCount;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setDarkCount(Long darkCount) {
		this.darkCount = darkCount;
	}

	public void setDeckCount(Long deckCount) {
		this.deckCount = deckCount;
	}

	public void setFireCount(Long fireCount) {
		this.fireCount = fireCount;
	}

	public void setHandCount(Long handCount) {
		this.handCount = handCount;
	}

	public void setHitPoint(Long hitPoint) {
		this.hitPoint = hitPoint;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setLightCount(Long lightCount) {
		this.lightCount = lightCount;
	}

	public void setMoonCount(Long moonCount) {
		this.moonCount = moonCount;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public void setStoneCount(Long stoneCount) {
		this.stoneCount = stoneCount;
	}

	public void setVoidCount(Long voidCount) {
		this.voidCount = voidCount;
	}			

	public void setWaterCount(Long waterCount) {
		this.waterCount = waterCount;
	}

	public void setWindCount(Long windCount) {
		this.windCount = windCount;
	}

}
