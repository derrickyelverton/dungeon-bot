package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.Background;
import com.saturnnight.dungeonbot.service.BackgroundService;

@RestController
@RequestMapping(value = "/backgrounds")
@PreAuthorize("isAuthenticated()")
public class BackgroundController {

	@Autowired
	BackgroundService backgroundService;

	@RequestMapping(method = RequestMethod.POST)
	public Background createBackground(@RequestBody Background background) {
		return backgroundService.save(background);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public Background updateBackground(@PathVariable("id") String id, @RequestBody Background background) {
		return backgroundService.save(background);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteBackground(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			backgroundService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete background.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete background.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public Background getBackground(@PathVariable("id") long id) {
		return this.backgroundService.findById(id);
	}
	
	@RequestMapping(method = RequestMethod.GET)
	public Page<Background> getBackgrounds( @RequestParam("count") int count, @RequestParam("filter") String filter, @RequestParam("offset") int offset, @RequestParam("sort") String sort ) {
		Page<Background> backgroundsPageList = backgroundService.findAll(sort, offset, count);
		return backgroundsPageList;
	}

}
