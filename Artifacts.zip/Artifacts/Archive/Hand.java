package com.saturnnight.dungeonbot.jpa;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "HAND")
public class Hand implements Serializable {

	private static final long serialVersionUID = -2263615907598572619L;

	@Id
	@Column(name = "ID")
	private Long id;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "HAND_CARD")
	private List<Card> cards;		

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "PLAYER_ID")
	private Player player;			

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "GAME_ID")
	private Game game;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

//	public List<Card> getCards() {
//		return cards;
//	}

//	public void setCards(List<Card> cards) {
//		this.cards = cards;
//	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}			
	
}
