package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.Deck;
import com.saturnnight.dungeonbot.jpa.Inventory;
import com.saturnnight.dungeonbot.repository.InventoryRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class InventoryService {

	@Autowired
	InventoryRepository inventoryRepository;
	
	public Inventory findById(final long id) {
		return inventoryRepository.findOne(id);
	}

	public Page<Inventory> findAll(final String sort, final int offset, final int count) {
		return inventoryRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public Inventory save(Inventory inventory) {
		return inventoryRepository.save(inventory);
	}

	public void delete(long id) {
		inventoryRepository.delete(id);

	}	
	
		
}
