package com.saturnnight.dungeonbot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.EventType;
import com.saturnnight.dungeonbot.repository.EventTypeRepository;
import com.saturnnight.dungeonbot.util.JsonUtil;

@Service
public class EventTypeService {

	@Autowired
	EventTypeRepository eventTypeRepository;

	public EventType findById(final long id) {
		return eventTypeRepository.findOne(id);
	}
	
	public Page<EventType> findAll(final String sort, final int offset, final int count) {
		return eventTypeRepository.findAll(JsonUtil.createPageRequest(sort, offset, count));
	}

	public EventType save(EventType eventType) {
		return eventTypeRepository.save(eventType);
	}

	public void delete(long id) {
		eventTypeRepository.delete(id);
	}	
		
}
