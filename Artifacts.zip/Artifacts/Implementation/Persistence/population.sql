INSERT INTO USER (
 ID,         
 ACTIVE,     
 FIRST_NAME, 
 LAST_NAME,   
 PHONE,       
 EMAIL,       
 USER_NAME,   
 PASSWORD,    
 DESCRIPTION
) VALUES (
1,
1,
'Derrick',
'Yelverton',
'904-228-4403',
'derrickyelverton@gmail.com',
'saturn',
'test',
'i rule the world'
);

INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (1, 'KINGS QUEST SCENE', 'game_lib/img/Background1.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (2, 'KINGS QUEST SCENE', 'game_lib/img/Background2.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (3, 'KINGS QUEST SCENE', 'game_lib/img/Background3.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (4, 'KINGS QUEST SCENE', 'game_lib/img/Background4.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (5, 'KINGS QUEST SCENE', 'game_lib/img/Background5.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (6, 'KINGS QUEST SCENE', 'game_lib/img/Background6.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (7, 'KINGS QUEST SCENE', 'game_lib/img/Background7.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (8, 'KINGS QUEST SCENE', 'game_lib/img/Background8.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (9, 'KINGS QUEST SCENE', 'game_lib/img/Background9.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (10, 'KINGS QUEST SCENE', 'game_lib/img/Background10.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (11, 'KINGS QUEST SCENE', 'game_lib/img/Background11.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (12, 'KINGS QUEST SCENE', 'game_lib/img/Background12.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (13, 'KINGS QUEST SCENE', 'game_lib/img/Background13.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (14, 'KINGS QUEST SCENE', 'game_lib/img/Background14.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (15, 'KINGS QUEST SCENE', 'game_lib/img/Background15.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (16, 'KINGS QUEST SCENE', 'game_lib/img/Background16.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (17, 'KINGS QUEST SCENE', 'game_lib/img/Background17.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (18, 'KINGS QUEST SCENE', 'game_lib/img/Background18.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (19, 'KINGS QUEST SCENE', 'game_lib/img/Background19.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (20, 'KINGS QUEST SCENE', 'game_lib/img/Background20.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (21, 'KINGS QUEST SCENE', 'game_lib/img/Background21.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (22, 'KINGS QUEST SCENE', 'game_lib/img/Background22.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (23, 'KINGS QUEST SCENE', 'game_lib/img/Background23.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (24, 'KINGS QUEST SCENE', 'game_lib/img/Background24.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (25, 'KINGS QUEST SCENE', 'game_lib/img/Background25.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (26, 'KINGS QUEST SCENE', 'game_lib/img/Background26.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (27, 'KINGS QUEST SCENE', 'game_lib/img/Background27.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (28, 'KINGS QUEST SCENE', 'game_lib/img/Background28.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (29, 'KINGS QUEST SCENE', 'game_lib/img/Background29.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (30, 'KINGS QUEST SCENE', 'game_lib/img/Background30.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (31, 'KINGS QUEST SCENE', 'game_lib/img/Background31.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (32, 'KINGS QUEST SCENE', 'game_lib/img/Background32.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (33, 'KINGS QUEST SCENE', 'game_lib/img/Background33.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (34, 'KINGS QUEST SCENE', 'game_lib/img/Background34.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (35, 'KINGS QUEST SCENE', 'game_lib/img/Background35.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (36, 'KINGS QUEST SCENE', 'game_lib/img/Background36.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (37, 'KINGS QUEST SCENE', 'game_lib/img/Background37.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (38, 'KINGS QUEST SCENE', 'game_lib/img/Background38.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (39, 'KINGS QUEST SCENE', 'game_lib/img/Background39.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (40, 'KINGS QUEST SCENE', 'game_lib/img/Background40.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (41, 'KINGS QUEST SCENE', 'game_lib/img/Background41.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (42, 'KINGS QUEST SCENE', 'game_lib/img/Background42.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (43, 'KINGS QUEST SCENE', 'game_lib/img/Background43.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (44, 'KINGS QUEST SCENE', 'game_lib/img/Background44.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (45, 'KINGS QUEST SCENE', 'game_lib/img/Background45.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (46, 'KINGS QUEST SCENE', 'game_lib/img/Background46.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (47, 'KINGS QUEST SCENE', 'game_lib/img/Background47.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (48, 'KINGS QUEST SCENE', 'game_lib/img/Background48.png');

INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (49, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap1.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (50, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap2.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (51, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap3.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (52, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap4.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (53, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap5.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (54, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap6.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (55, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap7.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (56, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap8.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (57, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap9.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (58, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap10.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (59, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap11.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (60, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap12.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (62, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap13.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (63, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap14.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (64, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap15.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (65, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap16.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (66, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap17.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (67, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap18.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (68, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap19.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (69, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap20.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (70, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap21.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (71, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap22.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (72, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap23.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (73, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap24.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (74, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap25.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (75, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap26.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (76, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap27.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (77, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap28.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (78, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap29.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (79, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap30.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (80, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap31.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (81, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap32.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (82, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap33.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (83, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap34.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (84, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap35.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (85, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap36.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (86, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap37.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (87, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap38.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (88, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap39.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (89, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap40.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (90, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap41.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (91, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap42.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (92, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap43.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (93, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap44.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (94, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap45.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (95, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap46.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (96, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap47.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (97, 'KINGS QUEST SCENE HEATMAP', 'game_lib/img/BackgroundHeatMap48.png');


INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (98, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel1.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (99, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel2.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (100, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel3.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (101, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel4.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (102, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel5.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (103, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel6.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (104, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel7.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (105, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel8.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (106, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel9.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (107, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel10.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (108, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel11.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (109, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel12.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (110, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel13.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (112, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel14.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (113, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel15.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (114, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel16.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (115, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel17.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (116, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel18.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (117, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel19.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (118, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel20.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (119, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel21.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (120, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel22.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (121, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel23.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (122, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel24.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (123, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel25.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (124, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel26.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (125, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel27.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (126, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel28.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (127, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel29.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (128, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel30.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (129, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel31.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (130, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel32.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (131, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel33.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (132, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel34.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (133, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel35.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (134, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel36.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (135, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel37.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (136, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel38.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (137, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel39.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (138, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel40.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (139, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel41.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (140, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel42.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (141, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel43.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (142, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel44.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (143, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel45.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (144, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel46.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (145, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel47.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (146, 'GAUNTLET SCENE', 'game_lib/img/backgroundLevel48.png');

INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (147, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel1.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (148, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel2.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (149, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel3.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (150, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel4.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (151, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel5.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (152, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel6.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (153, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel7.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (154, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel8.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (155, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel9.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (156, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel10.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (157, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel11.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (158, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel12.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (159, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel13.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (160, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel14.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (161, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel15.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (162, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel16.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (163, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel17.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (164, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel18.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (165, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel19.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (166, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel20.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (167, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel21.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (168, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel22.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (169, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel23.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (170, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel24.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (171, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel25.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (172, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel26.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (173, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel27.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (174, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel28.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (175, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel29.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (176, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel30.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (177, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel31.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (178, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel32.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (179, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel33.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (180, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel34.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (181, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel35.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (182, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel36.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (183, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel37.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (184, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel38.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (185, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel39.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (186, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel40.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (187, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel41.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (188, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel42.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (189, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel43.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (190, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel44.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (191, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel45.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (192, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel46.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (193, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel47.png');
INSERT INTO BACKGROUND (ID, NAME, PATH) VALUES (194, 'GAUNTLET SCENE HEATMAP', 'game_lib/img/heatMapLevel48.png');
 
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (0, 'Weapon', 'game_lib/img/weapon.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (1, 'Chest', 'game_lib/img/chest.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (2, 'Pants', 'game_lib/img/pants.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (3, 'Shoes', 'game_lib/img/shoes.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (4, 'Gloves', 'game_lib/img/gloves.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (5, 'Ring', 'game_lib/img/ring.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (6, 'Necklace', 'game_lib/img/necklace.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (7, 'Item', 'game_lib/img/item.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (8, 'Potion', 'game_lib/img/potion.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (9, 'Keys', 'game_lib/img/keys.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (10, 'Pawn', 'game_lib/img/pawn.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (11, 'Boss', 'game_lib/img/boss.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (12, 'Hero', 'game_lib/img/hero.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (13, 'EasterEgg', 'game_lib/img/easteregg.png');
INSERT INTO SPRITE_TYPE (ID, NAME, PATH) VALUES (14, 'Store', 'game_lib/img/weapon.png');

--INSERT INTO DIALOG (ID, X, Y, Z, CONTENT, MESSAGE, SOURCE) VALUES ();
--             src,                      width, height, offsetX, offsetY, frames, duration, spriteType, startPositionX, startPositionY, health, experience, level, healthOverlayShown, isGold, gold, name
--new Sprite('game_lib/img/catfolk.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 475, 100, 1, 10),
--new Sprite('game_lib/img/dhampir.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 180, 200, 1, 10),
--new Sprite('game_lib/img/drow.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 595, 300, 1, 10),
--new Sprite('game_lib/img/fetchling.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Boss, 800, 330, 1, 20)
--new Sprite('game_lib/img/goblin.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 705, 120, 1, 10),
--new Sprite('game_lib/img/orc.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 620, 80, 1, 10),
--new Sprite('game_lib/img/dragon.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 435, 120, 1, 10),
--new Sprite('game_lib/img/halfling.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 340, 140, 1, 10),
--new Sprite('game_lib/img/elf.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 135, 180, 1, 10),
--new Sprite('game_lib/img/dwarf.png', 32, 32, 0, 128, 4, 0, Constants.SpriteType.Pawn, 160, 220, 1, 10)

-- ORIGINAL BADGUYS

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (1, 'Cat Folk', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/catfolk.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (2, 'Dhampir', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dhampir.png', 10,
                    180, 200);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (3, 'Drow', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/drow.png', 10,
                    595, 300);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (4, 'Fetchling', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/fetchling.png', 10,
                    800, 330);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (5, 'Goblin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/goblin.png', 10,
                    705, 120);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (6, 'Orc', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/orc.png', 10,
                    620, 80);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (7, 'Dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dragon.png', 10,
                    435, 120);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (8, 'Halfling', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/halfling.png', 10,
                    340, 140);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (9, 'Elf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/elf.png', 10,
                    135, 180);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (10, 'Dwarf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dwarf.png', 10,
                    135, 180);
                                   

-- ACTIONS

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (11, 'Fireball', 0, 10, 5, 0, 1, 0,
                    32, 32, 0, 1, 0, 0, 'game_lib/img/fireball.png', 10,
                    135, 180);                    
                    
-- HERO
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (12, 'Knight', 0, 0, 4, 0, 100, 1,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/knight.png', 12,
                    400, 400); 
-- WEAPONS
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (13, 'Sword', 0, 0, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sword.png', 0,
                    360, 160);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (14, 'Sword of Fire', 0, 0, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/swordOfFire.png', 0,
                    400, 160);                    

--  ITEMS

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (15, 'Easter Egg', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/key.png', 13,
                    450, 100);
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (16, 'Key', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/key.png', 7,
                    500, 100);
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (17, 'Chest', 0, 10, 4, 1000, 1, 0,
                    32, 32, 1, 1, 0, 128, 'game_lib/img/chest.png', 7,
                    525, 100);
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (18, 'Money Bag', 0, 10, 4, 500, 1, 0,
                    32, 32, 1, 1, 0, 128, 'game_lib/img/moneybag.png', 7,
                    550, 100);                    

--D N D CHARACTERS

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (19, 'Aarakocra', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/aarakocra.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (20, 'Aboleth', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/aboleth.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (21, 'Ankheg', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/ankheg.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (22, 'Arcane', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/arcane.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (23, 'Argos', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/rgos.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (24, 'Aurumvorax', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/aurumvorax.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (25, 'Baatezu', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/Baatezu.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (26, 'Banshee', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/banshee.png', 10,
                    475, 100);  

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (27, 'Basilisk', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/basilisk.png', 10,
                    475, 100);  

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (28, 'Bat', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bat.png', 10,
                    475, 100);                    

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (29, 'Bear', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bear.png', 10,
                    475, 100);                    

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (30, 'Beetle', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/beetle.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (31, 'Behir', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/behir.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (32, 'Beholder and beholder-kin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/beholder.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (33, 'Bird', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bird.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (34, 'Brain mole', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/brainmole.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (35, 'Broken one', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/brokenone.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (36, 'Brownie', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/brownie.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (37, 'Bugbear', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bugbear.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (38, 'Bulette', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bulette.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (39, 'Bullywug', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/bullywug.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (40, 'Carrion crawler', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/carrioncrawler.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (41, 'Cat, great', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/greatcat.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (42, 'Cat, small', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/smallcat.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (43, 'Catoblepas', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/catoblepas.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (44, 'Cave fisher', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cavefisher.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (45, 'Centaur', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/centaur.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (46, 'Centipede', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/centipede.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (47, 'Chimera', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chimera.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (48, 'Cloaker', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cloaker.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (49, 'Cockatrice', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cockatrice.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (50, 'Couatl', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/couatl.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (51, 'Crabman', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/crabman.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (52, 'Crawling claw', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/crawlingclaw.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (53, 'Crocodile', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/crocodile.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (54, 'Crustacean, giant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giantcrustacean.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (55, 'Crypt thing', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cryptthing.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (56, 'Death knight', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/deathknight.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (57, 'Deepspawn', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/deepspawn.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (58, 'Dinosaur', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dinosaur.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (59, 'Displacer beast', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/displacerbeast.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (60, 'Dog', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dog.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (61, 'Dog, moon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/moondog.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (62, 'Dolphin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dolphin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (63, 'Doppleganger', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/doppleganger.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (64, 'Dracolich', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dracolich.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (65, 'Dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (66, 'Dragon, chromatic: black dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chromaticblackdragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (67, 'Dragon, chromatic: blue dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chromaticbluedragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (68, 'Dragon, chromatic: green dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chromaticgreendragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (69, 'Dragon, chromatic: red dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chromaticreddragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (70, 'Dragon, chromatic: white dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/chromaticwhitedragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (71, 'Dragon, gem: amethyst dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gemamethystdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (72, 'Dragon, gem: crystal dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gemcrystaldragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (73, 'Dragon, gem: emerald dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gememeralddragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (74, 'Dragon, gem: topaz dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gemtopazdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (75, 'Dragon, gem: topaz dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gemtopazdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (76, 'Dragon, metallic: brass dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/metallicbrassdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (77, 'Dragon, metallic: bronze dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/metallicbronzedragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (78, 'Dragon, metallic: copper dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/metalliccopperdragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (79, 'Dragon, metallic: gold dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/metallicgolddragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (80, 'Dragon, metallic: silver dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/metallicsilverdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (81, 'Brown dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/browndragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (82, 'Cloud dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/clouddragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (83, 'Deep dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/deepdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (84, 'Mercury dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mercurydragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (85, 'Mist dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mistdragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (86, 'Shadow dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/shadowdragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (87, 'Steel dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/steeldragon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (88, 'Yellow dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/yellowdragon.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (89, 'Dragon turtle', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dragonturtle.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (90, 'Dragonet, faerie dragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/faeriedragondragonet.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (91, 'dragonetfiredrake', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/firedrakedragonet.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (92, 'Dragonet, pseudodragon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/pseudodragondragonet.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (93, 'Dragonne', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dragonne.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (94, 'Dryad', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dryad.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (95, 'Dwarf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dwarf.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (96, 'Elemental', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/elemental.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (97, 'Elemental, air kin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/airkinelemental.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (98, 'Elemental, earth kin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/earthkinelemental.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (99, 'Elemental, fire-kin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/firekinelemental.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (100, 'Elemental, water kin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/waterkinelemental.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (101, 'Elemental, composite', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/compositeelemental.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (102, 'Elephant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/elephant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (103, 'Elf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/elf.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (104, 'Elf, aquatic', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/aquaticelf.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (105, 'Elf, drow', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/drowelf.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (106, 'Ettercap', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/Ettercap.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (107, 'Eyewing', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/eyewing.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (108, 'Feyr', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/feyr.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (109, 'Fish', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/fish.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (110, 'Frog', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/frog.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (111, 'Fungus', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/fungus.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (112, 'Galeb duhr', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/galebduhr.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (113, 'Gargantua', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gargantua.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (114, 'Gargoyle', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gargoyle.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (115, 'Genie', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/genie.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (116, 'Ghost', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/ghost.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (117, 'Ghoul', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/ghoul.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (118, 'Giant, cloud', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cloudgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (119, 'Giant, cyclops', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/cyclopsgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (120, 'Giant, desert', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/desertgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (121, 'Giant, ettin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/ettingiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (122, 'Giant, firbolg', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/firbolggiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (123, 'Giant, fire', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/firegiant.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (124, 'Giant, fog', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/foggiant.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (125, 'Giant, formorian', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/formoriangiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (126, 'Giant, frost', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/frostgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (127, 'Giant, hill', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hillgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (128, 'Giant, jungle', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/junglegiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (129, 'Giant, mountain', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mountaingiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (130, 'Giant, reef', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/reefgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (131, 'Giant, stone', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/stonegiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (132, 'Giant, storm', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/stormgiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (133, 'Giant, verbeeg', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/verbeeggiant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (134, 'Giant, wood', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/woodgiant.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (135, 'Gibberling', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gibberling.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (136, 'Giff', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giff.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (137, 'Gith', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gith.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (138, 'Gith, Pirate', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/pirategith.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (139, 'Githyanki', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/githyanki.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (140, 'Githzerai', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/githzerai.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (141, 'Gloomwing', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gloomwing.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (142, 'Gnoll', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gnoll.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (143, 'Gnome', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gnome.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (144, 'Gnome, spriggan', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/spriggangnome.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (145, 'Goblin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/goblin.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (146, 'Golem', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/golem.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (147, 'Gorgon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gorgon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (148, 'Grell', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/grell.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (149, 'Gremlin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/gremlin.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (150, 'Gremlin, jermlaine', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/jermlainegremlin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (151, 'Griffon', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/griffon.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (152, 'Grimlock', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/grimlock.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (153, 'Grippli', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/grippli.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (154, 'Hag', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hag.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (155, 'Halfling', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/halfling.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (156, 'Harpy', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/harpy.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (157, 'Hatori', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hatori.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (158, 'Haunt', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/haunt.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (159, 'Hell hound', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hellhound.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (160, 'Heucuva', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/heucuva.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (161, 'Hippocampus', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hippocampus.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (162, 'Hippogriff', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hippogriff.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (163, 'Hobgoblin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hobgoblin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (164, 'Homonculus', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/homonculus.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (165, 'Hook horror', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hookhorror.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (166, 'Horse', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/horse.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (167, 'Human', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/human.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (168, 'Hydra', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/hydra.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (169, 'Imp', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/imp.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (170, 'Imp, mephit', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mephitimp.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (171, 'Insect', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/insect.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (172, 'Insect swarm', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/insectswarm.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (173, 'Intellect devourer', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/intellectdevourer.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (174, 'Invisible stalker', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/invisiblestalker.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (175, 'Ixitxachitl', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/ixitxachitl.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (176, 'Jackalwere', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/jackalwere.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (177, 'Kenku', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/kenku.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (178, 'Ki-rin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/kirin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (179, 'Kirre', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/kirre.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (180, 'Kobold', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/kobold.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (181, 'Kuo-toa', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/kuotoa.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (182, 'Lamia', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lamia.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (183, 'Lammasu', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lammasu.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (184, 'Leech', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/leech.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (185, 'Leprechaun', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/leprechaun.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (186, 'Leucrotta', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/leucrotta.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (187, 'Lich', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lich.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (188, 'Living wall', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/livingwall.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (189, 'Lizard', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lizard.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (190, 'Lizard man', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lizardman.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (191, 'Locathah', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/locathah.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (192, 'Lurker', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lurker.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (193, 'Lycanthrope', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/lycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (194, 'Lycanthrope, seawolf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/seawolflycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (195, 'Lycanthrope, werebat', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/werebatlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (196, 'Lycanthrope, wereboar', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wereboarlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (197, 'Lycanthrope, werefox', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/werefoxlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (198, 'Lycanthrope, wererat', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wereratlycanthrope.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (199, 'Lycanthrope, wereraven', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wereravenlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (200, 'Lycanthrope, weretiger', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/weretigerlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (201, 'Lycanthrope, weretiger', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/weretigerlycanthrope.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (202, 'Lycanthrope, werewolf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/werewolflycanthrope.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (203, 'Mammal', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mammal.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (204, 'Mammal, herd', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/herdmammal.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (205, 'Mammal, small', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/smallmammal.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (206, 'Manscorpion', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/manscorpion.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (207, 'Manticore', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/manticore.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (208, 'Medusa', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/medusa.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (209, 'Medusa, maedar', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/maedarmedusa.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (210, 'Merman', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/merman.png', 10,
                    475, 100); 
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (211, 'Mimic', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mimic.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (212, 'Mind flayer (illithid)', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mindflayer.png', 10,
                    475, 100); 
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (213, 'Minotaur', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/minotaur.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (214, 'Mist, crimson death', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/deathcrimsonmist.png', 10,
                    475, 100); 
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (215, 'Mist, vampiric', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/vampiricmist.png', 10,
                    475, 100); 

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (216, 'Mold', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mold.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (217, 'Mold man (vegepygmy)', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/moldman.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (218, 'Mongrelman', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mongrelman.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (219, 'Morkoth', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/morkoth.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (219, 'MudmaMuckdwellern', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mudmamuckdwellern.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (220, 'Mudman', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/mudman.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (221, 'Mummy, greater', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/greatermummy.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (222, 'Myconid', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/myconid.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (223, 'Naga', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/naga.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (224, 'Naga, dark', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/darknaga.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (225, 'Neogi', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/neogi.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (226, 'Nightmare', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/nightmare.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (227, 'Nymph', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/nymph.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (228, 'Octopus, giant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giantoctopus.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (229, 'Ogre, half', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/halforc.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (230, 'Ooze, Slime, Jelly', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/oozeslimejelly.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (231, 'Orc', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/orc.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (232, 'Otyugh', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/otyugh.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (233, 'Owlbear', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/owlbear.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (234, 'Pegasus', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/pegasus.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (235, 'Peryton', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/peryton.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (236, 'Phantom', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/phantom.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (237, 'Phoenix', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/phoenix.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (238, 'Piercer', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/piercer.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (239, 'Plant, dangerous', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/dangerousplant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (240, 'Plant, intelligent', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/intelligentplant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (241, 'Poltergeist', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/poltergeist.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (242, 'Pudding, deadly', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/deadlypudding.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (243, 'Quaggoth', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/quaggoth.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (244, 'Rakshasa', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/rakshasa.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (235, 'Rat', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/rat.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (236, 'Remorhaz', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/remorhaz.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (237, 'Revenant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/revenant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (238, 'Roc', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/roc.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (237, 'Roper', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/roper.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (238, 'Rust monster', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/rustmonster.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (239, 'Sahuagin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sahuagin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (240, 'Satyr', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/satyr.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (241, 'Scorpion', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/scorpion.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (242, 'Sea lion', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sealion.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (243, 'Selkie', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/selkie.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (244, 'Shadow', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/shadow.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (245, 'Shedu', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/shedu.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (246, 'Sirine', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sirine.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (247, 'Skeleton', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/skeleton.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (248, 'Skeleton, giant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giantskeleton.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (249, 'Skeleton warrior', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/skeletonwarrior.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (250, 'Slaad', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/slaad.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (251, 'Slug, giant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giantslug.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (252, 'Snake', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/snake.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (253, 'Snake, winged', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wingedsnake.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (254, 'Spectre', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/spectre.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (255, 'Sphinx', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sphinx.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (256, 'Spider', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/spider.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (257, 'Sprite', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sprite.png', 10,
                    475, 100);
                                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (258, 'Squid, Giant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/giantsquid.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (259, 'Stirge', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/stirge.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (260, 'Su-monster', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/sumonster.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (261, 'Swanmay', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/swanmay.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (262, 'Tabaxi', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/tabaxi.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (263, 'Tako', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/tako.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (264, 'Tanar ri', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/tanarri.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (265, 'Tarrasque', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/tarrasque.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (266, 'Tasloi', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/tasloi.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (267, 'Thought-eater', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/thoughteater.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (268, 'Thri-kreen', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/thrikreen.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (269, 'Titan', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/titan.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (270, 'Toad', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/toad.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (271, 'Treant', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/treant.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (272, 'Triton', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/triton.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (273, 'Troglodyte', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/troglodyte.png', 10,
                    475, 100);


INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (274, 'Troll', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/troll.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (275, 'Umber Hulk', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/umberhulk.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (276, 'Unicorn', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/unicorn.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (277, 'Urchin', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/urchin.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (278, 'Vampire', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/vampire.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (279, 'Wemic', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/Wemic.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (280, 'Whale', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/whale.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (281, 'Wight', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wight.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (282, 'Will owisp', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/willowisp.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (283, 'Wolf', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wolf.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (284, 'Wolfwere', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wolfwere.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (285, 'Worm', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/worm.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (286, 'Wraith', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wraith.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (287, 'Wyvern', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/wyvern.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (288, 'Xorn', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/xorn.png', 10,
                    475, 100);
                    
INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (289, 'Yeti', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/yeti.png', 10,
                    475, 100);


INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (290, 'Yuan-ti', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/yuanti.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (291, 'Yuan-ti, histachii', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/histachii.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (292, 'Yugoloth, guardian', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/yugoloth.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (293, 'Zaratan', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/zaratan.png', 10,
                    475, 100);

INSERT INTO SPRITE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (294, 'Zombie', 0, 10, 4, 0, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/zombie.png', 10,
                    475, 100);

    
-- STORES
                    
 INSERT INTO STORE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (1, 'Store', 0, 0, 4, 100, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/store.png', 14,
                    200, 120);                     
                    
 INSERT INTO STORE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
                    WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
                    START_POSITION_X, START_POSITION_Y) 
            VALUES (10, 'The Store', 0, 0, 4, 100, 1, 0,
                    32, 32, 0, 1, 0, 128, 'game_lib/img/store.png', 14,
                    200, 120);                                        

--Store('game_lib/img/store.png', 32, 32, 0, 128, Constants.SpriteType.Store, 200, 120, 999, 'The Store', null)],[],[],[],[],[],[],[]],

--INSERT INTO STORE (ID, NAME, DURATION, EXPERIENCE, FRAMES, GOLD, HEALTH, HEALTH_OVERLAY_SHOWN, 
 --                  WIDTH, HEIGHT, IS_GOLD, LEVEL, OFFSET_X, OFFSET_Y, SOURCE, SPRITE_TYPE, 
 --                  START_POSITION_X, START_POSITION_Y) 
  --         VALUES ();

INSERT INTO STORE_ITEM_SPRITE (STORE_ID, SPRITE_ID) VALUES (1, 13);
INSERT INTO STORE_ITEM_SPRITE (STORE_ID, SPRITE_ID) VALUES (1, 14);


INSERT INTO GAME (ID, CANVAS_ID, NAME, DESCRIPTION) VALUES (1, 1, 'Kings Quest X Adventure Game' ,'Kings Quest X Adventure Game');
INSERT INTO GAME (ID, CANVAS_ID, NAME, DESCRIPTION) VALUES (2, 2, 'Gauntlet X Kill', 'Gauntlet X Kill');



INSERT INTO CANVAS (ID, NAME, MODE, WIDTH, HEIGHT, HERO) VALUES (1, 'KINGS QUEST X', 'adventure', 800, 600, 12);
INSERT INTO CANVAS (ID, NAME, MODE, WIDTH, HEIGHT, HERO) VALUES (2, 'GAUNTLET X', 'kill', 800, 600, 12);


INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 1);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 2);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 3);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 4);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 5);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 6);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 7);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 8);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 9);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 10);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 11);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 12);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 13);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 14);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 15);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 16);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 17);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 18);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 19);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 20);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 21);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 22);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 23);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 24);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 25);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 26);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 27);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 28);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 29);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 30);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 31);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 32);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 33);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 34);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 35);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 36);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 37);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 38);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 39);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 40);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 41);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 42);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 43);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 44);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 45);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 46);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 47);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (1, 48);

INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 98);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 99);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 100);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 101);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 102);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 103);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 104);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 105);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 106);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 107);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 108);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 109);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 110);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 111);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 112);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 113);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 114);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 115);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 116);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 117);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 118);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 119);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 120);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 121);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 122);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 123);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 124);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 125);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 126);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 127);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 128);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 129);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 130);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 132);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 133);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 134);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 135);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 136);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 137);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 138);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 139);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 140);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 141);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 142);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 143);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 144);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 145);
INSERT INTO CANVAS_BACKGROUNDS (CANVAS_ID, BACKGROUNDS_ID) VALUES (2, 146);

INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 1);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 2);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 3);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 4);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 5);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 6);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 7);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 8);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 9);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (1, 10);

INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 1);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 2);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 3);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 4);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 5);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 6);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 7);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 8);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 9);
INSERT INTO CANVAS_BADGUYS (CANVAS_ID, BADGUYS_ID) VALUES (2, 10);

INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 49);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 50);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 51);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 52);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 53);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 54);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 55);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 56);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 57);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 58);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 59);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 60);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 61);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 62);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 63);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 64);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 65);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 66);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 67);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 68);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 69);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 70);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 71);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 72);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 73);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 74);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 75);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 76);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 77);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 78);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 79);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 80);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 81);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 82);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 83);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 84);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 85);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 86);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 87);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 88);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 89);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 90);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 91);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 92);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 93);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 94);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 95);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 96);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 97);

INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 147);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 148);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 149);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 150);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 151);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 152);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 153);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 154);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 155);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 156);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 157);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 158);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 159);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 160);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 161);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 162);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 163);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 164);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 165);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 166);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 167);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 168);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 169);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 170);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 171);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 172);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 173);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 174);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 175);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 176);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 177);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 178);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 179);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 180);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 181);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 182);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 183);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 184);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 185);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 186);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 187);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 189);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 190);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 191);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 192);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 193);
INSERT INTO CANVAS_HEATMAPS_BACKGROUND (CANVAS_ID, HEATMAPS_ID) VALUE (1, 194);

INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (1, 15);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (1, 16);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (1, 17);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (1, 18);

INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (2, 15);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (2, 16);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (2, 17);
INSERT INTO CANVAS_ITEMS_SPRITE (CANVAS_ID, ITEMS_ID) VALUES (2, 18);


--INSERT INTO CANVAS_STORE (CANVAS_ID, STORE_ID) VALUES (1 ,1);
--INSERT INTO CANVAS_STORE (CANVAS_ID, STORE_ID) VALUES (2 ,1);

INSERT INTO CANVAS_STORES (CANVAS_ID, STORES_ID) VALUES (1 ,1);
INSERT INTO CANVAS_STORES (CANVAS_ID, STORES_ID) VALUES (2 ,1);

INSERT INTO STORE_ITEMS_SPRITE (STORE_ID, ITEMS_ID) VALUES (1, 13);
INSERT INTO STORE_ITEMS_SPRITE (STORE_ID, ITEMS_ID) VALUES (1, 14);


INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,1);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,2);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,3);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,4);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,5);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,6);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,7);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,8);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,9);
INSERT INTO CANVAS_ROWS (CANVAS_ID, ROWS_ID) VALUES (1 ,10);

INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,2);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,3);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,4);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,5);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,6);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,7);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,8);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,9);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (1 ,10);

INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,2);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,3);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,4);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,5);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,6);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,7);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,8);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,9);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (2 ,10);

INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3 ,2);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3 ,3);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3 ,4);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 5);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 6);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 7);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 8);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 9);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (3, 10);

INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4 ,2);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4 ,3);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4 ,4);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 5);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 6);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 7);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 8);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 9);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (4, 10);

INSERT INTO ROW (ID, ROW_NUMBER) VALUES (5 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (6 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (7 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (8 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (9 ,1);
INSERT INTO ROW (ID, ROW_NUMBER) VALUES (10 ,1);



INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,1);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,2);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,3);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,4);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,5);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,6);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,7);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,8);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,9);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (1 ,10);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (1, 1, 49);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (2, 2, 50);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (3, 3, 51);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (4, 4, 52);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (5, 5, 53);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (6, 6, 54);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (7, 7, 55);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (8, 8, 56);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (9, 9, 57);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (10, 10, 58);


INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,11);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,12);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,13);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,14);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,15);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,16);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,17);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,18);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,19);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (2 ,20);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (11, 11, 59);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (12, 12, 60);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (13, 13, 61);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (14, 14, 62);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (15, 15, 63);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (16, 16, 64);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (17, 17, 65);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (18, 18, 66);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (19, 19, 67);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (20, 20, 68);


INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (3 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (21, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (22, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (23, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (24, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (25, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (26, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (27, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (28, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (29, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (30, 30, 78);

INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (4 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (31, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (32, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (33, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (34, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (35, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (36, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (37, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (38, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (39, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (40, 30, 78);

INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (5 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (31, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (32, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (33, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (34, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (35, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (36, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (37, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (38, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (39, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (40, 30, 78);

INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (6 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (31, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (32, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (33, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (34, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (35, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (36, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (37, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (38, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (39, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (40, 30, 78);

INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (7 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (31, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (32, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (33, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (34, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (35, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (36, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (37, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (38, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (39, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (40, 30, 78);


INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,31);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,32);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,33);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,34);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,35);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,36);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,37);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,38);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,39);
INSERT INTO ROW_SCENES (ROW_ID, SCENES_ID) VALUES (8 ,40);

INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (31, 21, 69);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (32, 22, 70);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (33, 23, 71);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (34, 24, 72);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (35, 25, 73);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (36, 26, 74);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (37, 27, 75);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (38, 28, 76);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (39, 29, 77);
INSERT INTO SCENE (ID, BACKGROUND_ID, HEATMAP_ID) VALUES (40, 30, 78);


--CREATE TABLE SCENE_HEATMAPS_BACKGROUND (
--	SCENE_ID         MEDIUMINT NOT NULL,
--	HEATMAPS_ID      MEDIUMINT NOT NULL,
--	CONSTRAINT SCENE_HEATMAPS_BACKGROUND_PK PRIMARY KEY (SCENE_ID, HEATMAPS_ID)
--);

--CREATE TABLE SCENE_BACKGROUNDS (
--	SCENE_ID          MEDIUMINT NOT NULL,
--	BACKGROUNDS_ID    MEDIUMINT NOT NULL,
--	CONSTRAINT CSCENE_BACKGROUNDS_PK PRIMARY KEY (SCENE_ID, BACKGROUNDS_ID)
--);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (1, 10);


INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (2, 10);


INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (3, 10);


INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (4, 10);


INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (5, 10);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (6, 10);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (7, 10);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (8, 10);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (9, 10);

INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 1);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 2);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 3);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 4);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 5);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 6);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 7);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 8);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 9);
INSERT INTO SCENE_BADGUYS (SCENE_ID, BADGUYS_ID) VALUES (10, 10);


INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (1, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (2, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (3, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (4, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (5, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (6, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (7, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (8, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (9, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (10, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (11, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (12, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (13, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (14, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (15, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (16, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (17, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (18, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (19, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (20, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (21, 1);
INSERT INTO SCENE_STORES (SCENE_ID, STORES_ID) VALUES (22, 1);

INSERT INTO SCENE_ITEMS (SCENE_ID, ITEMS_ID) VALUES (1, 15);
INSERT INTO SCENE_ITEMS (SCENE_ID, ITEMS_ID) VALUES (1, 16);
INSERT INTO SCENE_ITEMS (SCENE_ID, ITEMS_ID) VALUES (1, 17);
INSERT INTO SCENE_ITEMS (SCENE_ID, ITEMS_ID) VALUES (1, 18);



INSERT INTO INVENTORY (ID, GOLD) VALUES (1, 0);

--INSERT INTO INVENTORY_ITEMS (INVENTORY_ID, ITEMS_ID) VALUES (1, );

UPDATE SPRITE SET START_POSITION_LATITUDE = 0;
UPDATE SPRITE SET START_POSITION_LONGITUDE = 0;
UPDATE SPRITE SET START_POSITION_ELEVATION = 0;
UPDATE SPRITE SET ELEVATION = 0;
UPDATE SPRITE SET LONGITUDE = 0;
UPDATE SPRITE SET LATITUDE = 0;
