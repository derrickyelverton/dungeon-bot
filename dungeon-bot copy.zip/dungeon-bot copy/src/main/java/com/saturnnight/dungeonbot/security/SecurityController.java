package com.saturnnight.dungeonbot.security;

import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.User;
import com.saturnnight.dungeonbot.service.UserService;

/**
 * Handles requests for the application home page.
 */
@RestController
@RequestMapping("/security")
public class SecurityController {

	@Autowired
	UserService userService;

	private static final Logger logger = LoggerFactory.getLogger(SecurityController.class);

	@RequestMapping("/user")
	public ResponseEntity<User> getLoggedInUser() {
		logger.debug("Returning logged in user.");

		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		Object principal = authentication.getPrincipal();

		if (principal instanceof String && ((String) principal).equals("anonymousUser")) {
			return new ResponseEntity<User>(HttpStatus.UNAUTHORIZED);
		}

		//String username = ((UserDetails) principal).getUsername();
		String username = (String)principal;
		User user = userService.findByUserName(username);
		Iterator a = authentication.getAuthorities().iterator();
		while (a.hasNext()) {
			user.addRole( ((GrantedAuthority)a.next()).getAuthority() );
		}
		
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

}
