package com.saturnnight.dungeonbot.security.permissionevaluator;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.saturnnight.dungeonbot.jpa.User;

@Component
public class BasePermission {

	protected String getLoginUsername(final Authentication authentication) {
		Object principal = authentication.getPrincipal();
		return ((UserDetails) principal).getUsername();
	}

	protected boolean isAuthenticated(Authentication authentication) {
		return (authentication != null && !(authentication.getPrincipal() instanceof String) && !(authentication.getPrincipal().equals("anonymousUser")));
	}

	protected User getLoggedInUser() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		User loginUser = (User) attr.getRequest().getSession().getAttribute("loginUser");
		return loginUser;
	}

	protected boolean isValidLongInstance(Object targetDomainObject) {
		return targetDomainObject instanceof Long && (Long) targetDomainObject > 0;
	}
}
