package com.saturnnight.dungeonbot.security.permissionevaluator;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;

public class CardGamePermissionEvaluator implements PermissionEvaluator {

	private static final Logger logger = LoggerFactory.getLogger(CardGamePermissionEvaluator.class);

	private Map<String, Permission> permissionNameToPermissionMap = new HashMap<String, Permission>();

	protected CardGamePermissionEvaluator() {
	}

	public CardGamePermissionEvaluator(Map<String, Permission> permissionNameToPermissionMap) {
		// notNull(permissionNameToPermissionMap);
		this.permissionNameToPermissionMap = permissionNameToPermissionMap;
	}

	@Override
	public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
		boolean hasPermission = false;
		if (canHandle(authentication, targetDomainObject, permission)) {
			hasPermission = checkPermission(authentication, targetDomainObject, (String) permission);
		}
		return hasPermission;
	}

	private boolean canHandle(Authentication authentication, Object targetDomainObject, Object permission) {
		return targetDomainObject != null && authentication != null && permission instanceof String;
	}

	private boolean checkPermission(Authentication authentication, Object targetDomainObject, String permissionKey) {
		boolean isPermissionKeyDefined = false;
		try {
			verifyPermissionIsDefined(permissionKey);
			Permission permission = permissionNameToPermissionMap.get(permissionKey);
			isPermissionKeyDefined = permission.isAllowed(authentication, targetDomainObject);
		} catch (PermissionNotDefinedException e) {
			logger.info(e.getMessage());
		}
		return isPermissionKeyDefined;
	}

	private void verifyPermissionIsDefined(String permissionKey) throws PermissionNotDefinedException {
		if (!permissionNameToPermissionMap.containsKey(permissionKey)) {
			throw new PermissionNotDefinedException("No permission with key " + permissionKey + " is defined in " + this.getClass().toString());
		}
	}

	@Override
	public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
		return false;
	}

}
