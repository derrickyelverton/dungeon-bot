package com.saturnnight.dungeonbot.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

public class StaticResourcesProductionFilter implements Filter {

    public static final String PROFILE_NAME = "spring.profiles.active";
	
	public static final String SPRING_PROFILE_DEVELOPMENT = "dev";
    public static final String SPRING_PROFILE_PRODUCTION = "prod";
    
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		if(request.getServletContext().getInitParameter(PROFILE_NAME).endsWith(SPRING_PROFILE_PRODUCTION)) {
			HttpServletRequest httpRequest = (HttpServletRequest) request;
			String contextPath = ((HttpServletRequest) request).getContextPath();
			String requestURI = httpRequest.getRequestURI();
			requestURI = StringUtils.substringAfter(requestURI, contextPath);
			if (StringUtils.equals("/", requestURI)) {
				requestURI = "/index.html";
			}
			String newURI = "/dist" + requestURI;
			request.getRequestDispatcher(newURI).forward(request, response);
		} else {
			chain.doFilter(request, response);
		}

	}

}
