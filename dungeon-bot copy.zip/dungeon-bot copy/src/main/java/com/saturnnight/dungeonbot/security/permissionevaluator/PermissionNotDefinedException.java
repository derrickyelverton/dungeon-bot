package com.saturnnight.dungeonbot.security.permissionevaluator;

public class PermissionNotDefinedException extends Exception {

	private static final long serialVersionUID = 4325857060838198106L;

	private String message = "Permission not found.";

	public PermissionNotDefinedException() {
		super();
	}

	public PermissionNotDefinedException(String message) {
		super(message);
		this.message = message;
	}

	public PermissionNotDefinedException(Throwable cause) {
		super(cause);
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}
}
