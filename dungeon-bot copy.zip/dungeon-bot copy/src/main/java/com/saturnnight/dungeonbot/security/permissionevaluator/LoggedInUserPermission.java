package com.saturnnight.dungeonbot.security.permissionevaluator;

import org.springframework.security.core.Authentication;

public class LoggedInUserPermission extends BasePermission implements Permission {

	@Override
	public boolean isAllowed(Authentication authentication, Object userId) {
		boolean hasPermisson = false;
		if (isAuthenticated(authentication) && isValidLongInstance(userId)) {
			if (getLoggedInUser().getId().equals(userId)) {
				hasPermisson = true;
			}
		}
		return hasPermisson;
	}

}
