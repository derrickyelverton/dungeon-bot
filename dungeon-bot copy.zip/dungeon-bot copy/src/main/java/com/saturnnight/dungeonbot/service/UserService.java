package com.saturnnight.dungeonbot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.saturnnight.dungeonbot.jpa.User;
import com.saturnnight.dungeonbot.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;

	public User findById(final long id) {
		return userRepository.findOne(id);
	}

	public User findByUserNameAndPassword(final String userName, final String password) {
		return userRepository.findByUserNameAndPassword(userName, password);
	}

	public User save(User user) {
		return userRepository.save(user);
	}

	public void delete(long id) {
		userRepository.delete(id);
	}

	public User findByUserName(String userName) {
		return userRepository.findByUserName(userName);
	}	
		
}
