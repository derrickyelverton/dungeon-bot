package com.saturnnight.dungeonbot.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

public class JsonUtil {

	private static final Logger logger = LoggerFactory.getLogger(JsonUtil.class);
	
	private static final String[] INTEGER_FIELDS = {"person.id"};
	
	public static JsonObject stringToJson(String response) {
		InputStream is = new ByteArrayInputStream(response.getBytes(StandardCharsets.UTF_8));
	
		JsonReader jsonReader = null;
		JsonObject resultObject = null;
		try {
			jsonReader = Json.createReader(is);
			resultObject = jsonReader.readObject();
	
		}
		finally {
			if (jsonReader != null) {
				jsonReader.close();
			}
			if (is != null) {
				try {
					is.close();
				}
				catch (Exception e) {
					logger.error("parseResonse", e);
				}
			}
		}
		return resultObject;
	}		
	
	public static PageRequest createPageRequest(final String sort, final int offset, final int count) {
		PageRequest pageRequest = null;
		Sort sortBy = createSort(sort);
		if (sortBy != null) {
			pageRequest = new PageRequest(offset/count, count, sortBy);
			
		}
		else {
			pageRequest = new PageRequest(offset/count, count);
		}
		return pageRequest;
	}
	
	//{"field":"id","dir":"asc"}
	public static Sort createSort(String sort) {
		Sort sortBy = null;
		if (sort != null && !"".equals(sort)) {
			JsonObject sorter = stringToJson(sort);
			if (sorter != null) {
				sortBy = new Sort((("asc".equals(sorter.get("dir").toString()))?Sort.Direction.ASC:Sort.Direction.DESC), sorter.get("field").toString());
			}
		}
		return sortBy;
	}
	
	public static String createOrderBy(String sort) {
		String orderBy = "";
		if (sort != null && !"".equals(sort)) {
			JsonObject sorter = stringToJson(sort);
			if (sorter != null) {
				orderBy = " ORDER BY e." + sorter.get("field").toString() + " " + sorter.get("dir").toString();
			}
		}
		return orderBy;
	}

	public static String createWhere(String filter) {
		JsonObject filterBy = stringToJson(filter);		 
		String where = " WHERE ";
  		String logic = filterBy.get("logic").toString();
		JsonArray filters = filterBy.getJsonArray("filters");
		for (int i = 0;i<filters.size();i++) {
			JsonObject fil = filters.getJsonObject(i);
			String operator = fil.get("operator").toString();
			String value = fil.get("value").toString();
			
			boolean isIntegerField = false;
			for (int f=0;f<INTEGER_FIELDS.length;f++) {
				if (INTEGER_FIELDS[f].equals(fil.get("field").toString())) {
					isIntegerField = true;
				}
			}
			
			if (isIntegerField) {
				where = where + "e." + fil.get("field").toString();
				if ("contains".equals(operator)) {
					where = where + " like " + "%" + value + "%";
				}
				else if ("startswith".equals(operator)) {
					where = where + " like " + value + "%";
				}
				else if ("endswith".equals(operator)) {
					where = where + " like " + "%" + value + "";
				}
				else if ("eq".equals(operator)) { // equals
					where = where + " = " + value + "";
				}
				else if ("doesnotcontain".equals(operator)) { // equals
					where = where + " not like %" + value + "%";
				}
				else if ("neq".equals(operator)) {  // not equals
					where = where + " not = " + value + "";
				}
				else if ("greaterthan".equals(operator)) {  // greater than
					where = where + " > " + value + "";
				}
				else if ("lessthan".equals(operator)) {  // less than
					where = where + " < " + value + "";
				}
			}
			else { // string fields
				where = where + "LOWER(e." + fil.get("field").toString()+")";
				if ("contains".equals(operator)) {
					where = where + " like " + "'%" + value + "%'";
				}
				else if ("startswith".equals(operator)) {
					where = where + " like '" + value + "%'";
				}
				else if ("endswith".equals(operator)) {
					where = where + " like '" + "%" + value + "'";
				}
				else if ("eq".equals(operator)) { // equals
					where = where + " = '" + value + "'";
				}
				else if ("doesnotcontain".equals(operator)) { // equals
					where = where + " not like '%" + value + "%'";
				}
				else if ("neq".equals(operator)) {  // not equals
					where = where + " not = '" + value + "'";
				}
				else if ("greaterthan".equals(operator)) {  // greater than
					where = where + " > " + value + "";
				}
				else if ("lessthan".equals(operator)) {  // less than
					where = where + " < " + value + "";
				}
			}
			if (i+1<filters.size()) {
				where = where + " " + logic + " ";
			}
  		}		 
		return where;
	}
	
 
}