package com.saturnnight.dungeonbot.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.saturnnight.dungeonbot.jpa.User;
import com.saturnnight.dungeonbot.service.UserService;

@RestController
@RequestMapping(value = "/systemusers")
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(method = RequestMethod.POST)
	public User createPerson(@RequestBody User person) {
		User existingUser = userService.findByUserName(person.getUserName());
		if (existingUser == null) {
			return userService.save(person);
		}
		else {
			return null;
		}
			
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public User updatePerson(@PathVariable("id") String id, @RequestBody User person) {
		return userService.save(person);
	}	
	
	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deletePerson(@PathVariable("id") long id) {
		ResponseEntity<String> responseEntity;
		try {
			userService.delete(id);
			responseEntity = new ResponseEntity<String>("{\"status\":\"ok\"}",HttpStatus.OK);
		}
		catch (DataIntegrityViolationException e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete person.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		catch (Exception e) {
			responseEntity = new ResponseEntity<String>("{\"status\":\"Failed to delete person.\"}",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public User getPerson(@PathVariable("id") long id) {
		return this.userService.findById(id);
	}
	
}
