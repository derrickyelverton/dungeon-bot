
var inputController = null;

function Input() {
	this.loggedIn = false;
	this.accessRequested = false;
	this.lastUserInputString = null;

	// set the user input 
	window.addEventListener('keydown', this.handleKeyDown, false);
	window.addEventListener('keyup', this.handleKeyUp, false);
	//battleChasersController.canvas.addEventListener('mousedown', this.handleMouseDown, false);
	
	//battleChasersController.canvas.addEventListener('mousemove', this.getPixelColor);
}

Input.prototype.getPixelColor = function(event) {
	  var x = event.layerX;
	  var y = event.layerY;
	  var pixel = battleChasersController.convasContext.getImageData(x, y, 1, 1);
	  var data = pixel.data;
	  var rgba = 'rgba(' + data[0] + ', ' + data[1] +
	             ', ' + data[2] + ', ' + (data[3] / 255) + ')';
	  document.getElementById('outputField').innerHTML =  "Current Mouse Position x: " + x + ", y: " + y + ", rgba: " + rgba;
	}

Input.prototype.handleInputCommand = function(userInputString) {
	userInputString = userInputString.toLowerCase();
	
    if (userInputString.indexOf('hello') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapHelloResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('look') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapLookResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('search') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapSearchResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('get') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapGetResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('take') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapTakeResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('give') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapGiveResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('acquire') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapAcquireResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('swipe') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapSwipeResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('pick') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapPickResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('pluck') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapPluchResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('pull') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapPullResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('push') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapPushResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('bow') >= 0) {
		document.getElementById('outputField').innerHTML = 'You can not bow.';
	}
	else if (userInputString.indexOf('jump') >= 0) {
		document.getElementById('outputField').innerHTML = 'You can not jump.';
	}
	else if (userInputString.indexOf('open') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapOpenResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('close') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapCloseResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('move') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapMoveResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('climb') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to climb.';
	}
	else if (userInputString.indexOf('scale') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to scale.';
	}
	else if (userInputString.indexOf('show') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to show or anyone to show it to.';
	}
	else if (userInputString.indexOf('talk') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapTalkResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('build') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to build.';
	}
	else if (userInputString.indexOf('plant') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to plant.';
	}
	else if (userInputString.indexOf('play') >= 0) {
		document.getElementById('outputField').innerHTML = 'There is nothing around to play.';
	}
	else if (userInputString.indexOf('eat') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapEatResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('read') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapReadResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('drink') >= 0) {
		document.getElementById('outputField').innerHTML = Constants.mapDrinkResponse[Constants.mapCurrentRow][Constants.mapCurrentColumn];
	}
	else if (userInputString.indexOf('attack') >= 0) {
		document.getElementById('outputField').innerHTML = 'Hit the F key to fire';
	}
	else if (userInputString.indexOf('do you understand what i am saying') >= 0) {
		document.getElementById('outputField').innerHTML = 'Sometime, i am programmed to respond to you in a way you might feels like a "human".';
	}
	else if (userInputString.indexOf('i dont like you') >= 0  || userInputString.indexOf("i don't like you") >= 0) {
		document.getElementById('outputField').innerHTML = 'I dont like you either.';
	}
	else if (userInputString.indexOf('what is your favorite movie') >= 0) {
		document.getElementById('outputField').innerHTML = 'I have never seen a movie. I dont have eyes';
	}
	else if (userInputString.indexOf('what is your name') >= 0 || userInputString.indexOf('do you have a name') >= 0) {
		document.getElementById('outputField').innerHTML = 'My name is , well I do not have a name.  I am a program. Silly';
	}
	else if (userInputString.indexOf('what is your favorite color') >= 0 || userInputString.indexOf('do you have a favorite color') >= 0) {
		document.getElementById('outputField').innerHTML = 'I do not have a favorite color';
	}
	else if (userInputString.indexOf('what is your favorite food') >= 0) {
		document.getElementById('outputField').innerHTML = 'I do not eat food. I suppose it enjoy being on in and eating power';
	}
	else if (userInputString.indexOf('next') >= 0) {
		battleChasersController.setupNewLevel();
	}
	else if (userInputString.indexOf('walk') >= 0) {
		Constants.Keys.getDown.push(Constants.Keys.RIGHT);
	}
	else if (userInputString.indexOf('stop') >= 0) {
		Constants.Keys.getDown = [];
	}
	else if (userInputString.indexOf('shoot') >= 0) {
		Constants.Keys.getDown.push(Constants.Keys.SPACE);
		setTimeout(function(){ Constants.Keys.getDown = []; }, 1000);
	}
	else if (userInputString.indexOf('punch') >= 0) {
		Constants.Keys.getDown.push(Constants.Keys.P);
		setTimeout(function(){ Constants.Keys.getDown = []; }, 1000);
	}
	else if (userInputString.indexOf('kick') >= 0) {
		Constants.Keys.getDown.push(Constants.Keys.K);
		setTimeout(function(){ Constants.Keys.getDown = []; }, 1000);
	}
	else if (userInputString.indexOf('go') >= 0 || userInputString.indexOf('up') >= 0 || userInputString.indexOf('down') >= 0 ||
	userInputString.indexOf('right') >= 0 || userInputString.indexOf('left') >= 0) {
		document.getElementById('outputField').innerHTML = 'Use the arrow keys';
	}
	else if (userInputString.indexOf('request access') >= 0) {
		document.getElementById('outputField').innerHTML = 'Username/Password';
		this.accessRequested = true;
	}
	else if (this.accessRequested && userInputString.indexOf('saturn/welcome') >= 0) {
		document.getElementById('outputField').innerHTML = 'logged in to system. welcome saturn';
		this.loggedIn = true;
	}
	else {
		document.getElementById('outputField').innerHTML = 'I am not sure what you are trying to do?';
	}
	this.lastUserInputString = userInputString;

}

/*
{----------------------------------------------}
Controls                                      }
{----------------------------------------------}

Up Arrow - Move North/Up
Down Arrow - Move South/Down
Left Arrow - Move West
Right Arrow - Move East
Page Up - Move Northeast
Page Down - Move Southeast
Home - Move Northwest
End- Move Southwest

+ - Faster Speed
= - Normal Speed
- - Slower Speed

F1 - Open Help Menu
F2 - Toggle Sound On/Off
F3 - Retype Last Command
F4 - Duck
F5 - Save Game
F6 - Jump
F7 - Restore Game
F9 - Restart Game

Ctrl A - About KQ1
Ctrl Q - Quit Game
Ctrl p - Pause Game
Ctrl I - Inventory
Ctrl S - Change Speed
Ctrl V - Change Volume 

Esc - Open Menu Bar
Tab - Open Inventory
Space - Retype Last Message

*/
Input.prototype.handleKeyDown = function(e) {
	switch (e.keyCode) {
	    case Constants.Keys.ENTER:
		    if (document.getElementById('inputField').value != '') {
			   inputController.handleInputCommand(document.getElementById('inputField').value);
			   this.battleChasersController.hero.communication.push(document.getElementById('inputField').value);
			}
		    break;
	    		    
		case Constants.Keys.SPACE:
			Constants.Keys.getDown.push(Constants.Keys.SPACE);
			break;		    
		case Constants.Keys.SPACE:
			Constants.Keys.getDown.push(Constants.Keys.SPACE);
			break;
		case Constants.Keys.SPACE:
			Constants.Keys.getDown.push(Constants.Keys.SPACE);
			break;
		case Constants.Keys.SHIFT:
			Constants.Keys.getDown.push(Constants.Keys.SHIFT);
			break;

		case Constants.Keys.A:
			if (!Constants.inArray(Constants.Keys.A, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.A);
			}
			break;
	   case Constants.Keys.D:
			if (!Constants.inArray(Constants.Keys.D, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.D);
			}
			break;
		case Constants.Keys.W:
			if (!Constants.inArray(Constants.Keys.W, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.W);
			}
			break;
		case Constants.Keys.K:
			if (!Constants.inArray(Constants.Keys.W, Constants.Keys.getDown) && !Constants.inArray(Constants.Keys.S, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.K);
			}
			break;
		case Constants.Keys.P:
			if (!Constants.inArray(Constants.Keys.P, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.P);
			}
			break;
		case Constants.Keys.F:
			if (!Constants.inArray(Constants.Keys.F, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.F);
			}
			break;
		case Constants.Keys.I:
			if (!Constants.inArray(Constants.Keys.I, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.I);
			}
			break;
		case Constants.Keys.T:
			if (!Constants.inArray(Constants.Keys.T, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.T);
			}
			break;
		case Constants.Keys.ZERO:
			if (!Constants.inArray(Constants.Keys.ZERO, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.ZERO);
			}
			break;
		case Constants.Keys.ONE:
			if (!Constants.inArray(Constants.Keys.ONE, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.ONE);
			}
			break;
		case Constants.Keys.TWO:
			if (!Constants.inArray(Constants.Keys.TWO, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.TWO);
			}
			break;
		case Constants.Keys.THREE:
			if (!Constants.inArray(Constants.Keys.THREE, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.THREE);
			}
			break;
		case Constants.Keys.FOUR:
			if (!Constants.inArray(Constants.Keys.FOUR, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.FOUR);
			}
			break;
		case Constants.Keys.FIVE:
			if (!Constants.inArray(Constants.Keys.FIVE, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.FIVE);
			}
			break;
		case Constants.Keys.S:
			if (!Constants.inArray(Constants.Keys.S, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.S);
			}
			break;
		case Constants.Keys.LEFT:
			if (!Constants.inArray(Constants.Keys.RIGHT, Constants.Keys.getDown) && !Constants.inArray(Constants.Keys.LEFT, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.LEFT);
			}
			break;
	   case Constants.Keys.RIGHT:
			if (!Constants.inArray(Constants.Keys.LEFT, Constants.Keys.getDown) && !Constants.inArray(Constants.Keys.RIGHT, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.RIGHT);
			}
			break;
		case Constants.Keys.UP:
			if (!Constants.inArray(Constants.Keys.UP, Constants.Keys.getDown) && !Constants.inArray(Constants.Keys.DOWN, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.UP);
			}
			break;
		case Constants.Keys.DOWN:
			if (!Constants.inArray(Constants.Keys.DOWN, Constants.Keys.getDown) && !Constants.inArray(Constants.Keys.UP, Constants.Keys.getDown)) {
				Constants.Keys.getDown.push(Constants.Keys.DOWN);
			}
			break;
			
	}
}

Input.prototype.handleMouseDown = function(e) {
}

Input.prototype.handleKeyUp = function(e) {
	switch (e.keyCode) {
		case Constants.Keys.W:
		case Constants.Keys.D:
		case Constants.Keys.S:
		case Constants.Keys.A:
		case Constants.Keys.K:
		case Constants.Keys.P:
		case Constants.Keys.F:
		case Constants.Keys.I:
		case Constants.Keys.ZERO: 
		case Constants.Keys.ONE: 
		case Constants.Keys.TWO:
		case Constants.Keys.THREE: 
		case Constants.Keys.FOUR: 
		case Constants.Keys.FIVE: 
		case Constants.Keys.SIX: 
		case Constants.Keys.SEVEN: 
		case Constants.Keys.EIGHT: 
		case Constants.Keys.NINE: 
		case Constants.Keys.SPACE:
		case Constants.Keys.SHIFT:
		case Constants.Keys.LEFT:
		case Constants.Keys.RIGHT:
		case Constants.Keys.UP:
		case Constants.Keys.DOWN:
			Constants.Keys.getDown = Constants.removeFromArray(e.keyCode, Constants.Keys.getDown);
			break;
	}	
}	
