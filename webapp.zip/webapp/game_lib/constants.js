
var Constants = {
		
	GameMode: {
		Kill: 0,
		Adventure: 1,
		HorizontalScrolling: 2,
		VerticalScrolling: 3
	},	
		
	SpriteType: {
				Weapon: 0,
				Chest: 1,
				Pants: 2,
				Shoes: 3,
				Gloves: 4,
				Ring: 5,
				Necklace: 6,
				Item: 7,
				Potion: 8,
				Keys: 9,
				Pawn: 10,
				Boss: 11,
				Hero: 12,
				EasterEgg: 13,
				Store: 14
			},

	Direction: {
				LEFT: 0,
				RIGHT: 1,
				UP: 3,
				DOWN: 4
			},

			//numbers on top of keyboard ( 0 - 9 ) : 48 - 57
			//numbers on numeric keypad ( 0 - 9 ) : 96 - 105

	NumberKeyLookup: [48,49,50,51,52,53,54,55,56,57],

    Keys: {
				getDown: [],
				UP: 38,
				DOWN: 40,
				LEFT: 37,
				RIGHT: 39,
				ZERO: 48,
				ONE: 49,
				TWO: 50,
				THREE: 51,
				FOUR: 52,
				FIVE: 53,
				SIX: 54,
				SEVEN: 55,
				EIGHT: 56,
				NINE: 57,
				
				A: 65,
				B: 66,
				C: 67,
				D: 68,
				E: 69,
				F: 70,
				G: 71,
				H: 72,
				I: 73,
				J: 74,
				K: 75,
				L: 76,
				M: 77,
				N: 78,
				O: 79,
				P: 80,
				Q: 81,
				R: 82,
				S: 83,
				T: 84,
				U: 85,
				V: 86,
				W: 87,
				X: 88,
				Y: 89,
				Z: 90,
				SPACE: 32,
				ENTER: 13,
				SHIFT: 16,
				CONTROL:17
			},

	 Action: {
				getAction: [],
				STANDING: 1,
				SITTING: 2,
				WALKING: 3,
				SHOOTING_FIREBALL: 4,
				PUNCH: 5,
				KICK: 6
			},		
	
	lastRunTime: 0,
	lastSecond: 0,
	runTime: 0,
	boardLevel: 1,
	
	canvasWidth: 800,
	canvasHeight: 600,
	
	spritePositionX: 16,
	spritePositionY: 32,
	
	mapCurrentRow: 0,
	mapCurrentColumn: 0,
	
	empty: [
	    [[],[],[],[],[],[],[],[]],
	    [[],[],[],[],[],[],[],[]],
	    [[],[],[],[],[],[],[],[]],
	    [[],[],[],[],[],[],[],[]],
	    [[],[],[],[],[],[],[],[]],
	    [[],[],[],[],[],[],[],[]],
	],
	
	mapLookResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapHelloResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapLookResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapSearchResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapGetResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapTakeResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapGiveResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapAcquireResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapSwipeResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapPickResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapPluchResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapPullResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapPushResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapOpenResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapCloseResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],


	mapMoveResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapTalkResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],


	mapEatResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapReadResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

	mapDrinkResponse: [
	    ['There are some strange flowers you see on the ground.  It is best to stay away!','game_lib/img/BackgroundHeatMap7.png','game_lib/img/BackgroundHeatMap13.png','game_lib/img/BackgroundHeatMap19.png','game_lib/img/BackgroundHeatMap25.png','game_lib/img/BackgroundHeatMap31.png','game_lib/img/BackgroundHeatMap37.png','game_lib/img/BackgroundHeatMap43.png'],
	    ['game_lib/img/BackgroundHeatMap2.png','game_lib/img/BackgroundHeatMap8.png','game_lib/img/BackgroundHeatMap14.png','game_lib/img/BackgroundHeatMap20.png','game_lib/img/BackgroundHeatMap26.png','game_lib/img/BackgroundHeatMap32.png','game_lib/img/BackgroundHeatMap38.png','game_lib/img/BackgroundHeatMap44.png'],
	    ['game_lib/img/BackgroundHeatMap3.png','game_lib/img/BackgroundHeatMap9.png','game_lib/img/BackgroundHeatMap15.png','game_lib/img/BackgroundHeatMap21.png','game_lib/img/BackgroundHeatMap27.png','game_lib/img/BackgroundHeatMap33.png','game_lib/img/BackgroundHeatMap39.png','game_lib/img/BackgroundHeatMap45.png'],
	    ['game_lib/img/BackgroundHeatMap4.png','game_lib/img/BackgroundHeatMap10.png','game_lib/img/BackgroundHeatMap16.png','game_lib/img/BackgroundHeatMap22.png','game_lib/img/BackgroundHeatMap28.png','game_lib/img/BackgroundHeatMap34.png','game_lib/img/BackgroundHeatMap40.png','game_lib/img/BackgroundHeatMap46.png'],
	    ['game_lib/img/BackgroundHeatMap5.png','game_lib/img/BackgroundHeatMap11.png','game_lib/img/BackgroundHeatMap17.png','game_lib/img/BackgroundHeatMap23.png','game_lib/img/BackgroundHeatMap29.png','game_lib/img/BackgroundHeatMap35.png','game_lib/img/BackgroundHeatMap41.png','game_lib/img/BackgroundHeatMap47.png'],
	    ['game_lib/img/BackgroundHeatMap6.png','game_lib/img/BackgroundHeatMap12.png','game_lib/img/BackgroundHeatMap18.png','game_lib/img/BackgroundHeatMap24.png','game_lib/img/BackgroundHeatMap30.png','game_lib/img/BackgroundHeatMap36.png','game_lib/img/BackgroundHeatMap42.png','game_lib/img/BackgroundHeatMap48.png'],
	],

    pointDistance: function(aX, aY, bX, bY) {
		return this.distance(aX, bX) + this.distance(aY, bY);
	},

	distance: function(aX, bX) {
		return (aX > bX) ? Math.abs(aX - bX) : Math.abs(bX - aX); 
	},

	getColorAtPoint: function(context, x, y) {
		return context.getImageData(x, y, 1, 1).data;
	},

	clearCanvas: function(canvas, canvasWidth, canvasHeight) {
		canvas.clearRect(0, 0, canvasWidth, canvasHeight);
	},

	inArray: function(element, arr) {
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] === element) {
				return true;
			}
		}    
		return false;
	},

	removeFromArray: function(element, arr) {
		for (var i = 0; i < arr.length; i++) {
			if (arr[i] == element)
				arr.splice(i, 1);
		}
		return arr;
	}
	
}
