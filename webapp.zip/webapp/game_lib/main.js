var constantUtils = null;
var battleChasersController = null;
var inputController = null;
	

window.onload = function() {
	// create the game
	battleChasersController = new Game();
    //create the input
	inputController = new Input();

	document.getElementById('newGameButton').onclick = function() {
		battleChasersController.setupNewGame();
		document.getElementById('statusClockStart').innerHTML = "";
	}

	document.getElementById('showHeatMapButton').onclick = function() {
		battleChasersController.showHeatMap();
	}

	document.getElementById('showBackgroundButton').onclick = function() {
		battleChasersController.showBackground();
	}

	document.getElementById('nextBoardButton').onclick = function() {
		battleChasersController.setupNewLevel();
	}
	
	document.getElementById('saveGameButton').onclick = function() {
		battleChasersController.saveGame();
	}

	document.getElementById('loadGameButton').onclick = function() {
		battleChasersController.loadGame();
	}
	
	// setup a interval of 5 mil to have the game redraw itself 
	setInterval(function() {
		// draw
		if (battleChasersController.timer != undefined) {
			if (document.getElementById('statusClockStart').innerHTML == "") {
				document.getElementById('statusClockStart').innerHTML = battleChasersController.timer.getSeconds();
			}
			battleChasersController.draw(battleChasersController.timer.getSeconds());
			// update health and magic bar
			document.getElementById('healthBar').style = 'height:25px;width:'+battleChasersController.hero.health+'%;background-color:red;';
			document.getElementById('magicBar').style = 'height:25px;width:'+battleChasersController.hero.magic+'%;background-color:blue;';
			document.getElementById('experienceBar').style = 'height:25px;width:'+battleChasersController.hero.experience+'%;background-color:green;';
			document.getElementById('statusPlayerGold').innerHTML = battleChasersController.hero.inventory.gold;
			// update status
			document.getElementById('statusCanvasWidth').innerHTML = Constants.canvasWidth;
			document.getElementById('statusCanvasHeight').innerHTML = Constants.canvasHeight;
			document.getElementById('statusClockRun').innerHTML = battleChasersController.timer.getSeconds() - document.getElementById('statusClockStart').innerHTML;
			document.getElementById('statusClock').innerHTML = battleChasersController.timer.getSeconds();
			if (battleChasersController.timer.getSeconds() != Constants.lastSecond) {
				Constants.lastSecond = battleChasersController.timer.getSeconds();
				document.getElementById('statusFPS').innerHTML = Constants.runTime - Constants.lastRunTime;
				Constants.lastRunTime = Constants.runTime;
			}
			document.getElementById('statusGameTime').innerHTML = Constants.runTime;
			document.getElementById('statusPlayerHealth').innerHTML = battleChasersController.hero.health;
			document.getElementById('statusPlayerMagic').innerHTML = battleChasersController.hero.magic;
			document.getElementById('statusPlayerExperience').innerHTML = battleChasersController.hero.experience;
			document.getElementById('statusPlayerLevel').innerHTML = battleChasersController.hero.level;
			
			document.getElementById('statusPlayerBoard').innerHTML = Constants.boardLevel;
			document.getElementById('statusPlayerMapRow').innerHTML = Constants.mapCurrentRow;
			document.getElementById('statusPlayerMapColumn').innerHTML = Constants.mapCurrentColumn;
			document.getElementById('statusPlayerX').innerHTML = battleChasersController.hero.Position.x;
			document.getElementById('statusPlayerY').innerHTML = battleChasersController.hero.Position.y;
			
		}
	}, 5);
}
