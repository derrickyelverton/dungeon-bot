function Screen(context, x, y, z, title, backgroundImageScr, continueKey, callBackFunction) {
	this.context = context;
	this.x = x;
	this.y = y;
	this.z = z;
	this.displayTime = 200;  // frames maybe 60 a second so 3 ish seconds
	this.title = title;
	this.continueKey = continueKey;
    this.backgroundImageScr = backgroundImageScr;
    this.callBackFunction = callBackFunction;
}

Screen.prototype.draw = function(c, drawShadow) {
	if (this.shown) {
		c.drawImage(this.backgroundImageScr, 
					this.offsetX, 
					this.offsetY, 
					this.width,
					this.height, 
					this.x, 
					this.y, 
					this.width * this.zoomLevel, 
					this.height * this.zoomLevel);
	    c.font = '8pt Calibri';
	    c.textAlign = 'center';
        //c.fillStyle = 'blue';
	    if (color != null && color != undefined && color != '') {
	    	    c.fillStyle = color;
	    }
	    c.fillText(this.title + "", this.x, this.y);
	  
		if (constantUtils.inArray(continueKey, Keys.getDown)) {
			this.shown = false;
			this.callBackFunction(true);
		}	    
	}
}
