//var global game variable once created
var gameController = null;
//Game object
function Game(gameName, gameMode, gameMap, gameMapHeatMap, gameItems, gameStores, gameDialogs, gameBadGuys, gameHero, gameRows, saveHeroCallback, loadHeroCallback) {
	this.saveHero = saveHeroCallback;
	this.loadHero = loadHeroCallback;
	//initialize the game
	this.gameName = gameName;
	this.gameMode = gameMode;
	this.gameMap = gameMap;
	this.gameMapHeatMap = gameMapHeatMap;
    this.gameRows = gameRows;
	this.gameItems = gameItems;
	this.gameStores = gameStores;
    this.gameBadGuys = gameBadGuys;
	this.gameDialogs = [];
    // create hero sprite
    this.hero = this.createHero(gameHero);
	this.initialize();
}

Game.prototype.initialize = function() {
	//load inventory background
	this.setInventoryBackground('game_lib/img/inventoryBackground.png');
    //create the canvas
	this.createCanvas();
	//create the heatmap
	this.createHeatMap();
	//setup new game
	this.setupNewGame(true);
    // perform save check
	this.saveCheck();
}

Game.prototype.saveCheck = function() {
	this.ableToSave = false;
	if (typeof(Storage) !== "undefined") {
	    // Code for localStorage/sessionStorage.
		this.ableToSave = true;
	} else {
	    // Sorry! No Web Storage support..
	}	
}

Game.prototype.createHero = function(gameHero) {
    // create hero sprite
    var sprite = new Sprite(gameHero.source, gameHero.width, gameHero.height, gameHero.offsetX, gameHero.offsetY, gameHero.frames, gameHero.duration, gameHero.spriteType, gameHero.startPositionX, gameHero.startPositionY, gameHero.health, gameHero.experience, gameHero.level, gameHero.healthOverlayShown, gameHero.isGold, gameHero.gold, gameHero.name, gameHero.id);
    sprite.inventory = this.createInventory(gameHero);
    return sprite;
}

Game.prototype.createInventory = function(gameHero) {
    // create hero sprite
    var inventory = null;
    if (gameHero.inventory != undefined) {
    		inventory = new Inventory(null, gameHero.inventory.id, gameHero.inventory.gold, gameHero.inventory.items);
    }
    else {
		inventory = new Inventory(null, 1, 0, []);
    }
    return inventory;
}

Game.prototype.createCanvas = function() {
	// create handle to canvas
	this.canvas = document.getElementById('myCanvas');
	// create handle to (2d) context
	this.convasContext = this.canvas.getContext('2d');	
}

Game.prototype.createHeatMap = function() {
	// create heatmap	
	this.heatMapCanvas = document.createElement("canvas");
	this.heatMapCanvas.height = Constants.canvasHeight;
	this.heatMapCanvas.width = Constants.canvasWidth;
	// get heat map canvas context
	this.heatMapCanvasContext = this.heatMapCanvas.getContext("2d");
}

Game.prototype.showBackground = function() {
	//get background image from world map based on current row column of the user
	this.setBackground(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].background);
}

Game.prototype.setBackground = function(background) {
	//create/set background image
	this.background = new Image();
	this.background.src = background.path;
}

Game.prototype.showHeatMap = function() {
	//show heat map image
	this.background.src = this.heatMapImage.src;
}

Game.prototype.setHeatMap = function(background) {
	//create/set heat map
	this.heatMapImage = new Image();
	this.heatMapImage.src = background.path;
}

Game.prototype.setInventoryBackground = function(background) {
	//create/set heat map
	this.inventoryBackgroundImage = new Image();
	this.inventoryBackgroundImage.src = background;
}

Game.prototype.draw = function(timeStamp) {
	//if game has started
	if (this.timer != undefined && !this.isGameOver()) {
		//increase run time
		Constants.runTime = Constants.runTime + 1;
		this.timer.update();
		
		
		// clear the scene
		this.convasContext.clearRect(0, 0, this.canvas.width, this.canvas.height);		
		this.convasContext.restore();
		
		//draw background
		this.drawBackground();
		//draw heat map
		this.drawHeatMap();
		//draw draw items
		this.drawItems();
		//draw badguys
		this.drawBadguys();
		//draw stores
		this.drawStores();
		//draw hero
		if (!this.isGameOver()) {	
			this.updateHero();
			this.drawHero();
		}
		this.drawDialogs();
		//draw Inventory Screen
		this.drawInventoryScreen();
	}
}

Game.prototype.drawStores = function() {
	var stores = this.stores;
	if (stores != null && stores != undefined) {
		for (var i=0; i < stores.length; i++) {
			var store = stores[i];
			store.draw(this.convasContext);
		}
	}	
}


Game.prototype.drawInventoryScreen = function() {
	var dialogs = this.gameDialogs;
	if (dialogs != null && dialogs != undefined) {
		for (var i=0; i < dialogs.length; i++) {
			var dialog = dialogs[i];
			dialog.displayMessage();
			if (dialog.displayTime <= 0) {
				Constants.removeFromArray(dialog, this.gameDialogs[i]);
			}
		}
	}	
}


Game.prototype.drawDialogs = function() {
	var dialogs = this.gameDialogs;
	if (dialogs != null && dialogs != undefined) {
		for (var i=0; i < dialogs.length; i++) {
			var dialog = dialogs[i];
			dialog.displayMessage();
			if (dialog.displayTime <= 0) {
				Constants.removeFromArray(dialog, this.gameDialogs[i]);
			}
		}
	}	
}

Game.prototype.drawBackground = function() {
	//draw background
	if (this.background != undefined && this.background != null ) {
		this.convasContext.drawImage(this.background, 0, 0, Constants.canvasWidth, Constants.canvasHeight);
	}
}

Game.prototype.drawHeatMap = function() {
	//draw heat map
	if (this.heatMapImage != undefined && this.heatMapImage != null ) {
		this.heatMapCanvasContext.drawImage(this.heatMapImage, 0, 0, Constants.canvasWidth, Constants.canvasHeight);
	}
}

Game.prototype.updateHero = function() {
	//update hero and fireball, punch and kick position 
	this.calculateSpriteOffset(this.hero, this.hero.Speed.x, this.hero.Speed.y);
	this.calculateSpriteDirection(this.hero);
	this.caculateSpritePosition(this.hero);	
	this.caculateSpriteFireball(this.hero);
	this.caculateSpritePunch(this.hero);
	this.caculateSpriteKick(this.hero);
	this.caculateSpritePickupOrSearch(this.hero);
	this.caculateSpriteOpenStore(this.hero);
	this.caculateSpriteOpenInventory(this.hero);
	this.caculateSpritePuchase(this.hero)
	
}

Game.prototype.drawHero = function() {
	//draw fireballs and hero
    this.drawSpriteFireBalls(this.hero);
	this.hero.animate(this.convasContext, this.timer);
	this.hero.draw(this.convasContext);
}

Game.prototype.drawBadguys = function() {
	//draw all the badguys
	if ( this.badguys != null && this.badguys != undefined) {
		for (var b=0; b < this.badguys.length; b++) {
			var badguy = this.badguys[b];
			// if badguy is not dead
			if (!badguy.dead) {
				// collision detection and hit 
				if (this.hero.health > 0) {
					if (badguy.collisionDection(this.hero.Position.x, this.hero.Position.y)) {
						this.hero.hit(badguy.damage);
						if (this.hero.health <= 0) {
							this.gameOver();
						}
					}
					// hero attacks bad guy ( via fireball)
					var hitCount = this.hero.attack(badguy.Position.x, badguy.Position.y)
					if (hitCount > 0) {
						// hero hit the bad guy
						badguy.hit(hitCount * this.hero.damage);
						// if bad guy is now dead
						if (badguy.health <= 0) {
							this.setHeroExperience(badguy.experience);
							//save hero
							this.saveHero();
							
							badguy.dead = true;
							badguy.shown = false;
							Constants.removeFromArray(badguy, this.badguys); 
						}
					}
				}
				if (badguy.health > 0) {
					// calculate new position and draw
					badguy = this.caculateBadGuyPosition(badguy);			
					badguy.animate(this.convasContext, this.timer);
					badguy.draw(this.convasContext);	
				}
			}
		}
	}
}

Game.prototype.drawItems = function() {
	//draw all the items
	if (this.items != null && this.items != undefined) {
		for (var i=0; i < this.items.length; i++) {
			var item = this.items[i];
			item = this.caculateItemPosition(item);			
			item.animate(this.convasContext, this.timer);
			item.draw(this.convasContext);	
		}
	}
}

Game.prototype.setHeroExperience = function(experience) {
	this.hero.experience = this.hero.experience + experience;
	if (this.hero.experience > 100) {
		this.hero.level = this.hero.level + 1;
		this.hero.totalExperience = this.hero.totalExperience + this.hero.experience;
		this.hero.experience = 0;
	}	
}

Game.prototype.getColorAtPoint = function(context, x, y) {
	return context.getImageData(x, y, 1, 1).data;
}

Game.prototype.isValidPath = function(sprite, xOffset, yOffset) {
	var validFound     = false;
	// calculate the future postion of the sprite
	var futurePositionX = sprite.Position.x+xOffset;
	var futurePositionY = sprite.Position.y+yOffset;
	// get the future position point color
	//this is a costly call
	var pointColor = Constants.getColorAtPoint(this.heatMapCanvasContext, futurePositionX + Constants.spritePositionX, futurePositionY + Constants.spritePositionY);			

	document.getElementById('statusFutureRGB').innerHTML = "Future RGB: (" + pointColor[0] + " " + pointColor[1] +" "+ pointColor[2] + ")";	
	
	//if color is yellow - scene change moving down (row + 1) and in the grid and hero sprite
	if (pointColor[0] == 254 && pointColor[1] == 240 && pointColor[2] == 53 && Constants.mapCurrentRow+1 < this.gameRows.length && sprite.spriteType == 12) {
		// valid location to move to down
		Constants.mapCurrentRow = Constants.mapCurrentRow + 1;
		this.setupNewLevel();		
	}	
	//if color is green - scene change moving right (column + 1) and in the grid and hero sprite
	else if (pointColor[0] == 16 && pointColor[1] == 127 && pointColor[2] == 67 && Constants.mapCurrentColumn+1 < this.gameRows[Constants.mapCurrentRow].scenes.length && sprite.spriteType == 12) {
		// valid location to move to right
		Constants.mapCurrentColumn = Constants.mapCurrentColumn + 1;
		this.setupNewLevel();	
	}	
	//if color is purple - scene change moving up (row - 1) and in the grid and hero sprite
	else if (pointColor[0] == 127 && pointColor[1] == 37 && pointColor[2] == 251 && Constants.mapCurrentRow >= 0 && sprite.spriteType == 12) {
		// valid location to move to up
		Constants.mapCurrentRow = Constants.mapCurrentRow - 1;
		this.setupNewLevel();		
	}	
	//if color is orange - scene change moving left (column -1 )  and in the grid and hero sprite
	else if (pointColor[0] == 253 && pointColor[1] == 127 && pointColor[2] == 54 && Constants.mapCurrentColumn >= 0 && sprite.spriteType == 12) {
		// valid location to move to left
		Constants.mapCurrentColumn = Constants.mapCurrentColumn - 1;
		this.setupNewLevel();		
	}	
	//if color is red - can not move
	else if (pointColor[0] == 252 && pointColor[1] == 13 && pointColor[2] == 27) {
		validFound = false;
	}
	//if color is blue - can move
	else if (pointColor[0] == 11 && pointColor[1] == 36 && pointColor[2] == 251) {
		// valid location to move to
		validFound = true;
	}
	else if (pointColor[0] == 0 && pointColor[1] == 0 && pointColor[2] == 0) {
		// valid location to move to
		validFound = true;
	}
	else {
//		alert("strange color found: " + pointColor[0] + ",  " + pointColor[1] + ",  " + pointColor[2]);
	}
    	return validFound;
}

Game.prototype.calculateSpriteOffset = function(sprite, x, y) {
	if (x === 0 && y === 0) { // standing still
		sprite.setOffset(0, 128);
		sprite.setFrames(1);
		sprite.setDuration(0);
	} 
	else if (x > 0 && y === 0) { // East
		if (sprite.offsetY !== 192) {
			sprite.setOffset(0, 192);
			sprite.setFrames(6);
			sprite.setDuration(500);
		}
	} 
	else if (x < 0 && y === 0) { // West
		if (sprite.offsetY !== 224) {
			sprite.setOffset(0, 224);
			sprite.setFrames(6);
			sprite.setDuration(500);
		}
	} 
	else if (x === 0 && y > 0) { // South
		if (sprite.offsetY !== 128 || sprite.frames !== 4) {
			sprite.setOffset(0, 128);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (x === 0 && y < 0) { // North
		if (sprite.offsetY !== 160) {
			sprite.setOffset(0, 160);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (x > 0 && y < 0) { // North East
		if (sprite.offsetY !== 0) {
			sprite.setOffset(0, 0);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (x > 0 && y > 0) { // South East
		if (sprite.offsetY !== 32) {
			sprite.setOffset(0, 32);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (x < 0 && y < 0) { // North West
		if (sprite.offsetY !== 64) {
			sprite.setOffset(0, 64);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (x < 0 && y > 0) { // South West
		if (sprite.offsetY !== 96) {
			sprite.setOffset(0, 96);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	}
}

Game.prototype.calculateSpriteDirection = function(sprite) {
	// Calculate X speed
	if (Constants.inArray(Constants.Keys.RIGHT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.D, Constants.Keys.getDown)) {
		sprite.Speed.x += (sprite.Speed.x <= sprite.Speed.MAX) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.RIGHT;
	} 
	else if (Constants.inArray(Constants.Keys.LEFT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.A, Constants.Keys.getDown)) {
		sprite.Speed.x -= (sprite.Speed.x >= (sprite.Speed.MAX * -1)) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.LEFT;
	} 
	else if (sprite.Speed.x > 0) { // No right / left keys are being pressed
		sprite.Speed.x += sprite.Speed.FRICTION * -1;
		sprite.Speed.x = (sprite.Speed.x < 0) ? 0 : sprite.Speed.x;
	}
	else if (sprite.Speed.x < 0) {
		sprite.Speed.x += sprite.Speed.FRICTION;
		sprite.Speed.x = (sprite.Speed.x > 0) ? 0 : sprite.Speed.x;
	}

	// Calculate Y speed
	if (Constants.inArray(Constants.Keys.DOWN, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.S, Constants.Keys.getDown)) {
		sprite.Speed.y += (sprite.Speed.y <= sprite.Speed.MAX) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.DOWN;
	} 
	else if (Constants.inArray(Constants.Keys.UP, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.W, Constants.Keys.getDown)) {
		sprite.Speed.y -= (sprite.Speed.y >= (sprite.Speed.MAX * -1)) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.UP;
	} 
	else if (sprite.Speed.y > 0) { // No up / down keys are being pressed
		sprite.Speed.y += sprite.Speed.FRICTION * -1;
		sprite.Speed.y = (sprite.Speed.y < 0) ? 0 : sprite.Speed.y;
	} 
	else if (sprite.Speed.y < 0) {
		sprite.Speed.y += sprite.Speed.FRICTION;
		sprite.Speed.y = (sprite.Speed.y > 0) ? 0 : sprite.Speed.y;
	}
}

Game.prototype.caculateSpritePosition = function(sprite) {
	if (this.isValidPath(sprite, sprite.Speed.x, sprite.Speed.y)) {
		sprite.Position.x += sprite.Speed.x;
		sprite.Position.y += sprite.Speed.y;		
	}
	sprite.setPosition(sprite.Position.x, sprite.Position.y);
}

Game.prototype.caculateSpritePuchase = function(hero) {
	var stores = this.stores;
	if (stores != null && stores != undefined) {
		for (var i=0; i < stores.length; i++) {
			var store = stores[i];
			if (store.displayInventory) {
				//for all stores inventory 
				for (var i=0; i < store.inventory.inventory.length; i++) {
					var items = store.inventory.inventory[i];
					for (var c=0; c < items.length; c++) {
						var item = items[c];
						if (item.saleNumber && Constants.NumberKeyLookup[item.saleNumber] && Constants.inArray(Constants.NumberKeyLookup[item.saleNumber], Constants.Keys.getDown)) {
							Constants.removeFromArray(Constants.NumberKeyLookup[item.saleNumber], Constants.Keys.getDown);	
							store.customerBuysItem(hero, item);
							//save hero
							this.saveHero();
						}
					}
				}	
			}
		}
	}
}

Game.prototype.caculateSpriteOpenInventory = function(hero) {
	if (Constants.inArray(Constants.Keys.I, Constants.Keys.getDown)) {
		//draw Inventory Background Image
		this.convasContext.drawImage(this.inventoryBackgroundImage, 
     			0, 
	     		0,
				400,
				400, 
				100, 
				100, 
				400, 
				400);		
		
		//for all heros inventory 
		for (var i=0; i < this.hero.inventory.inventory.length; i++) {
			var items = this.hero.inventory.inventory[i];
			for (var c=0; c < items.length; c++) {
				var item = items[c];
				item.draw();
			}
		}
	}
}

Game.prototype.caculateSpriteOpenStore = function(hero) {
	if (Constants.inArray(Constants.Keys.T, Constants.Keys.getDown)) {
		var stores = this.stores;
		if (stores != null && stores != undefined) {
			for (var i=0; i < stores.length; i++) {
				var store = stores[i];
				if (store.collisionDection(this.hero.Position.x, this.hero.Position.y)) {
					store.displayInventory = !store.displayInventory;
					Constants.removeFromArray(Constants.Keys.T, Constants.Keys.getDown);	
				}
			}
		}	
	}
}

Game.prototype.caculateSpritePickupOrSearch = function(hero) {
	if (Constants.inArray(Constants.Keys.F, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.P, Constants.Keys.getDown)) {
		for (var i=0; i < this.items.length; i++) {
			var item = this.items[i];
			if (item.collisionDection(this.hero.Position.x, this.hero.Position.y)) {
				if ( item.isGold == 1 ) {
					this.hero.inventory.addGold(item.inventory.gold);
					var scoreOverlay = new Dialog(this.convasContext, item.Position.x, item.Position.y, item.Position.z, "You found " + item.inventory.gold + " gold pieces.", null);
					this.gameDialogs.push( scoreOverlay );
					scoreOverlay.displayMessage();					
					//save hero
					this.saveHero();			
				}
				else {
					var itemTypeOverlay = new Dialog(this.convasContext, item.Position.x, item.Position.y, item.Position.z, "You found a " + item.name + '.', null);
					this.gameDialogs.push( itemTypeOverlay );
					itemTypeOverlay.displayMessage();
					if (item.spriteType == Constants.SpriteType.EasterEgg) {
						//save hero
						this.saveHero();
						this.gameWon();
					}
					else {
						this.hero.inventory.addInventoryItem(item);
					}

				}
				item.shown = false;
				
				Constants.removeFromArray(item, this.items);		
			}
		}
	}
}

Game.prototype.caculateSpriteFireball = function(sprite) {
	if (Constants.inArray(Constants.Keys.SHIFT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.SPACE, Constants.Keys.getDown)) {
		sprite.shootFireball( new Sprite('game_lib/img/fireball.png', 36, 36, 0, 0, 5, 0), sprite.Position.x, sprite.Position.y, sprite.direction);
	}
}

Game.prototype.drawSpriteFireBalls = function(sprite) {
	if (sprite.fireballCount > 0) {
		for (var f = 0; f < sprite.fireballs.length; f++) {
			var fb = sprite.fireballs[f];
			if (fb) {
				if (Constants.pointDistance(fb.Position.x, fb.Position.y, fb.startPosition.x, fb.startPosition.y) < 100) {
					fb.Position.x = (fb.direction == Constants.Direction.LEFT) ? fb.Position.x - 1: fb.Position.x + 1;
					fb.setPosition(fb.Position.x, fb.Position.y);
					fb.animate(this.convasContext, this.timer);
					fb.draw(this.convasContext);
				}
				else {
					Constants.removeFromArray(fb, sprite.fireballs);
					sprite.fireballCount = sprite.fireballCount - 1;
					sprite.magic = sprite.magic + 10;
				}
			}
		}
	}
}

Game.prototype.caculateSpriteKick = function(sprite) {
	if (sprite.action == Constants.Action.KICK && sprite.actionCount == 0) {
		sprite.action = Constants.Action.STANDING;
	}
	else if (Constants.inArray(Constants.Keys.K, Constants.Keys.getDown)) {
		if (sprite.direction == Constants.Direction.RIGHT) {
			sprite.setOffset(0, 256);
		}
		else if (sprite.direction == Constants.Direction.LEFT) {
			sprite.setOffset(0, 288);
		}
		sprite.setFrames(4);
		sprite.setDuration(500);
		sprite.action = Constants.Action.KICK;
		sprite.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (sprite.action == Constants.Action.KICK) {
		sprite.actionCount = sprite.actionCount - 1; 
	}	
}

Game.prototype.caculateSpritePunch = function(sprite) {
	if (sprite.action == Constants.Action.PUNCH && sprite.actionCount == 0) {
		sprite.action = Constants.Action.STANDING;
	}
	else if (Constants.inArray(Constants.Keys.P, Constants.Keys.getDown)) {
		if (sprite.direction == Constants.Direction.RIGHT) {
			sprite.setOffset(0, 320);
		}
		else if (sprite.direction == Constants.Direction.LEFT) {
			sprite.setOffset(0, 352);
		}
		sprite.setFrames(4);
		sprite.setDuration(500);
		sprite.action = Constants.Action.PUNCH;
		sprite.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (sprite.action == Constants.Action.PUNCH) {
		sprite.actionCount = sprite.actionCount - 1; 
	}	
}

Game.prototype.caculateItemPosition = function(sprite) {
	sprite.Position.x = sprite.Position.x;
	sprite.Position.y = sprite.Position.y;		
	sprite.setPosition(sprite.Position.x, sprite.Position.y);
	return sprite;
}

Game.prototype.caculateBadGuyPosition = function(badguy) {
    // line of sight? or maybe distance
	var distance = Constants.pointDistance(badguy.Position.x, badguy.Position.y, this.hero.Position.x, this.hero.Position.y);
    if (distance <= 150) {
		var bX = badguy.Position.x;
		var bY = badguy.Position.y;
		var hX = this.hero.Position.x;
		var hY = this.hero.Position.y;
		var futurePositionBX = bX;
		var futurePositionBY = bY;
		
		var changeFound = false;
		if (hX > bX && hY > bY) {
			if (this.isValidPath(badguy, 1, 1)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}
			else if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, -1)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX < bX && hY < bY) {
			if (this.isValidPath(badguy, -1, -1)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}
			else if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX == bX && hY > bY) {
			if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX == bX && hY < bY) {	
			if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
		}	
		if (!changeFound && hX > bX && hY < bY) {
		    if (this.isValidPath(badguy, 1, -1)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, +1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX < bX && hY > bY) {
			if (this.isValidPath(badguy, -1, +1)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX > bX && hY == bY) {
			if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
		}
		if (!changeFound && hX < bX && hY == bY) {
			if (this.isValidPath(badguy, -1, 0)) {
				futurePositionBX = bX-1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 1, 0)) {
				futurePositionBX = bX+1;
				futurePositionBY = bY;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, 1)) {
				futurePositionBX = bX;
				futurePositionBY = bY+1;
	    			changeFound = true;			
			}	
			else if (this.isValidPath(badguy, 0, -1)) {
				futurePositionBX = bX;
				futurePositionBY = bY-1;
	    			changeFound = true;			
			}	
		}
		this.setBadguyPosition(badguy, futurePositionBX, futurePositionBY);
    }
	return badguy;
}

Game.prototype.setBadguyPosition = function(badguy, x,y) {
	badguy.Position.x = x;
    badguy.Position.y = y;
	badguy.setPosition(x, y);		
}

Game.prototype.isGameOver = function() {
	// no badguys left
    if (this.badguys != undefined && this.badguys != null && this.badguys.length == 0 && this.gameMode == 'kill') {
    	   Constants.boardLevel = Constants.boardLevel + 1;
    	   this.setupNewLevel();
	}	
	return this.hero.dead;
}

Game.prototype.gameOver = function() {
	this.hero.dead = true;
	this.hero.shown = false;

	//invert background image color
	var imgData=this.convasContext.getImageData(0,0,Constants.canvasWidth,Constants.canvasHeight);
	// invert colors
	for (var i=0;i<imgData.data.length;i+=4)
	  {
	  imgData.data[i]=255-imgData.data[i];
	  imgData.data[i+1]=255-imgData.data[i+1];
	  imgData.data[i+2]=255-imgData.data[i+2];
	  imgData.data[i+3]=255;
	  }
	this.convasContext.putImageData(imgData,0,0);
	
	alert("Game Over");	
}

Game.prototype.gameWon = function() {
	alert("You Win!!!");	
	// call window reload
	window.location.reload();
	
}

Game.prototype.saveGame = function() {
	//save the hero and bad guy states to be able to load a game
	if (this.ableToSave) {
		localStorage.setItem("heroId", this.hero.id);
		//localStorage.setItem("gameLastRunTime", Constants.lastRunTime);
		//localStorage.setItem("gameLastSecond", Constants.lastSecond);
		//localStorage.setItem("gameRunTime", Constants.runTime);
		localStorage.setItem("gameBoardLevel", Constants.boardLevel);
		localStorage.setItem("gameBoardRow", Constants.mapCurrentRow);
		localStorage.setItem("gameBoardColumn", Constants.mapCurrentColumn);
		alert("Game Saved.");
	}
	else {
		alert("Your browser does not support location storage. Update your browser.")
	}
}

Game.prototype.loadGame = function() {
	if (localStorage.getItem("gameBoardLevel")) {
		this.loadHero(parseInt(localStorage.getItem("heroId")));
		Constants.boardLevel = parseInt(localStorage.getItem("gameBoardLevel"));		
		Constants.mapCurrentRow = parseInt(localStorage.getItem("gameBoardRow"));		
		Constants.mapCurrentColumn = parseInt(localStorage.getItem("gameBoardColumn"));	
		alert("Game Loaded.");
	}
}

Game.prototype.setBadguys = function(badguys) {
    if (badguys) {
	    this.badguys = badguys;
		for (var g=0;g<badguys.length;g++) {
		    var gameBadGuy = badguys[g];
		    if (typeof gameBadGuy == "object" && Object.getPrototypeOf(gameBadGuy) !== Sprite.prototype ) {
		    		this.badguys[g] = new Sprite(gameBadGuy.source, gameBadGuy.width, gameBadGuy.height, gameBadGuy.offsetX, gameBadGuy.offsetY, gameBadGuy.frames, gameBadGuy.duration, gameBadGuy.spriteType, gameBadGuy.startPositionX, gameBadGuy.startPositionY, gameBadGuy.health, gameBadGuy.experience, gameBadGuy.level, gameBadGuy.healthOverlayShown, gameBadGuy.isGold, gameBadGuy.gold, gameBadGuy.name);
		    }		
		}
	}  	
}

Game.prototype.setItems = function(items) {
    if (items) {
	    this.items = items;
		for (var g=0;g<items.length;g++) {
		    var gameItem = items[g];
		    if (typeof gameItem == "object" && Object.getPrototypeOf(gameItem) !== Sprite.prototype ) {
		    		this.items[g] = new Sprite(gameItem.source, gameItem.width, gameItem.height, gameItem.offsetX, gameItem.offsetY, gameItem.frames, gameItem.duration, gameItem.spriteType, gameItem.startPositionX, gameItem.startPositionY, gameItem.health, gameItem.experience, gameItem.level, gameItem.healthOverlayShown, gameItem.isGold, gameItem.gold, gameItem.name); 
		    }		
		}
	}  	
}

Game.prototype.setStores = function(stores) {
    if (stores) {
	    this.stores = stores;
		for (var g=0;g<stores.length;g++) {
		    var gameStore = stores[g];
		    if (typeof gameStore == "object" && Object.getPrototypeOf(gameStore) !== Store.prototype ) {
		    		var inventory = new Inventory();
		    	    this.stores[g] = new Store(gameStore.source, gameStore.width, gameStore.height, gameStore.offsetX, gameStore.offsetY, gameStore.spriteType, gameStore.startPositionX, gameStore.startPositionY, gameStore.gold, gameStore.name, inventory);
		    }		
		}
	}  	
}

Game.prototype.resetGame = function() {
	for (var f = this.hero.fireballs.length-1; f >= 0; f--) {
		var fb = this.hero.fireballs[f];
		Constants.removeFromArray(fb, this.hero.fireballs);
	}

	for (var f = Constants.Keys.getDown.length-1; f >= 0; f--) {
		var kd = Constants.Keys.getDown[f];
		Constants.removeFromArray(kd, Constants.Keys.getDown);
	}	

	for (var f = this.gameDialogs.length-1; f >= 0 ; f--) {
		var kd = this.gameDialogs[f];
		Constants.removeFromArray(kd, this.gameDialogs);
	}	
	
	this.hero.Position.x = 400;
	this.hero.Position.y = 300;	
}

Game.prototype.intilizeCanvas = function() {
	this.setBackground(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].background);
	this.setHeatMap(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].heatMap);
	this.setBadguys(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].badguys);
	this.setStores(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].stores);
	this.setItems(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].items);
}

Game.prototype.setupNewGame = function() {
	Constants.boardLevel = 1;
	Constants.runTime = 1;
	Constants.mapCurrentRow = 0;
	Constants.mapCurrentColumn = 0;
	this.intilizeCanvas();
	// setup game timer
	this.timer = new Timer();
}

Game.prototype.setupNewLevel = function() {
	this.resetGame();
	this.intilizeCanvas();
}