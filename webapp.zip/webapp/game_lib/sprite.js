// A generic sprite class

var Sprite = function(src, width, height, offsetX, offsetY, frames, duration, spriteType, startPositionLatitude, startPositionLongitude, health, experience, level, healthOverlayShown, isGold, gold, name, id, totalExperience, map, randomizeLocation) {
	this.source = src;
	this.width = width;
	this.height = height;
	this.offsetX = offsetX;
	this.offsetY = offsetY;
	this.frames = frames;
	this.duration = duration;
	this.startPositionLongitude = startPositionLongitude;
	this.startPositionLatitude = startPositionLatitude;
	this.health = health;
	this.experience = experience;
	this.level = level;
	this.isGold = isGold;
	this.gold = gold;
	this.totalExperience = 0;
	
	this.id = id;
	this.name = name;
	this.spriteType = spriteType;
	this.healthOverlayShown = healthOverlayShown;
	this.saleNumber = 0;
		// create the speed object
	// need to move into sprite
	this.Speed = {
		latitude: 0,
		longitude: 0,
		elevation: 0,
		MAX: 2,
		FRICTION: 0.25,
		INCREASE: 0.25
	}

	this.Position = {
		id: null,
		latitude: 285,
		longitude: 290,
		elevation: 0
	}
	this.Position.longitude = startPositionLongitude; 
	this.Position.latitude = startPositionLatitude; 

	this.health = 100;
	if (health) {
		 this.health = health;
	}
	this.experience = 0;
	if (experience) {
		 this.experience = experience;
	}

	this.level = 0;
	if (level) {
		 this.level = level;
	}	

	this.magic = 100;
	this.damage = 5;
	this.dead = false;

	this.communication = [];
	this.fireballs = [];
	this.fireballCount = 0;
	this.direction = Constants.Direction.LEFT;
	this.action = Constants.Action.STANDING;
	
	//new feature inventory
	// maybe create an array of json objects to contain different areas of the inventory
	// 
	this.inventoryType = null;
	this.inventory = new Inventory();
	this.isGold = isGold;
	this.inventory.gold = gold;
	this.cost = gold;
	
	this.spritesheet = null;
	this.offsetX = 0;
	this.offsetY = 0;
	this.width = width;
	this.height = height;
	this.frames = 1;
	this.currentFrame = 0;
	this.duration = 1;
	this.shown = true;
	this.zoomLevel = 1;
	this.shadow = null;
	this.displaySaleLabel = false;

	this.setSpritesheet(src);
	this.setOffset(offsetX, offsetY);
	this.setFrames(frames);
	this.setDuration(duration);
	
	var d = new Date();
	if (this.duration > 0 && this.frames > 0) {
		this.ftime = d.getTime() + (this.duration / this.frames);
	} else {
		this.ftime = 0;	
	}
	
	this.createSpriteMapMarker(map, randomizeLocation);
	
}

Sprite.prototype.createSpriteMapMarker = function(map, randomize) {
	this.markerCount = this.markerCount + 1;
	
	var offsetValueLat = 0;
	var offsetValueLong = 0;
	if (randomize) {
		offsetValueLat = (diceController.roll(1, 1, true) + 1/10);
		offsetValueLong = (diceController.roll(1, 1, true) + 1/10);
	}
	
	if (this.latitude && this.longitude) {
		this.latitude = this.latitude + offsetValueLat;
		this.longitude	 = this.longitude + offsetValueLong;
	}
	else if (this.startPositionLatitude && this.startPositionLongitude) {
		this.latitude = this.startPositionLatitude + offsetValueLat;
		this.longitude = this.startPositionLongitude + offsetValueLong;
	}
	else if (battleChasersController.userLocation) {
    		this.latitude = battleChasersController.userLocation.coords.latitude + offsetValueLat;
    		this.longitude = battleChasersController.userLocation.coords.longitude + offsetValueLong;
	}
	else {
		this.latitude = 0 + offsetValueLat;
		this.longitude = 0 + offsetValueLong;
	}
	
	this.createSpriteMarker(map);

}

Sprite.prototype.createSpriteMarker = function(map) {
    
    var marker = new google.maps.Marker({
        position: {lat: this.latitude, lng: this.longitude},
        map: map,
        icon:  {
	    		url: this.source,
	    	    size: new google.maps.Size(this.width, this.height),
	    	    origin: new google.maps.Point(this.offsetX, this.offsetY),
	    	    anchor: new google.maps.Point(0, this.height)
    		}
    });
    
	var infoWindow = new google.maps.InfoWindow({ content: this.name });

    marker.addListener('click', function() {
        //for (var w=0;w<battleChasersController.infoWindowList.length;w++) {
        //		battleChasersController.infoWindowList[w].close();
        //}
        infoWindow.open(map, marker);
    });
    
    //battleChasersController.infoWindowList.push(infoWindow);    
    
    this.infoWindow = infoWindow;
    this.marker = marker;

} 

Sprite.prototype.setSpritesheet = function(src) {
	if (src instanceof Image) {
		this.spritesheet = src;
	} else {
		this.spritesheet = new Image();
		this.spritesheet.src = src;
	}
}

Sprite.prototype.hit = function(attackAmount) {
    this.health = this.health - attackAmount;
	return this.health;
}

Sprite.prototype.shootFireball = function(e, eX, eY, eDirection) {
	var successful = false;
	if (this.fireballCount < 10) {
		this.magic = this.magic - 10;
		e.direction = eDirection;
		e.Position.latitude = eX;
		e.Position.longitude = eY;
		e.startPosition = { x: eX, y: eY };
		this.fireballs[this.fireballCount] = e;
		this.fireballCount = this.fireballCount + 1;
	}
	return successful;
}

Sprite.prototype.attack = function(eX, eY) {
	var hitCount = 0;
	if (this.fireballCount > 0) {
		for (var f = 0; f < this.fireballs.length; f++) {
			var fireball = this.fireballs[f];
			if (fireball && fireball.collisionDection(eX, eY)) {
				hitCount = hitCount + 1;
			}
		}
	}
	else if ((this.action == Constants.Action.Kick || this.action == Constants.Action.Punch) && this.collisionDection(eX, eY)) {
		hitCount = hitCount + 1;
	}
	return hitCount;
}

Sprite.prototype.collisionDection = function (cX, cY) {
    return this.longitude <= cX && cX <= this.longitude + (this.height/1000) &&
    		this.latitude <= cY && cY <= this.latitude + (this.width/1000);   
}

Sprite.prototype.setPosition = function(latitude, longitude) {
	this.Position.latitude = latitude;
	this.Position.longitude = longitude;
}

Sprite.prototype.getPosition = function() {
	return this.Position;
}

Sprite.prototype.setOffset = function(x, y) {
	this.offsetX = x;
	this.offsetY = y;
}

Sprite.prototype.setFrames = function(fcount) {
	this.currentFrame = 0;
	this.frames = fcount;
}

Sprite.prototype.setDuration = function(duration) {
	this.duration = duration;
}

Sprite.prototype.animate = function(c, t) {
	if (t.getMilliseconds() > this.ftime) {
		this.nextFrame ();
	}
}

Sprite.prototype.nextFrame = function() {	
	if (this.duration > 0) {
		var d = new Date();

		if (this.duration > 0 && this.frames > 0) {
			this.ftime = d.getTime() + (this.duration / this.frames);
		} else {
			this.ftime = 0;	
		}

		this.offsetX = this.width * this.currentFrame;
		
		if (this.currentFrame === (this.frames - 1)) {
			this.currentFrame = 0;
		} else {
			this.currentFrame++;
		}
	}
}

Sprite.prototype.draw = function(c) {
	if (this.shown) {
		/*
		c.drawImage(this.spritesheet, 
					this.offsetX, 
					this.offsetY, 
					this.width,
					this.height, 
					this.Position.latitude, 
					this.Position.longitude, 
					this.width * this.zoomLevel, 
					this.height * this.zoomLevel);
		this.drawHealthOverlay(c);
		this.drawSaleOverlay(c, this.saleNumber);
		this.drawSpriteBorder(c);
		*/
	}
		
}

Sprite.prototype.drawHealthOverlay = function(context) {
	//if (this.healthOverlayShown) {
	// draw a dialog over the hero with the health of the hero
	if (this.spriteType == Constants.SpriteType.Hero || this.spriteType == Constants.SpriteType.Boss || this.spriteType == Constants.SpriteType.Pawn) {
		//                              context, x, y, z, spriteSheet 
		this.healthOverlay = new Dialog(context, this.Position.latitude, this.Position.longitude, this.Position.elevation, this.health, null);
		this.healthOverlay.displayMessage();
	}
	
	//if (this.spriteType == Constants.SpriteType.Hero) {
	//	this.drawPictureInPicture(context, this.Position.x, this.Position.y, this.width, this.height);
	//}
	//}
}

Sprite.prototype.drawSaleOverlay = function(context, label) {
	if (this.displaySaleLabel) {
		//                              context, x, y, z, spriteSheet 
		this.salesOverlay = new Dialog(context, this.Position.latitude, this.Position.longitude, this.Position.elevation, label, null);
		this.salesOverlay.displayMessage('white');
	}
}

Sprite.prototype.drawSpriteBorder = function(context) {
	//bug where the canvas does not clear so it creates streaks of black
	//c.rect(this.Position.x, this.Position.y,this.width,this.height);
    //c.stroke();

	// get the data
//	var imgData = context.getImageData(this.Position.x,this.Position.y);
//	imgData[0] = 255;
//	imgData[1] = 255;
//	imgData[2] = 255;
//	imgData[3] = 255;
	// draw border
	
}

Sprite.prototype.drawPictureInPicture = function(context, latitude, longitude, width, height) {
	if (longitude == undefined) {
		longitude = this.Position.longitude;
	}
	if (latitude == undefined) {
		latitude = this.Position.latitude;
	}
	if (width == undefined) {
		width = this.width;
	}
	if (height == undefined) {
		height = this.height;
	}
	
	// get the data
	var imgData = context.getImageData(latitude,longitude,width,height);
	// draw border colors
	for ( var p=longitude; p<=longitude+width; p++ ) {
	  imgData.data[p]=255;
	}
	for ( var p=latitude; p<=latitude+height; p++ ) {
		  imgData.data[p]=255;
	}
	context.putImageData(imgData,0,0);	
	
}
 
 