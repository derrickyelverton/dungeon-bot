/**
 * A simple timer
 */

function Utils() {

}

Utils.prototype.getRequestParameter = function(name){
	   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
	      return decodeURIComponent(name[1]);
}