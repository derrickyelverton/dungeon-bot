//function Dialog(context, x, y, z, message, spriteSheet) {
function Dialog(context, latitude, longitude, elevation, message, spriteSheet) {
	this.context = context;
//	this.x = x;
//	this.y = y;
//	this.z = z;
	this.latitude = latitude;
	this.longitude = longitude;
	this.elevation = elevation;
	this.displayTime = 200;  // frames maybe 60 a second so 3 ish seconds
	this.message = message;
    this.spriteSheet = 'game_lib/img/backgroundLevel1.png'
}

Dialog.prototype.displayMessage = function(map) {
	/*
    this.context.font = '8pt Calibri';
    this.context.textAlign = 'center';
    if (color != null && color != undefined && color != '') {
    	    this.context.fillStyle = color;
    }
    this.context.fillText(this.message + "", this.x, this.y);
    this.displayTime = this.displayTime - 1;
    */
	this.createSpriteMarker(map);
}

Dialog.prototype.createSpriteMarker = function(map, marker) {
    
	var infoWindow = new google.maps.InfoWindow({ content: this.name });
    infoWindow.open(map, marker);
    this.infoWindow = infoWindow;

} 