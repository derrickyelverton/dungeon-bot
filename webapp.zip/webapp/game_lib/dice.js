
var diceController = null;

function Dice() {
	
}
/*
Dice.prototype.roll = function(numberOfDice, sided) {
	var totalCount = 0;
	for (var d = 0; d < numberOfDice; d ++) { 
		var value = Math.random() * 10;
		totalCount = totalCount + Math.round(value);
	}
	return totalCount;
}
*/
Dice.prototype.roll = function(numberOfDice, sided, includeNegative) {
	var totalCount = 0;
	var isNegative = false;
	if (includeNegative) {
		isNegative = Math.floor(Math.random() * Math.floor(2));
	}

	for (var d = 0; d < numberOfDice; d ++) { 
		var value = Math.floor(Math.random() * Math.floor(sided));
		totalCount = totalCount + Math.round(value);
	}
	return (isNegative)?totalCount:-totalCount;
}
