var Inventory = function(inventory, id, gold, items) {
    this.id = id;
    this.items = items;
	this.inventory = [];
	this.gold = 0;
	
	if (gold != undefined) {
		this.gold = gold;
	}
	
	if (inventory) {
		this.inventory = inventory;
	}
	else {
		
		var weapons = [];
		var chests = [];
		var pants = [];
		var shoes = [];
		var gloves = [];
		var rings = [];
		var necklaces = [];
		var items = [];
		var potions = [];
		var keys = [];
	
		this.inventory.push(weapons);
		this.inventory.push(chests);
		this.inventory.push(pants);
		this.inventory.push(shoes);
		this.inventory.push(gloves);
		this.inventory.push(rings);
		this.inventory.push(necklaces);
		this.inventory.push(items);
		this.inventory.push(potions);
		this.inventory.push(keys);
	}
	
}

Inventory.prototype.addGold = function(gold) {
	this.gold = this.gold + gold;
}

Inventory.prototype.addInventoryItem = function(item) {
	this.inventory[item.spriteType].push(item);
}

Inventory.prototype.getInventoryItems = function(inventoryType) {
	return this.inventory[this.spriteType];
}