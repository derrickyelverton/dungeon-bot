var Store = function(src, width, height, offsetX, offsetY, spriteType, startPositionLongitude, startPositionLatitude, gold, name, inventory, map, randomizeLocation) {
	this.source = src;
	this.startPositionLongitude = startPositionLongitude;
	this.startPositionLatitude = startPositionLatitude;
	this.gold = gold;
	
	this.Position = {
		latitude: startPositionLatitude,
		longitude: startPositionLongitude,
		elevation: 0,
		width: width,
		height: height
	}
	this.startPosition = this.Position;
	
	this.displayInventory = false;
	this.name = name;
	this.spriteType = spriteType;
	this.width = width;
	this.height = height;
	this.duration = 1;
	this.shown = true;
	this.zoomLevel = 1;
	this.offsetX = offsetX;
	this.offsetY = offsetY;	
	this.setImage(src);
	this.setStoreBackgroundImage('game_lib/img/storeBackground.png');

	this.communication = ["Hello, welcome to our store.  What would you like to buy?"];
	
	if (inventory) {
		this.inventory = inventory;
	}
	else {
		this.inventory = new Inventory();
	}
	
	this.inventory.inventory[Constants.SpriteType.Weapon].push(new Sprite('game_lib/img/sword.png', 32, 32, 0, 128, 1, 0, Constants.SpriteType.Weapon, 360, 160, 1, 10, 1, false, false, 0, 'Sword', 13),
			new Sprite('game_lib/img/swordOfFire.png', 32, 32, 0, 128, 1, 0, Constants.SpriteType.Weapon, 400, 160, 1, 10, 1, false, false, 0, 'Sword of Fire', 14));
	
	this.inventory.gold = gold;
	
	this.createSpriteMapMarker(map);
}

Store.prototype.createSpriteMapMarker = function(map, randomize) {
	this.markerCount = this.markerCount + 1;
	
	var offsetValueLat = 0;
	var offsetValueLong = 0;
	if (randomize) {
		offsetValueLat = diceController.roll(1, 12, true);
		offsetValueLong = diceController.roll(1, 12, true);
	}
	
	if (this.latitude && this.longitude) {
		this.latitude = this.latitude + offsetValueLat;
		this.longitude	 = this.longitude + offsetValueLong;
	}
	else if (this.startPositionLatitude && this.startPositionLongitude) {
		this.latitude = this.startPositionLatitude + offsetValueLat;
		this.longitude = this.startPositionLongitude + offsetValueLong;
	}
	else if (battleChasersController.userLocation) {
    		this.latitude = battleChasersController.userLocation.coords.latitude + offsetValueLat;
    		this.longitude = battleChasersController.userLocation.coords.longitude + offsetValueLong;
	}
	else {
		this.latitude = 0 + offsetValueLat;
		this.longitude = 0 + offsetValueLong;
	}
	
	this.createSpriteMarker(map);

}

Store.prototype.createSpriteMarker = function(map) {
    
    var marker = new google.maps.Marker({
        position: {lat: this.latitude, lng: this.longitude},
        map: map,
        icon:  {
	    		url: this.source,
	    	    size: new google.maps.Size(this.width, this.height),
	    	    origin: new google.maps.Point(this.offsetX, this.offsetY),
	    	    anchor: new google.maps.Point(0, this.height)
    		}
    });
    
	var infoWindow = new google.maps.InfoWindow({ content: this.name });

    marker.addListener('click', function() {
        //for (var w=0;w<battleChasersController.infoWindowList.length;w++) {
        //		battleChasersController.infoWindowList[w].close();
        //}
        infoWindow.open(map, marker);
    });
    
    //battleChasersController.infoWindowList.push(infoWindow);    
    
    this.infoWindow = infoWindow;
    this.marker = marker;

} 

Store.prototype.collisionDection = function (cX, cY) {
    return this.longitude <= cX && cX <= this.longitude + (this.height/1000) &&
		this.latitude <= cY && cY <= this.latitude + (this.width/1000);
/*	
    return this.Position.x <= cX && cX <= this.Position.x + this.width &&
           this.Position.y <= cY && cY <= this.Position.y + this.height;
           */
}

Store.prototype.customerBuysItem = function(sprite, item) {
	if (sprite.inventory.gold < item.cost) {
		alert('You do not have enough gold to buy this item.');
	}
	else {
		alert('You bought a ' + item.name);
		sprite.inventory.inventory[item.spriteType].push(item);
		sprite.inventory.items.push({inventoryId: sprite.inventory.id, itemsId: item.id});
		//sprite.inventory.items.push({inventory_id: sprite.inventory.id, items_id: item.id});
		//sprite.inventory.items.push(item);
		sprite.inventory.gold = sprite.inventory.gold - item.cost;	
		this.inventory.gold = this.inventory.gold + item.cost;
	}
	return sprite;
}

Store.prototype.customerSellsItem = function(sprite, item) {
	if (this.inventory.gold < item.cost) {
		alert("Sorry we dont have enough gold to buy that item");
	}
	else {
		alert('Thank you for selling us the ' + item.name + '. We sell it to a good home.');
		sprite.removeInventoryItem(item);
		//Constants.removeFromArray(sprite.inventory.items, item);
		Constants.removeFromArray(sprite.inventory.items, {inventoryId: sprite.inventory.id, itemsId: item.id});
		//Constants.removeFromArray(sprite.inventory.items, {inventory_id: sprite.inventory.id, items_id: item.id});
		this.inventory.inventory[item.spriteType].push(item);
		this.inventory.gold = this.inventory.gold - item.cost;
		sprite.inventory.gold = sprite.inventory.gold + item.cost;
	}
	return sprite;
}

Store.prototype.addInventoryItem = function(item) {
	this.inventory[item.spriteType].push(item);
}

Store.prototype.getInventoryItems = function(inventoryType) {
	return this.inventory[this.spriteType];
}

Store.prototype.setImage = function(src) {
	if (src instanceof Image) {
		this.image = src;
	} else {
		this.image = new Image();
		this.image.src = src;
	}
}


Store.prototype.setStoreBackgroundImage = function(src) {
	if (src instanceof Image) {
		this.storeBackgroundImage = src;
	} else {
		this.storeBackgroundImage = new Image();
		this.storeBackgroundImage.src = src;
	}
}

Store.prototype.draw = function(c) {
	if (this.shown) {
		/*
		c.drawImage(this.image, 
	     			this.offsetX, 
		     		this.offsetY,
					this.width,
					this.height, 
					this.Position.latitude, 
					this.Position.longitude, 
					this.width, 
					this.height);
		if (this.displayInventory) {
			c.drawImage(this.storeBackgroundImage, 
	     			0, 
		     		0,
					300,
					400, 
					300, 
					80, 
					300, 
					400);
			var saleNumber = 0;
			//for all stores inventory 
			if (this.inventory && this.inventory.inventory) {
				for (var i=0; i < this.inventory.inventory.length; i++) {
					var items = this.inventory.inventory[i];
					for (var b=0; b < items.length; b++) {
						var item = items[b];
						saleNumber = saleNumber  + 1;
						item.saleNumber = saleNumber;
						item.displaySaleLabel = true;
						item.draw(c);
					}
				}
			}
		}
		*/
	}
}