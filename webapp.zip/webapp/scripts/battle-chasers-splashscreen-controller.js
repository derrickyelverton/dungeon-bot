/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('BattleChasersSplashScreenController', ['$scope', '$rootScope', '$state', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $state, $stateParams, GameService) {

        'use strict';

		$scope.gameName = "Battle Chasers";      
        
        $scope.startBattleChasers = function() {
//        	   $state.go('battle-chasers', {playerName: document.getElementById('playerName').value});
        	   $state.go('battle-chasers');
        };        
        
        $scope.continueBattleChaser = function() {
     	   $state.go('battle-chasers');
        };
        
    }
]);

