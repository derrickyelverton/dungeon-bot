(function () {

	'use strict';

	var BattleChasersWebApp = angular.module('BattleChasersWebApp' , ['SATURNNIGHT.security_service', 'ngRoute', 'ngResource', 'ngCookies', 'ngSanitize', 'ui.router' /*'kendo.directives'*/]);
	BattleChasersWebApp.config(['$stateProvider', '$urlRouterProvider',
		function ($stateProvider, $urlRouterProvider) {

			$urlRouterProvider.otherwise('/battleChasers');

			// flow
			// 1 create user
			// 2 login - validate the user against db
			// 3 select or create player
			// 4 select or create deck, 5 view cards
			// 6 create deck - 7 add cards to deck
			// 8 select or create game, 9 settings
			// 10 game
			// 11 game over
			// back to 4
		
			$stateProvider
			.state('arcade-game-list', {
				url: '/arcadeGameList',
				templateUrl: './views/arcade-game-list.html',
				controller: 'ArcadeGameListController',
				isSecure: true
			})	
			.state('game', {
				url: '/game',
				templateUrl: './views/game.html',
				controller: 'GameController',
				isSecure: true
			})	
			.state('gauntlet', {
				url: '/gauntlet',
				templateUrl: './views/canvas.html',
				controller: 'GauntletController',
				isSecure: true
			})	
			.state('battle-quest', {
				url: '/battleQuest',
				templateUrl: './views/battle-quest.html',
				controller: 'BattleQuestController',
				isSecure: true
			})
			.state('battle-chasers', {
				url: '/battleChasers',
				templateUrl: './views/battle-chasers.html',
				controller: 'BattleChasersController',
				isSecure: true
			})	
			.state('kings-quest', {
				url: '/kingsQuest',
				templateUrl: './views/canvas.html',
				controller: 'KingsQuestController',
				isSecure: true
			})	
			.state('arcade', {
				url: '/arcade',
				templateUrl: './views/arcade.html',
				controller: 'ArcadeController',
				isSecure: true
			})	
			.state('battle-chasers-splashscreen', {
				url: '/battleChasersSplashScreen/:playerName',
				templateUrl: './views/battle-chasers-splashscreen.html',
				controller: 'BattleChasersSplashScreenController',
				isSecure: true
			})
			.state('gauntlet-splashscreen', {
				url: '/gauntletSplashScreen/:playerName',
				templateUrl: './views/gauntlet-splashscreen.html',
				controller: 'GauntletSplashScreenController',
				isSecure: true
			})	
			.state('kings-quest-splashscreen', {
				url: '/kingsQuestSplashScreen/:playerName',
				templateUrl: './views/kings-quest-splashscreen.html',
				controller: 'KingsQuestSplashScreenController',
				isSecure: true
			})	
			.state('splashscreen', {
				url: '/splashscreen',
				templateUrl: './views/spashscreen.html',
				controller: 'SplashScreenController',
				isSecure: true
			})	
			.state('cardGame', {
				url: '/cardGame',
				templateUrl: './views/card-game.html',
				controller: 'BattleChasersController',
				isSecure: true
			})			
			.state('gameTable', {
				url: '/gameTable',
				templateUrl: './views/gametable.html',
				controller: 'GameTableController',
				isSecure: true
			})	
			.state('addAnGame', {
				url: '/game/add',
				templateUrl: './views/game/add-edit-game.html',
				controller: 'AddEditAnGameController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnGame', {
				url: '/game/:gameId/edit',
				templateUrl: './views/game/add-edit-game.html',
				controller: 'AddEditAnGameController',
				previousState: 'cardGame',
				isSecure: true
			})				
			.state('gameList', {
				url: '/gameList',
				templateUrl: './views/game/game-list.html',
				controller: 'GameListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('gameDetail', {
				url: '/game/:gameId/detail',
				templateUrl: './views/game/game-detail.html',
				controller: 'GameDetailController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('userList', {
				url: '/userList',
				templateUrl: './views/user/user-list.html',
				controller: 'UserListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('userDetail', {
				url: '/user/:userId/detail',
				templateUrl: './views/user/user-detail.html',
				controller: 'UserDetailController',
				previousState: 'cardGame',
				isSecure: true
			})						
			.state('addAnUser', {
				url: '/user/add',
				templateUrl: './views/user/add-edit-user.html',
				controller: 'AddEditAnUserController',
				previousState: 'cardGame',
				isSecure: false
			})
			.state('editAnUser', {
				url: '/user/:userId/edit',
				templateUrl: './views/user/add-edit-user.html',
				controller: 'AddEditAnUserController',
				previousState: 'cardGame',
				isSecure: true
			})		
			.state('playerList', {
				url: '/playerList',
				templateUrl: './views/player/player-list.html',
				controller: 'PlayerListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('playerDetail', {
				url: '/player/:playerId/detail',
				templateUrl: './views/player/player-detail.html',
				controller: 'PlayerDetailController',
				previousState: 'game',
				isSecure: true
			})			
			.state('addAnPlayer', {
				url: '/player/add',
				templateUrl: './views/player/add-edit-player.html',
				controller: 'AddEditAnPlayerController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnPlayer', {
				url: '/player/:playerId/edit',
				templateUrl: './views/player/add-edit-player.html',
				controller: 'AddEditAnPlayerController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('deckList', {
				url: '/deckList',
				templateUrl: './views/deck/deck-list.html',
				controller: 'DeckListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('deckDetail', {
				url: '/deck/:deckId/detail',
				templateUrl: './views/deck/deck-detail.html',
				controller: 'DeckDetailController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('addAnDeck', {
				url: '/deck/add',
				templateUrl: './views/deck/add-edit-deck.html',
				controller: 'AddEditAnDeckController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnDeck', {
				url: '/deck/:deckId/edit',
				templateUrl: './views/deck/add-edit-deck.html',
				controller: 'AddEditAnDeckController',
				previousState: 'cardGame',
				isSecure: true
			})	
			.state('cardList', {
				url: '/cardList',
				templateUrl: './views/card/card-list.html',
				controller: 'CardListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('cardDetail', {
				url: '/card/:cardId/detail',
				templateUrl: './views/card/card-detail.html',
				controller: 'CardDetailController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('addAnCard', {
				url: '/card/add',
				templateUrl: './views/card/add-edit-card.html',
				controller: 'AddEditAnCardController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnCard', {
				url: '/card/:cardId/edit',
				templateUrl: './views/card/add-edit-card.html',
				controller: 'AddEditAnCardController',
				previousState: 'cardGame',
				isSecure: true
			})	
			.state('attributeList', {
				url: '/attributeList',
				templateUrl: './views/attribute/attribute-list.html',
				controller: 'AttributeListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('attributeDetail', {
				url: '/attribute/:attributeId/detail',
				templateUrl: './views/attribute/attribute-detail.html',
				controller: 'AttributeDetailController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('addAnAttribute', {
				url: '/attribute/add',
				templateUrl: './views/attribute/add-edit-attribute.html',
				controller: 'AddEditAnAttributeController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnAttribute', {
				url: '/attribute/:attributeId/edit',
				templateUrl: './views/attribute/add-edit-attribute.html',
				controller: 'AddEditAnAttributeController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('imageList', {
				url: '/imageList',
				templateUrl: './views/image/image-list.html',
				controller: 'ImageListController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('imageDetail', {
				url: '/image/:imageId/detail',
				templateUrl: './views/image/image-detail.html',
				controller: 'ImageDetailController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('addAnImage', {
				url: '/image/add',
				templateUrl: './views/image/add-edit-image.html',
				controller: 'AddEditAnImageController',
				previousState: 'cardGame',
				isSecure: true
			})
			.state('editAnImage', {
				url: '/image/:imageId/edit',
				templateUrl: './views/image/add-edit-image.html',
				controller: 'AddEditAnImageController',
				previousState: 'cardGame',
				isSecure: true
			})			
			.state('login', {
				url: '/login',
				templateUrl: './views/login.html',
				controller: 'LoginController',
				isSecure: false
			});

			
			/*
		

			.state('categoryList', {
				url: '/categoryList/',
				templateUrl: './views/category-list.html',
				controller: 'CategoryListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('categoryDetail', {
				url: '/category/:categoryId/detail',
				templateUrl: './views/category-detail.html',
				controller: 'CategoryDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnCategory', {
				url: '/category/add',
				templateUrl: './views/add-edit-category.html',
				controller: 'AddEditAnCategoryController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnCategory', {
				url: '/category/:categoryId/edit',
				templateUrl: './views/add-edit-category.html',
				controller: 'AddEditAnCategoryController',
				previousState: 'game',
				isSecure: true
			})			
			

			
			.state('eventList', {
				url: '/eventList/',
				templateUrl: './views/event-list.html',
				controller: 'EventListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('eventDetail', {
				url: '/event/:eventId/detail',
				templateUrl: './views/event-detail.html',
				controller: 'EventDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnEvent', {
				url: '/event/add',
				templateUrl: './views/add-edit-event.html',
				controller: 'AddEditAnEventController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnEvent', {
				url: '/event/:eventId/edit',
				templateUrl: './views/add-edit-event.html',
				controller: 'AddEditAnEventController',
				previousState: 'game',
				isSecure: true
			})			
			
			.state('eventTypeList', {
				url: '/eventTypeList/',
				templateUrl: './views/eventType-list.html',
				controller: 'EventTypeListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('eventTypeDetail', {
				url: '/eventType/:eventTypeId/detail',
				templateUrl: './views/eventType-detail.html',
				controller: 'EventTypeDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnEventType', {
				url: '/eventType/add',
				templateUrl: './views/add-edit-eventType.html',
				controller: 'AddEditAnEventTypeController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnEventType', {
				url: '/eventType/:eventTypeId/edit',
				templateUrl: './views/add-edit-eventType.html',
				controller: 'AddEditAnEventTypeController',
				previousState: 'game',
				isSecure: true
			})			
			
			.state('handList', {
				url: '/handList/',
				templateUrl: './views/hand-list.html',
				controller: 'HandListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('handDetail', {
				url: '/hand/:handId/detail',
				templateUrl: './views/hand-detail.html',
				controller: 'HandDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnHand', {
				url: '/hand/add',
				templateUrl: './views/add-edit-hand.html',
				controller: 'AddEditAnHandController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnHand', {
				url: '/hand/:handId/edit',
				templateUrl: './views/add-edit-hand.html',
				controller: 'AddEditAnHandController',
				previousState: 'game',
				isSecure: true
			})			
	
			
			.state('operationList', {
				url: '/operationList/',
				templateUrl: './views/operation-list.html',
				controller: 'OperationListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('operationDetail', {
				url: '/operation/:operationId/detail',
				templateUrl: './views/operation-detail.html',
				controller: 'OperationDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnOperation', {
				url: '/operation/add',
				templateUrl: './views/add-edit-operation.html',
				controller: 'AddEditAnOperationController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnOperation', {
				url: '/operation/:operationId/edit',
				templateUrl: './views/add-edit-operation.html',
				controller: 'AddEditAnOperationController',
				previousState: 'game',
				isSecure: true
			})			

			
			.state('repeatTypeList', {
				url: '/repeatTypeList/',
				templateUrl: './views/repeatType-list.html',
				controller: 'RepeatTypeListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('repeatTypeDetail', {
				url: '/repeatType/:repeatTypeId/detail',
				templateUrl: './views/repeatType-detail.html',
				controller: 'RepeatTypeDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnRepeatType', {
				url: '/repeatType/add',
				templateUrl: './views/add-edit-repeatType.html',
				controller: 'AddEditAnRepeatTypeController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnRepeatType', {
				url: '/repeatType/:repeatTypeId/edit',
				templateUrl: './views/add-edit-repeatType.html',
				controller: 'AddEditAnRepeatTypeController',
				previousState: 'game',
				isSecure: true
			})			
			

			.state('settingList', {
				url: '/settingList/',
				templateUrl: './views/setting-list.html',
				controller: 'SettingListController',
				previousState: 'eventList',
				isSecure: true
			})			
			.state('settingDetail', {
				url: '/setting/:settingId/detail',
				templateUrl: './views/setting-detail.html',
				controller: 'SettingDetailController',
				previousState: 'game',
				isSecure: true
			})
			.state('addAnSetting', {
				url: '/setting/add',
				templateUrl: './views/add-edit-setting.html',
				controller: 'AddEditAnSettingController',
				previousState: 'game',
				isSecure: true
			})
			.state('editAnSetting', {
				url: '/setting/:settingId/edit',
				templateUrl: './views/add-edit-setting.html',
				controller: 'AddEditAnSettingController',
				previousState: 'game',
				isSecure: true
			})			

			*/
			
			
		}
	]);

	angular.module('BattleChasersWebApp').directive('ngEnter', function () {
		return function (scope, element, attrs) {
			element.bind("keydown keypress", function (event) {
				if(event.which === 13) {
					scope.$apply(function (){
						scope.$eval(attrs.ngEnter);
					});

					event.preventDefault();
				}
			});
		};
	});

	angular.module('BattleChasersWebApp').filter("asDate", function () {
		return function (input) {
			return new Date(input);
		};
	});


	angular.module('BattleChasersWebApp').filter("asFormattedDate", function () {
		return function (input) {
			return kendo.toString(kendo.parseDate(input, 'MMM dd, yyyy hh:mm:ss tt'), 'MM/dd/yyyy');
		};
	});

}());