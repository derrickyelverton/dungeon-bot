/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('DeckDetailController', ['$scope', '$rootScope', '$stateParams', 'DeckService',
    function ($scope, $rootScope, $stateParams, DeckService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Deck details';

        // setup get deck service calling
        $scope.getDeck = function () {
            // call the server to get parameter with that id
            DeckService.getDeck({id: $stateParams.deckId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.deck = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getDeck();
    }
]);
