/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('AddEditAnPlayerController', ['$scope', '$rootScope', '$stateParams', 'PlayerService',
    function ($scope, $rootScope, $stateParams, PlayerService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an player';
        $scope.isEdit = false;
        
        // setup get user service calling
        $scope.getPlayer = function () {
            if ($stateParams.playerId) {
                // call the server to get parameter with that id
                PlayerService.getPlayer({id: $stateParams.playerId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.user = response;
                            if ($scope.player != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an player';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.player = {};
            }
        };

        $scope.addEditAnPlayer = function () {
            var newPlayer = $scope.player;
            newPlayer.name = $('#nameSelection').val();
            newPlayer.description = $('#descriptionSelection').val();
            newPlayer.title = $('#titleSelection').val();
            newPlayer.createdOn = new Date();
            newPlayer.user = $rootScope.loggedInUser;
            if ($scope.validateDialog(newPlayer)) {
                if (!$scope.isEdit) {
                	newPlayer.id = null;
                    // call the user service create an user (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return PlayerService.createPlayer(newPlayer).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go('login');
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new player."}); 
                        	alert("Server Error: Failed to add the new player."); 
                        }
                    );
                }
                else {
                    return PlayerService.updatePlayer({id: newPlayer.id}, newPlayer).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the user."}); 
                        	alert("Server Error: Failed to edit the player."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newUser) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getPlayer();
    }
]);