/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('PlayerDetailController', ['$scope', '$rootScope', '$stateParams', 'PlayerService',
    function ($scope, $rootScope, $stateParams, PlayerService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Player details';

        // setup get player service calling
        $scope.getPlayer = function () {
            // call the server to get parameter with that id
            PlayerService.getPlayer({id: $stateParams.playerId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.player = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getPlayer();
    }
]);
