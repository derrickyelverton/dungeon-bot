/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('GameDetailController', ['$scope', '$rootScope', '$stateParams', 'GameService',
    function ($scope, $rootScope, $stateParams, GameService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Game details';

        // setup get game service calling
        $scope.getGame = function () {
            // call the server to get parameter with that id
            GameService.getGame({id: $stateParams.gameId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.game = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getGame();
    }
]);
