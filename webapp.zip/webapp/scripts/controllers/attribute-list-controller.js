/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('AttributeListController', ['$scope', '$rootScope', '$stateParams', 'AttributeService', 
    function ($scope, $rootScope, $stateParams, AttributeService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Attributes';
        
        // setup get attribute service calling
        $scope.getAttributes = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.attributeId) {
                // call the server to get parameter with that id
                AttributeService.getAttributes(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.attributes = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.attribute = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getAttributes();
    }
]);

