/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('UserDetailController', ['$scope', '$rootScope', '$stateParams', 'UserService',
    function ($scope, $rootScope, $stateParams, UserService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'User details';

        // setup get user service calling
        $scope.getUser = function () {
            // call the server to get parameter with that id
            UserService.getUser({id: $stateParams.userId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.user = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getUser();
    }
]);
