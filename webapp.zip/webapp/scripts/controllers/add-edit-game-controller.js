/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('AddEditAnGameController', ['$scope', '$rootScope', '$stateParams', 'GameService',
    function ($scope, $rootScope, $stateParams, GameService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an game';
        $scope.isEdit = false;
        
        // setup get game service calling
        $scope.getGame = function () {
            if ($stateParams.gameId) {
                // call the server to get parameter with that id
                GameService.getGame({id: $stateParams.gameId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.game = response;
                            if ($scope.game != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an game';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.game = {};
            }
        };

        $scope.addEditAnGame = function () {
            var newGame = $scope.game;
            newGame.name = $('#nameInput').val();
            newGame.value = $('#valueInput').val();
            newGame.playerOne = $rootScope.loggedInUser;
            newGame.updatedBy = $rootScope.loggedInUser.username;
            newGame.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newGame)) {
                if (!$scope.isEdit) {
                    newGame.createdBy = newGame.updatedBy;
                    newGame.createdOn = newGame.updatedOn;
                	newGame.id = null;
                    // call the game service create an game (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return GameService.createGame(newGame).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new game."}); 
                        	alert("Server Error: Failed to add the new game."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return GameService.updateGame({id: newGame.id}, newGame).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the game."}); 
                        	alert("Server Error: Failed to edit the game."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newGame) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getGame();
    }
]);