/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('ImageDetailController', ['$scope', '$rootScope', '$stateParams', 'ImageService',
    function ($scope, $rootScope, $stateParams, ImageService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Image details';

        // setup get image service calling
        $scope.getImage = function () {
            // call the server to get parameter with that id
            ImageService.getImage({id: $stateParams.imageId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.image = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getImage();
    }
]);
