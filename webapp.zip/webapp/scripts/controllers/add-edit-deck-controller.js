/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('AddEditAnDeckController', ['$scope', '$rootScope', '$stateParams', 'DeckService',
    function ($scope, $rootScope, $stateParams, DeckService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an deck';
        $scope.isEdit = false;
        
        // setup get user service calling
        $scope.getDeck = function () {
            if ($stateParams.deckId) {
                // call the server to get parameter with that id
                DeckService.getDeck({id: $stateParams.deckId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.user = response;
                            if ($scope.deck != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an deck';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.deck = {};
            }
        };

        $scope.addEditAnDeck = function () {
            var newDeck = $scope.deck;
            newDeck.name = $('#nameSelection').val();
            newDeck.cards = [];
            newDeck.player = null;
            if ($scope.validateDialog(newDeck)) {
                if (!$scope.isEdit) {
                	newDeck.id = null;
                    // call the user service create an user (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return DeckService.createDeck(newDeck).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go('login');
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new deck."}); 
                        	alert("Server Error: Failed to add the new deck."); 
                        }
                    );
                }
                else {
                    return DeckService.updateDeck({id: newDeck.id}, newDeck).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the user."}); 
                        	alert("Server Error: Failed to edit the deck."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newUser) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getDeck();
    }
]);