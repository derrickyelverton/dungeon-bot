/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('UserListController', ['$scope', '$rootScope', '$stateParams', 'UserService', 
    function ($scope, $rootScope, $stateParams, UserService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Users';
        
        // setup get user service calling
        $scope.getUsers = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.userId) {
                // call the server to get parameter with that id
                UserService.getUsers(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.users = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.user = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getUsers();
    }
]);

