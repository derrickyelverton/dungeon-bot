/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('GeoController', ['$scope', '$rootScope', '$stateParams',  
    function ($scope, $rootScope, $stateParams) {

        'use strict';

        $scope.title = "Geo game";
    	
        //$scope.markerPosition = {lat: -25.363, lng: 131.044};
        $scope.markerPosition = {lat: -33.9, lng: 151.2};
        //$scope.markerPosition = {lat: 32, lng: 88}
        
        $scope.marker = null;;

        $scope.gameElements = [];
        $scope.gameElementMarkers = [];
        $scope.gameCharacterElement = null;
        $scope.gameCharacterMarker = null;
        $scope.map = null;
        $scope.mapZoom = 18;

        $scope.createTestCircle = function() {
        	var citymap = {
			  chicago: {
			    center: {lat: 41.878, lng: -87.629},
			    population: 2714856
			  },
			  newyork: {
			    center: {lat: 40.714, lng: -74.005},
			    population: 8405837
			  },
			  losangeles: {
			    center: {lat: 34.052, lng: -118.243},
			    population: 3857799
			  },
			  vancouver: {
			    center: {lat: 49.25, lng: -123.1},
			    population: 603502
			  }
			};

    	  // Construct the circle for each value in citymap.
    	  // Note: We scale the area of the circle based on the population.
    	  for (var city in citymap) {
    	    // Add the circle for this city to the map.
    	    var cityCircle = new google.maps.Circle({
    	      strokeColor: '#FF0000',
    	      strokeOpacity: 0.8,
    	      strokeWeight: 2,
    	      fillColor: '#FF0000',
    	      fillOpacity: 0.35,
    	      map: $scope.map,
    	      center: citymap[city].center,
    	      radius: Math.sqrt(citymap[city].population) * 100
    	    });
    	  }

        };
        
        $scope.createTestPolygon = function() {
        	  // Define the LatLng coordinates for the polygon's path.
        	  var triangleCoords = [
        	    {lat: 25.774, lng: -80.190},
        	    {lat: 18.466, lng: -66.118},
        	    {lat: 32.321, lng: -64.757},
        	    {lat: 25.774, lng: -80.190}
        	  ];

        	  // Construct the polygon.
        	  var bermudaTriangle = new google.maps.Polygon({
        	    paths: triangleCoords,
        	    strokeColor: '#FF0000',
        	    strokeOpacity: 0.8,
        	    strokeWeight: 2,
        	    fillColor: '#FF0000',
        	    fillOpacity: 0.35
        	  });
        	  bermudaTriangle.setMap($scope.map);
        };
        
        $scope.createTestRectangle = function() {
        	  var rectangle = new google.maps.Rectangle({
        		    strokeColor: '#FF0000',
        		    strokeOpacity: 0.8,
        		    strokeWeight: 2,
        		    fillColor: '#FF0000',
        		    fillOpacity: 0.35,
        		    map: $scope.map,
        		    bounds: {
        		      north: 33.685,
        		      south: 33.671,
        		      east: -116.234,
        		      west: -116.251
        		    }
        		  });
        }; 	    
	    
        // create a marker on the map
        $scope.createTestMarker = function() {
            // Marker sizes are expressed as a Size of X,Y where the origin of the image
            // (0,0) is located in the top left of the image.

            // Origins, anchor positions and coordinates of the marker increase in the X
            // direction to the right and in the Y direction down.        
            $scope.image = {
              //url: '/assets/images/beachflag.png',	          		
        	    url: 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png',
        	    // This marker is 20 pixels wide by 32 pixels high.
        	    size: new google.maps.Size(20, 32),
        	    // The origin for this image is (0, 0).
        	    origin: new google.maps.Point(0, 0),
        	    // The anchor for this image is the base of the flagpole at (0, 32).
        	    anchor: new google.maps.Point(0, 32)
        	};
            
       	    // Shapes define the clickable region of the icon. The type defines an HTML
    	    // <area> element 'poly' which traces out a polygon as a series of X,Y points.
    	    // The final coordinate closes the poly by connecting to the first coordinate.
    	    var shape = {
    	        coords: [1, 1, 1, 20, 18, 20, 18, 1],
    	        type: 'poly'
    	    };        	
        	
	        var marker = new google.maps.Marker({
	          position: $scope.markerPosition,
           	  label: 'Marker label',
           	  title: 'Marker Title',
              draggable: true,
              animation: google.maps.Animation.DROP, 
              icon: $scope.image,
              shape: $scope.shape,
	          map: $scope.map
	        }); 
		    marker.addListener('click', $scope.toggleBounce);
			return marker;
        }; 

        $scope.toggleBounce = function() {
    	    if ($scope.marker.getAnimation() !== null) {
    	    	$scope.marker.setAnimation(null);
    	    } 
    	    else {
    	    	$scope.marker.setAnimation(google.maps.Animation.BOUNCE);
    	    }
    	};   
        
        $scope.removeMarker = function(marker) {
        	marker.setMap(null);
        };        
        
        $scope.remoaveAllMarkers = function() {
            for (var i = 0; i < $scope.gameElementMarkers.length; i++) {
            	$scope.gameElementMarkers[i].setMap(null);
            }
            $scope.gameElementMarkers = [];
        };
        
        $scope.createCircle = function() {
        	var centerOfCircle = {lat: 41.878, lng: -87.629};
        	var population = 2714856;

    	    var circle = new google.maps.Circle({
    	      strokeColor: '#FF0000',
    	      strokeOpacity: 0.8,
    	      strokeWeight: 2,
    	      fillColor: '#FF0000',
    	      fillOpacity: 0.35,
    	      map: $scope.map,
    	      center: centerOfCircle,
    	      radius: Math.sqrt(population) * 100
    	    });
        	  
            return circle;
        };
        
        $scope.createPolygon = function(element) {
        	/*
        	// Define the LatLng coordinates for the polygon's path.
        	var triangleCoords = [
        	    {lat: 25.774, lng: -80.190},
        	    {lat: 18.466, lng: -66.118},
        	    {lat: 32.321, lng: -64.757},
        	    {lat: 25.774, lng: -80.190}
        	  ];
      	    paths: triangleCoords,
    	    strokeColor: '#FF0000',
    	    strokeOpacity: 0.8,
    	    strokeWeight: 2,
    	    fillColor: '#FF0000',
    	    fillOpacity: 0.35
    	    */

        	  // Construct the polygon.
        	  var triangle = new google.maps.Polygon({
        	    paths: element.coords,
        	    strokeColor: element.strokeColor,
        	    strokeOpacity: element.strokeOpacity,
        	    strokeWeight: element.strokeWeight,
        	    fillColor: element.fillColor,
        	    fillOpacity: element.opacity,
        	    map: $scope.map
        	  });
        	  //triangle.setMap($scope.map);
        	  return triangle;
        };
        
        $scope.createRectangle = function(element) {
		    /* sample
        	strokeColor: '#FF0000',
		    strokeOpacity: 0.8,
		    strokeWeight: 2,
		    fillColor: '#FF0000',
		    fillOpacity: 0.35,
		    map: $scope.map,
		    bounds: {
		      north: 33.685,
		      south: 33.671,
		      east: -116.234,
		      west: -116.251
		    } 
		    */       	
    	    var rectangle = new google.maps.Rectangle({
    		    strokeColor: element.strokeColor,
    		    strokeOpacity: elementOpacity,
    		    strokeWeight: element.Weight,
    		    fillColor: element.fillColor,
    		    fillOpacity: element.fillOpacity,
    		    map: $scope.map,
    		    bounds: element.bounds
    		});
    	    
    	    // or
        	
    	    var rectangle = new google.maps.Rectangle({
    		    strokeColor: element.strokeColor,
    		    strokeOpacity: elementOpacity,
    		    strokeWeight: element.Weight,
    		    fillColor: element.fillColor,
    		    fillOpacity: element.fillOpacity,
    		    map: $scope.map,
    		    bounds: {
    		      north: element.north,
    		      south: element.south,
    		      east: element.east,
    		      west: element.west
    		    }
    		});
    	    return rectangle;
        };        
        
        // create a marker on the map
        $scope.createMarker = function(element) {
            var marker = new google.maps.Marker({
	            position: element.position,
           	    label: element.label,
           	    title: element.title,
                draggable: element.draggable,
                animation: google.maps.Animation.DROP, 
                icon: element.fullImageUrl,
                shape: element.shape,
	            map: $scope.map
	        }); 
			if (element.isUserCharacter) {
				marker.addListener('click', $scope.moveListener);
			}	
			return marker;      
        }; 
        
        $scope.moveListener = function (e) {
        	
            e = e || window.event;

            if (e.keyCode == '38' || e.keyCode == '40' || e.keyCode == '37' || e.keyCode == '39') {
            	$scope.gameCharacterMarkers.forEach(function(element) {
            		if (element.isUserCharacter) {
                        if (e.keyCode == '38') {
                            // up arrow
                        	$scope.moveUp(element);
                        }
                        else if (e.keyCode == '40') {
                            // down arrow
                        	$scope.moveDown(element);
                        }
                        else if (e.keyCode == '37') {
                           // left arrow
                        	$scope.moveLeft(element);
                        }
                        else if (e.keyCode == '39') {
                           // right arrow
                        	$scope.moveRight(element);
                        }       			
            		}
            	});            
            }
        }
                      
        $scope.getGameElements = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            GameService.getElements(params).$promise.then(
                function (response) {
                    if (response) {
                        $scope.gameElements = response.content;
                        $scope.drawScene();
                    }
                },
                function (status) {
                }
            );
        };
        
        $scope.drawScene = function() {
        	$scope.gameElements.forEach(function(element) {
        		$scope.gameElementMarkers.push($scope.createMarker(element));
        	});        	
        };        
        
        $scope.getGameCharacter = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            GameService.getCharacters(params).$promise.then(
                function (response) {
                    if (response) {
                        $scope.gameCharacterElement = response;
                        $scope.drawCharacter();
                    }
                },
                function (status) {
                }
            );
        };
        
        $scope.drawCharacter = function() {
        	$scope.createMarker($scope.gameCharacterElement);
        };        
        
        $scope.initializeScene = function() {
            $scope.map = new google.maps.Map(document.getElementById("mapContainer"), {
               center: $scope.markerPosition,
               zoom: $scope.mapZoom
            });
            $scope.marker = $scope.createTestMarker();
            $scope.createTestRectangle();
            $scope.createTestCircle();
            $scope.createTestPolygon();
        };  
        
        google.maps.event.addDomListener(window, 'load', $scope.initializeScene);

    }
]);

