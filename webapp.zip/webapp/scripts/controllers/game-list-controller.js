/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('GameListController', ['$scope', '$rootScope', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $stateParams, GameService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Games';
        
        // setup get game service calling
        $scope.getGames = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.gameId) {
                // call the server to get parameter with that id
                GameService.getGames(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.games = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.game = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getGames();
    }
]);

