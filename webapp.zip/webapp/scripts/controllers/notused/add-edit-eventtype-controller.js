/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnEventController', ['$scope', '$rootScope', '$stateParams', 'EventService',
    function ($scope, $rootScope, $stateParams, EventService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an eventtype';
        $scope.isEdit = false;
        
        // setup get eventtype service calling
        $scope.getEvent = function () {
            if ($stateParams.eventtypeId) {
                // call the server to get parameter with that id
                EventService.getEvent({id: $stateParams.eventtypeId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.eventtype = response;
                            if ($scope.eventtype != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an eventtype';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.eventtype = {};
            }
        };

        $scope.addEditAnEvent = function () {
            var newEvent = $scope.eventtype;
            newEvent.name = $('#nameInput').val();
            newEvent.value = $('#valueInput').val();
            newEvent.updatedBy = $rootScope.loggedInUser.username;
            newEvent.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newEvent)) {
                if (!$scope.isEdit) {
                    newEvent.createdBy = newEvent.updatedBy;
                    newEvent.createdOn = newEvent.updatedOn;
                	newEvent.id = null;
                    // call the eventtype service create an eventtype (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return EventService.createEvent(newEvent).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new eventtype."}); 
                        	alert("Server Error: Failed to add the new eventtype."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return EventService.updateEvent({id: newEvent.id}, newEvent).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the eventtype."}); 
                        	alert("Server Error: Failed to edit the eventtype."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newEvent) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getEvent();
    }
]);

