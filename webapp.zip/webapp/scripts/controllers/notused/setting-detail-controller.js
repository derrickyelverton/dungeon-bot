/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('SettingDetailController', ['$scope', '$rootScope', '$stateParams', 'SettingService',
    function ($scope, $rootScope, $stateParams, SettingService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Setting details';

        // setup get setting service calling
        $scope.getSetting = function () {
            // call the server to get parameter with that id
            SettingService.getSetting({id: $stateParams.settingId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.setting = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getSetting();
    }
]);
