/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnSettingController', ['$scope', '$rootScope', '$stateParams', 'SettingService',
    function ($scope, $rootScope, $stateParams, SettingService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an setting';
        $scope.isEdit = false;
        
        // setup get setting service calling
        $scope.getSetting = function () {
            if ($stateParams.settingId) {
                // call the server to get parameter with that id
                SettingService.getSetting({id: $stateParams.settingId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.setting = response;
                            if ($scope.setting != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an setting';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.setting = {};
            }
        };

        $scope.addEditAnSetting = function () {
            var newSetting = $scope.setting;
            newSetting.name = $('#nameInput').val();
            newSetting.value = $('#valueInput').val();
            newSetting.updatedBy = $rootScope.loggedInUser.username;
            newSetting.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newSetting)) {
                if (!$scope.isEdit) {
                    newSetting.createdBy = newSetting.updatedBy;
                    newSetting.createdOn = newSetting.updatedOn;
                	newSetting.id = null;
                    // call the setting service create an setting (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return SettingService.createSetting(newSetting).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new setting."}); 
                        	alert("Server Error: Failed to add the new setting."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return SettingService.updateSetting({id: newSetting.id}, newSetting).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the setting."}); 
                        	alert("Server Error: Failed to edit the setting."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newSetting) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getSetting();
    }
]);