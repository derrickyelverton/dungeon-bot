/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('EventDetailController', ['$scope', '$rootScope', '$stateParams', 'EventService',
    function ($scope, $rootScope, $stateParams, EventService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Event details';

        // setup get event service calling
        $scope.getEvent = function () {
            // call the server to get parameter with that id
            EventService.getEvent({id: $stateParams.eventId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.event = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getEvent();
    }
]);
