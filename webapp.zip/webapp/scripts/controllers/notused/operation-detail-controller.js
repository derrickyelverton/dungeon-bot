/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('OperationDetailController', ['$scope', '$rootScope', '$stateParams', 'OperationService',
    function ($scope, $rootScope, $stateParams, OperationService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Operation details';

        // setup get operation service calling
        $scope.getOperation = function () {
            // call the server to get parameter with that id
            OperationService.getOperation({id: $stateParams.operationId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.operation = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getOperation();
    }
]);
