/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('EventTypeListController', ['$scope', '$rootScope', '$stateParams', 'EventTypeService', 
    function ($scope, $rootScope, $stateParams, EventTypeService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'EventTypes';
        
        // setup get eventType service calling
        $scope.getEventTypes = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.eventTypeId) {
                // call the server to get parameter with that id
                EventTypeService.getEventTypes(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.eventTypes = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.eventType = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getEventTypes();
    }
]);

