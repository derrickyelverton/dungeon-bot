/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('HandListController', ['$scope', '$rootScope', '$stateParams', 'HandService', 
    function ($scope, $rootScope, $stateParams, HandService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Hands';
        
        // setup get hand service calling
        $scope.getHands = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.handId) {
                // call the server to get parameter with that id
                HandService.getHands(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.hands = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.hand = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getHands();
    }
]);

