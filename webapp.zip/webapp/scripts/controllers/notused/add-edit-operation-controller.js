/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnOperationController', ['$scope', '$rootScope', '$stateParams', 'OperationService',
    function ($scope, $rootScope, $stateParams, OperationService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an operation';
        $scope.isEdit = false;
        
        // setup get operation service calling
        $scope.getOperation = function () {
            if ($stateParams.operationId) {
                // call the server to get parameter with that id
                OperationService.getOperation({id: $stateParams.operationId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.operation = response;
                            if ($scope.operation != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an operation';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.operation = {};
            }
        };

        $scope.addEditAnOperation = function () {
            var newOperation = $scope.operation;
            newOperation.name = $('#nameInput').val();
            newOperation.value = $('#valueInput').val();
            newOperation.updatedBy = $rootScope.loggedInUser.username;
            newOperation.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newOperation)) {
                if (!$scope.isEdit) {
                    newOperation.createdBy = newOperation.updatedBy;
                    newOperation.createdOn = newOperation.updatedOn;
                	newOperation.id = null;
                    // call the operation service create an operation (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return OperationService.createOperation(newOperation).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new operation."}); 
                        	alert("Server Error: Failed to add the new operation."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return OperationService.updateOperation({id: newOperation.id}, newOperation).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the operation."}); 
                        	alert("Server Error: Failed to edit the operation."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newOperation) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getOperation();
    }
]);

