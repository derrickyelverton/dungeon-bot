/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('EventTypeDetailController', ['$scope', '$rootScope', '$stateParams', 'EventTypeService',
    function ($scope, $rootScope, $stateParams, EventTypeService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'EventType details';

        // setup get eventType service calling
        $scope.getEventType = function () {
            // call the server to get parameter with that id
            EventTypeService.getEventType({id: $stateParams.eventTypeId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.eventType = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getEventType();
    }
]);
