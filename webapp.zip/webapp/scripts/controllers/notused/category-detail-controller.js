/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('CategoryDetailController', ['$scope', '$rootScope', '$stateParams', 'CategoryService',
    function ($scope, $rootScope, $stateParams, CategoryService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Category details';

        // setup get category service calling
        $scope.getCategory = function () {
            // call the server to get parameter with that id
            CategoryService.getCategory({id: $stateParams.categoryId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.category = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getCategory();
    }
]);
