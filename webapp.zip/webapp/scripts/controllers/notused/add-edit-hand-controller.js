/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnHandController', ['$scope', '$rootScope', '$stateParams', 'HandService',
    function ($scope, $rootScope, $stateParams, HandService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an hand';
        $scope.isEdit = false;
        
        // setup get hand service calling
        $scope.getHand = function () {
            if ($stateParams.handId) {
                // call the server to get parameter with that id
                HandService.getHand({id: $stateParams.handId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.hand = response;
                            if ($scope.hand != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an hand';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.hand = {};
            }
        };

        $scope.addEditAnHand = function () {
            var newHand = $scope.hand;
            newHand.name = $('#nameInput').val();
            newHand.value = $('#valueInput').val();
            newHand.updatedBy = $rootScope.loggedInUser.username;
            newHand.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newHand)) {
                if (!$scope.isEdit) {
                    newHand.createdBy = newHand.updatedBy;
                    newHand.createdOn = newHand.updatedOn;
                	newHand.id = null;
                    // call the hand service create an hand (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return HandService.createHand(newHand).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new hand."}); 
                        	alert("Server Error: Failed to add the new hand."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return HandService.updateHand({id: newHand.id}, newHand).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the hand."}); 
                        	alert("Server Error: Failed to edit the hand."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newHand) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getHand();
    }
]);