/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('CardGameWebApp').controller('HandDetailController', ['$scope', '$rootScope', '$stateParams', 'HandService',
    function ($scope, $rootScope, $stateParams, HandService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Hand details';

        // setup get hand service calling
        $scope.getHand = function () {
            // call the server to get parameter with that id
            HandService.getHand({id: $stateParams.handId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.hand = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getHand();
    }
]);
