/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('CategoryListController', ['$scope', '$rootScope', '$stateParams', 'CategoryService', 
    function ($scope, $rootScope, $stateParams, CategoryService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Categories';
        
        // setup get category service calling
        $scope.getCategories = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.categoryId) {
                // call the server to get parameter with that id
                CategoryService.getCategories(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.categorys = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.category = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getCategories();
    }
]);

