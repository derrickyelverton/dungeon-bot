/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnCategoryController', ['$scope', '$rootScope', '$stateParams', 'CategoryService',
    function ($scope, $rootScope, $stateParams, CategoryService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an category';
        $scope.isEdit = false;
        
        // setup get category service calling
        $scope.getCategory = function () {
            if ($stateParams.categoryId) {
                // call the server to get parameter with that id
                CategoryService.getCategory({id: $stateParams.categoryId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.category = response;
                            if ($scope.category != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an category';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.category = {};
            }
        };

        $scope.addEditAnCategory = function () {
            var newCategory = $scope.category;
            newCategory.name = $('#nameInput').val();
            newCategory.value = $('#valueInput').val();
            newCategory.updatedBy = $rootScope.loggedInUser.username;
            newCategory.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newCategory)) {
                if (!$scope.isEdit) {
                    newCategory.createdBy = newCategory.updatedBy;
                    newCategory.createdOn = newCategory.updatedOn;
                	newCategory.id = null;
                    // call the category service create an category (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return CategoryService.createCategory(newCategory).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new category."}); 
                        	alert("Server Error: Failed to add the new category."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return CategoryService.updateCategory({id: newCategory.id}, newCategory).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the category."}); 
                        	alert("Server Error: Failed to edit the category."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newCategory) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getCategory();
    }
]);