/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('CardGameWebApp').controller('AddEditAnEventController', ['$scope', '$rootScope', '$stateParams', 'EventService',
    function ($scope, $rootScope, $stateParams, EventService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an event';
        $scope.isEdit = false;
        
        // setup get event service calling
        $scope.getEvent = function () {
            if ($stateParams.eventId) {
                // call the server to get parameter with that id
                EventService.getEvent({id: $stateParams.eventId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.event = response;
                            if ($scope.event != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an event';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.event = {};
            }
        };

        $scope.addEditAnEvent = function () {
            var newEvent = $scope.event;
            newEvent.name = $('#nameInput').val();
            newEvent.value = $('#valueInput').val();
            newEvent.updatedBy = $rootScope.loggedInUser.username;
            newEvent.updatedOn = kendo.toString(new Date(), "MMM dd, yyyy hh:mm:ss tt");
            if ($scope.validateDialog(newEvent)) {
                if (!$scope.isEdit) {
                    newEvent.createdBy = newEvent.updatedBy;
                    newEvent.createdOn = newEvent.updatedOn;
                	newEvent.id = null;
                    // call the event service create an event (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return EventService.createEvent(newEvent).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new event."}); 
                        	alert("Server Error: Failed to add the new event."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
                else {
                    return EventService.updateEvent({id: newEvent.id}, newEvent).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the event."}); 
                        	alert("Server Error: Failed to edit the event."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newEvent) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.previousState);
        };

        $scope.getEvent();
    }
]);