/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('CardDetailController', ['$scope', '$rootScope', '$stateParams', 'CardService',
    function ($scope, $rootScope, $stateParams, CardService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Card details';

        // setup get card service calling
        $scope.getCard = function () {
            // call the server to get parameter with that id
            CardService.getCard({id: $stateParams.cardId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.card = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getCard();
    }
]);
