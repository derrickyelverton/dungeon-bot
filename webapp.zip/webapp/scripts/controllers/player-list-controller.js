/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('PlayerListController', ['$scope', '$rootScope', '$stateParams', 'PlayerService', 
    function ($scope, $rootScope, $stateParams, PlayerService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Players';
        
        // setup get player service calling
        $scope.getPlayers = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.playerId) {
                // call the server to get parameter with that id
                PlayerService.getPlayers(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.players = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.player = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getPlayers();
    }
]);

