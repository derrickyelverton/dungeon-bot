/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('ImageListController', ['$scope', '$rootScope', '$stateParams', 'ImageService', 
    function ($scope, $rootScope, $stateParams, ImageService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Images';
        
        // setup get image service calling
        $scope.getImages = function () {
            var params = {
                filter: null,
//                  '{"logic":"OR", "filters":[' +
//                  '{"field":"startDate","operator":"greaterthan","value":"' +  kendo.toString(firstDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"}, ' +
//                  '{"field":"startDate","operator":"lessthan","value":"' + kendo.toString(lastDateOfMonth, "MMM dd, yyyy hh:mm:ss tt") + '"} ' +
//                  ']}',
                sort: '{"field":"id","dir":"asc"}',
                offset: 0,
                count: 1000
            };        	
            if ($stateParams.imageId) {
                // call the server to get parameter with that id
                ImageService.getImages(params).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.images = response.content;
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.image = {};
            }
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getImages();
    }
]);

