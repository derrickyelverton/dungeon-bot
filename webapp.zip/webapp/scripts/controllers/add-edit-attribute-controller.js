/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('AddEditAnAttributeController', ['$scope', '$rootScope', '$stateParams', 'AttributeService',
    function ($scope, $rootScope, $stateParams, AttributeService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Add an attribute';
        $scope.isEdit = false;
        
        // setup get user service calling
        $scope.getAttribute = function () {
            if ($stateParams.attributeId) {
                // call the server to get parameter with that id
                AttributeService.getAttribute({id: $stateParams.attributeId}).$promise.then(
                    function (response) {
                        if (response) {
                            $scope.user = response;
                            if ($scope.attribute != null) {
                                $scope.isEdit = true;
                                $scope.title = 'Edit an attribute';
                            }
                        }
                    },
                    function (status) {
                    }
                );
            }
            else {
                $scope.attribute = {};
            }
        };

        $scope.addEditAnAttribute = function () {
            var newAttribute = $scope.attribute;
            newAttribute.name = $('#nameSelection').val();
            newAttribute.attributes = [];
            newAttribute.player = null;
            if ($scope.validateDialog(newAttribute)) {
                if (!$scope.isEdit) {
                	newAttribute.id = null;
                    // call the user service create an user (uses the resource query POST call) passing the not parameter id in the URI passing the parameter json object in the request body
                    return AttributeService.createAttribute(newAttribute).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go('login');
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to add the new attribute."}); 
                        	alert("Server Error: Failed to add the new attribute."); 
                        }
                    );
                }
                else {
                    return AttributeService.updateAttribute({id: newAttribute.id}, newAttribute).$promise.then(
                        // success call back
                        function (response) {
                            if (response) {
                                $rootScope.$state.go($rootScope.previousState);
                            }
                        },
                        // error call back
                        function (status) {
							//dialogService.error({message: "Server Error: Failed to edit the user."}); 
                        	alert("Server Error: Failed to edit the attribute."); 
                            $rootScope.$state.go($rootScope.previousState);
                        }
                    );
                }
            }
            else {
				//dialogService.warn({message: "Please validate you have populated all required fields."}); 
            	alert("Please validate you have populated all required fields.");
            }
        };

        $scope.validateDialog = function(newUser) {
            var valid = true;
            return valid;
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getAttribute();
    }
]);