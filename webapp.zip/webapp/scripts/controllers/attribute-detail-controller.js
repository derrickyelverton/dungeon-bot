/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('AttributeDetailController', ['$scope', '$rootScope', '$stateParams', 'AttributeService',
    function ($scope, $rootScope, $stateParams, AttributeService) {

        'use strict';

        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Attribute details';

        // setup get attribute service calling
        $scope.getAttribute = function () {
            // call the server to get parameter with that id
            AttributeService.getAttribute({id: $stateParams.attributeId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.attribute = response;
                    }
                },
                function (status) {
                }
            );
        };

        $scope.cancel = function() {
            $rootScope.$state.go($rootScope.$state.$current.previousState);
        };

        $scope.getAttribute();
    }
]);
