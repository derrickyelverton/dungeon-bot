
angular.module('BattleChasersWebApp').controller('ApplicationController', ['$scope', '$rootScope', '$state', '$stateParams', 
    function ($scope, $rootScope, $state, $stateParams) {

            'use strict';

     	    $scope.gameName = "The Arcade";
            
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;

            $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

                    $rootScope.backButton = null;
                    if(toState.name != "/" && toState.name != "home" ) {
                            $rootScope.backButton = "true";
                            $rootScope.previousStateParams = fromParams;
                    }
            });

            $rootScope.$on('event:auth-loginConfirmed', function (rejection) {
              	$state.go('arcade');
            });
            
            $rootScope.$on('event:auth-loginRequired', function (rejection) {
                $state.go('login');
            });
            
            $rootScope.$on('event:userLoggedOut', function() {
            	delete $rootScope.feedbackMessage;
                $state.go('login');
            });            

            $scope.showBackButton = false;
            $rootScope.setShowBackButton = function(show) {
                    $scope.showBackButton = show;
            };

            $rootScope.goBack = function () {
                    $rootScope.$stateParams =  $rootScope.previousStateParams;
                    //$rootScope.$state.go('home', {site: $rootScope.$stateParams.site});
            };
             
    }]
);
