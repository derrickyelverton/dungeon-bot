function Character() {
	// create handle to canvas
	this.canvas = document.getElementById('myCanvas');
	// create handle to (2d) context
	this.c = this.canvas.getContext('2d');
	
	this.rollButtonEl = document.getElementById('buttonRoll');
	this.raceSelectEl = document.getElementById('raceField');
	
	this.characterSprite = new Sprite('img/knight.png', 32, 32, 0, 128, 4, 0, null, 0, 0);
	
	this.timer = new Timer();
	// initial draw
	this.draw(this.timer.getSeconds());
}

Character.prototype.inArray = function(element, arr) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] === element) {
			return true;
		}
	}    
	return false;
}

Character.prototype.removeFromArray = function(element, arr) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == element)
			arr.splice(i, 1);
	}
	return arr;
}

Character.prototype.draw = function(timeStamp) {
	this.runTime = this.runTime + 1;
	this.timer.update();

	this.c.fillStyle = '#3B5323';
	this.c.fillRect (0, 0, this.canvas.width, this.canvas.height);

	this.c.fillStyle = '#000000';
	this.c.font = '12px Arial, Sans-serif';
		
	this.drawCharacter();
}

Character.prototype.drawCharacter = function() {
	this.characterSprite.setPosition(this.characterSprite.Position.x, this.characterSprite.Position.y);
	this.characterSprite.animate(this.c, this.timer);
	this.characterSprite.draw(this.c);
}

Character.prototype.clearCanvas = function() {
	this.c.clearRect (0, 0, this.canvas.width, this.canvas.height);
}