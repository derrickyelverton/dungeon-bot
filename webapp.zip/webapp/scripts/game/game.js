function Game() {
    // create a grid object with two properties width and height
	this.grid = {
		width: 25,
		height: 25
	}
	
	this.scroll = {
		x: 0,
		y: 0
	}

	this.pointColor = null;

	this.lastRunTime = 0;
	this.lastSecond = 0;
	this.runTime = 0;
	this.boardLevel = 0;
	
	// create handle to canvas
	this.canvas = document.getElementById('myCanvas');
	// create handle to (2d) context
	this.c = this.canvas.getContext('2d');

	// create heatmap	
	this.heatMapCanvas = document.createElement("canvas");
	this.heatMapCanvas.height = this.canvas.height;
	this.heatMapCanvas.width = this.canvas.width;
	this.heatMapCanvasContext = this.heatMapCanvas.getContext("2d");
	this.heatMapImage = new Image();
	this.heatMapImage.src = "img/heatmap.png";
	this.heatMapCanvasContext.fillStyle = '#3B5323';
	this.heatMapCanvasContext.fillRect (0, 0, this.canvas.width, this.canvas.height);	
	this.heatMapCanvasContext.drawImage(this.heatMapImage, 0, 0, this.canvas.width, this.canvas.height);
	
	// create a tile array
	this.tileMap = [];

	// create a grass image
	this.background = new Image();
	this.background.src = "img/background.png";
	
	// create a grass image
	this.trees = new Image();
	this.trees.src = "img/treeslight.png";

	this.tile = new Image();
	this.tile.src = "img/landtile.png";	

	this.canvasWidth = this.grid.width * this.tile.width;
	this.canvasHeight = this.grid.height * this.tile.height;

	// create a dirt image
	this.dirt = new Image();
	this.dirt.src = "img/dirt.png";
	
	// Initialize our sprite array
	this.spritesheet = ['img/knight.png', 'img/badguyPawn.png', 'img/badguyBoss.png'];
	this.currentHero = 0;
	this.badguyPawn = 1;
	this.badguyBoss = 2;

	// Preload the sprite images
	for (var i = 0; i < this.spritesheet.src; i++) {
		var i = new Image();
		i.src = this.spritesheet[i];
	}
		
	// create the hero
	this.hero = new Sprite(this.spritesheet[this.currentHero], 32, 32, 0, 128, 4, 0, 0, this.canvas.width/2, this.canvas.height/2);
	// create the bad guys
	//src, width, height, offsetX, offsetY, frames, duration, badGuyType, startPositionX, startPositionY, health, experience
	this.badguys = [
		new Sprite('img/goblin.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 705, 120, 25, 10),
		new Sprite('img/orc.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 620, 80, 55, 10),
		new Sprite('img/dragon.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 435, 120, 75, 10),
		new Sprite('img/halfling.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 340, 140, 15, 10),
		new Sprite('img/elf.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 155, 180, 15, 10),
		new Sprite('img/dwarf.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 160, 220, 15, 10),
		new Sprite('img/catfolk.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 475, 100, 15, 10),
		new Sprite('img/dhampir.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 180, 200, 15, 10),
		new Sprite('img/drow.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 595, 300, 15, 10),
		new Sprite('img/fetchling.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 200, 200, 15, 10),
		new Sprite(this.spritesheet[this.badguyPawn], 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 655, 100, 15, 10),
		new Sprite(this.spritesheet[this.badguyBoss], 32, 32, 0, 128, 4, 0, BadguyType.Boss, 800, 330, 100, 20)
	];
	
	// setup game timer
	this.timer = new Timer();

	// initial draw
	this.draw(this.timer.getSeconds());
}

// There's probably a more efficient way to do this
Game.prototype.rotateMatrix = function(matrix, mW, mH, sW, sH) {
	var m = [];
	var sW = (sW === undefined) ? 0 : sW;
	var sH = (sH === undefined) ? 0 : sH;

	for (var i = sW; i < mW; i++) {
		for (var j = sH; j < mH; j++) {
			var row = (mW - j) - 1;

			if (this.tileMap[row] !== undefined && this.tileMap[row][i]) {
				m[i] = (m[i] === undefined) ? [] : m[i];
				m[i][j] = this.tileMap[row][i];
			}
		}
	}

	return m;
}

Game.prototype.inArray = function(element, arr) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] === element) {
			return true;
		}
	}    
	return false;
}

Game.prototype.removeFromArray = function(element, arr) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i] == element)
			arr.splice(i, 1);
	}
	return arr;
}

Game.prototype.calculateSpriteOffset = function(x, y) {
	if (x === 0 && y === 0) { // standing still
		this.hero.setOffset(0, 128);
		this.hero.setFrames(1);
		this.hero.setDuration(0);
	} else if (x > 0 && y === 0) { // East
		if (this.hero.offsetY !== 192) {
			this.hero.setOffset(0, 192);
			this.hero.setFrames(6);
			this.hero.setDuration(500);
		}
	} else if (x < 0 && y === 0) { // West
		if (this.hero.offsetY !== 224) {
			this.hero.setOffset(0, 224);
			this.hero.setFrames(6);
			this.hero.setDuration(500);
		}
	} else if (x === 0 && y > 0) { // South
		if (this.hero.offsetY !== 128 || this.hero.frames !== 4) {
			this.hero.setOffset(0, 128);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	} else if (x === 0 && y < 0) { // North
		if (this.hero.offsetY !== 160) {
			this.hero.setOffset(0, 160);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	} else if (x > 0 && y < 0) { // North East
		if (this.hero.offsetY !== 0) {
			this.hero.setOffset(0, 0);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	} else if (x > 0 && y > 0) { // South East
		if (this.hero.offsetY !== 32) {
			this.hero.setOffset(0, 32);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	} else if (x < 0 && y < 0) { // North West
		if (this.hero.offsetY !== 64) {
			this.hero.setOffset(0, 64);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	} else if (x < 0 && y > 0) { // South West
		if (this.hero.offsetY !== 96) {
			this.hero.setOffset(0, 96);
			this.hero.setFrames(4);
			this.hero.setDuration(500);
		}
	}
}

Game.prototype.calculateHeroSpeed = function() {
	// Calculate X speed
	if (this.inArray(Keys.RIGHT, Keys.getDown) || this.inArray(Keys.D, Keys.getDown)) {
		this.hero.Speed.x += (this.hero.Speed.x <= this.hero.Speed.MAX) ? this.hero.Speed.INCREASE : 0;
		this.hero.direction = Direction.RIGHT;
	} 
	else if (this.inArray(Keys.LEFT, Keys.getDown) || this.inArray(Keys.A, Keys.getDown)) {
		this.hero.Speed.x -= (this.hero.Speed.x >= (this.hero.Speed.MAX * -1)) ? this.hero.Speed.INCREASE : 0;
		this.hero.direction = Direction.LEFT;
	} 
	else {
		// No right / left keys are being pressed
		if (this.hero.Speed.x > 0) {
			this.hero.Speed.x += this.hero.Speed.FRICTION * -1;
			this.hero.Speed.x = (this.hero.Speed.x < 0) ? 0 : this.hero.Speed.x;
		}
		else if (this.hero.Speed.x < 0) {
			this.hero.Speed.x += this.hero.Speed.FRICTION;
			this.hero.Speed.x = (this.hero.Speed.x > 0) ? 0 : this.hero.Speed.x;
		}
	}

	// Calculate Y speed
	if (this.inArray(Keys.DOWN, Keys.getDown) || this.inArray(Keys.S, Keys.getDown)) {
		this.hero.Speed.y += (this.hero.Speed.y <= this.hero.Speed.MAX) ? this.hero.Speed.INCREASE : 0;
		this.hero.direction = Direction.DOWN;
	} 
	else if (this.inArray(Keys.UP, Keys.getDown) || this.inArray(Keys.W, Keys.getDown)) {
		this.hero.Speed.y -= (this.hero.Speed.y >= (this.hero.Speed.MAX * -1)) ? this.hero.Speed.INCREASE : 0;
		this.hero.direction = Direction.UP;
	} 
	else {
		// No up / down keys are being pressed
		if (this.hero.Speed.y > 0) {
			this.hero.Speed.y += this.hero.Speed.FRICTION * -1;
			this.hero.Speed.y = (this.hero.Speed.y < 0) ? 0 : this.hero.Speed.y;
		} else if (this.hero.Speed.y < 0) {
			this.hero.Speed.y += this.hero.Speed.FRICTION;
			this.hero.Speed.y = (this.hero.Speed.y > 0) ? 0 : this.hero.Speed.y;
		}
	}
}

Game.prototype.updateHero = function() {
	if (!this.hero.dead) {	
		 
		if (this.hero.action == Action.WALKING || this.hero.action == Action.STANDING) {
			// Change the X/Y offset of the spritesheet and the "speed" of the animation depending on X/Y speed
			this.calculateSpriteOffset(this.hero.Speed.x, this.hero.Speed.y);
			this.calculateHeroSpeed();
			this.caculateHeroPosition();
		}
		

		this.caculateHeroFireball();
		this.caculateHeroPunch();
		this.caculateHeroKick();
	}
}

Game.prototype.caculateHeroPosition = function() {
	// Make sure to restraint the character to move inside the canvas
	if ((this.hero.Position.x + this.hero.Speed.x) > 0 && (this.hero.Position.x + this.hero.Speed.x) < (this.canvas.width - this.hero.width)) {
		this.hero.Position.x += this.hero.Speed.x;
	}

	if ((this.hero.Position.y + this.hero.Speed.y) > 0 && (this.hero.Position.y + this.hero.Speed.y) < (this.canvas.height - this.hero.height)) {
		this.hero.Position.y += this.hero.Speed.y;
	}
}

Game.prototype.caculateHeroFireball = function() {
	if (this.inArray(Keys.SHIFT, Keys.getDown) || this.inArray(Keys.SPACE, Keys.getDown)) {
		this.hero.shootFireball( new Sprite('img/fireball.png', 32, 32, 0, 0, 4, 0), this.hero.Position.x, this.hero.Position.y, this.hero.direction);
	}
}

Game.prototype.caculateHeroKick = function() {
	if (this.hero.action == Action.KICK && this.hero.actionCount == 0) {
		this.hero.action = Action.STANDING;
	}
	if (this.inArray(Keys.K, Keys.getDown)) {
		if (this.hero.direction == Direction.RIGHT) {
			this.hero.setOffset(0, 256);
		}
		else if (this.hero.direction == Direction.LEFT) {
			this.hero.setOffset(0, 288);
		}
		this.hero.setFrames(4);
		this.hero.setDuration(500);
		this.hero.action = Action.KICK;
		this.hero.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (this.hero.action == Action.KICK) {
		this.hero.actionCount = this.hero.actionCount - 1; 
	}	
}

Game.prototype.caculateHeroPunch = function() {
	if (this.hero.action == Action.PUNCH && this.hero.actionCount == 0) {
		this.hero.action = Action.STANDING;
	}
	if (this.inArray(Keys.P, Keys.getDown)) {
		if (this.hero.direction == Direction.RIGHT) {
			this.hero.setOffset(0, 320);
		}
		else if (this.hero.direction == Direction.LEFT) {
			this.hero.setOffset(0, 352);
		}
		this.hero.setFrames(4);
		this.hero.setDuration(500);
		this.hero.action = Action.PUNCH;
		this.hero.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (this.hero.action == Action.PUNCH) {
		this.hero.actionCount = this.hero.actionCount - 1; 
	}	
}

Game.prototype.drawBadguys = function() {
	for (var b=0; b < this.badguys.length; b++) {
		var badguy = this.badguys[b];
		if (!badguy.dead) {
			// collision detection and hit 
			if (this.hero.health > 0) {
				if (badguy.collisionDection(this.hero.Position.x, this.hero.Position.y)) {
					this.hero.hit(badguy.damage);
					if (this.hero.health <= 0) {
						this.hero.dead = true;
						this.hero.shown = false;
						alert("Game Over");
					}
				}
				var hitCount = this.hero.attack(badguy.Position.x, badguy.Position.y)
				if (hitCount > 0) {
					badguy.hit(hitCount * this.hero.damage);
					if (badguy.health <= 0) {
						this.hero.experience = this.hero.experience + badguy.experience;
						if (this.hero.experience > 100) {
							this.hero.level = this.hero.level + 1;
							this.hero.totalExperience = this.hero.totalExperience + 100;
							this.hero.experience = this.hero.experience - 100;
						}
						badguy.dead = true;
						badguy.shown = false;
						this.removeFromArray(badguy, this.badguys); 
						if (this.badguys.length == 0) {
							alert("You WIN!");
							this.boardLevel = this.boardLevel + 1;
							this.badguys = [
								new Sprite('img/goblin.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 705, 120, 25, 10),
								new Sprite('img/orc.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 620, 80, 55, 10),
								new Sprite('img/dragon.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 435, 120, 75, 10),
								new Sprite('img/halfling.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 340, 140, 15, 10),
								new Sprite('img/elf.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 155, 180, 15, 10),
								new Sprite('img/dwarf.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 160, 220, 15, 10),
								new Sprite('img/catfolk.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 475, 100, 15, 10),
								new Sprite('img/dhampir.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 180, 200, 15, 10),
								new Sprite('img/drow.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 595, 300, 15, 10),
								new Sprite('img/fetchling.png', 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 200, 200, 15, 10),
								new Sprite(this.spritesheet[this.badguyPawn], 32, 32, 0, 128, 4, 0, BadguyType.Pawn, 655, 100, 15, 10),
								new Sprite(this.spritesheet[this.badguyBoss], 32, 32, 0, 128, 4, 0, BadguyType.Boss, 800, 330, 100, 20)
							];
							
						}
					}
				}
			}

			// move the badguy (currently just tracking the hero
			distance = this.pointDistance(badguy.Position.x, badguy.Position.y, this.hero.Position.x, this.hero.Position.y);
			
			if (distance <= 50) {
				badguy.Position.x = ((this.hero.Position.x > badguy.Position.x)?badguy.Position.x+1:badguy.Position.x-1);
				badguy.Position.y = ((this.hero.Position.y > badguy.Position.y)?badguy.Position.y+1:badguy.Position.y-1);
			}
			else {
				var aiDecission = Math.round(Math.random() * 10);
				if (aiDecission < 1) {
					badguy.Position.x = badguy.Position.x + 1;
				}				
				else if (aiDecission < 2) {
					badguy.Position.x = badguy.Position.x - 1;
				}
/*				
				else if (aiDecission < 3) {
					badguy.Position.x = badguy.Position.x + 1;
				}				
				else if (aiDecission < 4) {
					badguy.Position.x = badguy.Position.x - 1;
				}				
*/
			}
			badguy.setPosition(badguy.Position.x, badguy.Position.y);
			badguy.animate(this.c, this.timer);
			badguy.draw(this.c);		
		}
	}
}

Game.prototype.pointDistance = function(aX, aY, bX, bY) {
	return this.distance(aX, bX) + this.distance(aY, bY);
}

Game.prototype.distance = function(aX, bX) {
	return (aX > bX) ? Math.abs(aX - bX) : Math.abs(bX - aX); 
}

Game.prototype.draw = function(timeStamp) {
	this.runTime = this.runTime + 1;
	this.timer.update();

	this.updateScrollOffset();

	if (this.boardLevel == 0) {
	//	this.drawGrid();
		this.drawGridWithScroll();
	}
	else {
		this.drawGridLevel();
	}
	
	this.updateHero();
	
	this.drawBadguys();
	this.drawHero();
}

Game.prototype.drawHero = function() {
    if (!this.hero.dead) { 	
		if (this.hero.fireballCount > 0) {
			for (var f = 0; f < this.hero.fireballs.length; f++) {
				var fb = this.hero.fireballs[f];
				if (fb) {
					if (this.pointDistance(fb.Position.x, fb.Position.y, fb.startPosition.x, fb.startPosition.y) < 100) {
						fb.Position.x = (fb.direction == Direction.LEFT) ? fb.Position.x - 1: fb.Position.x + 1;
						fb.setPosition(fb.Position.x, fb.Position.y);
						fb.animate(this.c, this.timer);
						fb.draw(this.c);
					}
					else {
						this.removeFromArray(fb, this.hero.fireballs);
						this.hero.fireballCount = this.hero.fireballCount - 1;
						this.hero.magic = this.hero.magic + 10;
					}
				}
			}
		}
        // compare background pixel color if not in the isometric dont allow moving there		
		//'#3B5323';
		this.pointColor = this.getColorAtPoint(this.heatMapCanvasContext, this.hero.Position.x, this.hero.Position.y);
		if (this.pointColor[0] != 59 && this.pointColor[1] != 83 && this.pointColor[2] != 35) {
			this.hero.setPosition(this.hero.Position.x, this.hero.Position.y);
		}
		this.hero.animate(this.c, this.timer);
		this.hero.draw(this.c);
	}
}

Game.prototype.getColorAtPoint = function(context, x, y) {
	var data = context.getImageData(x, y, 1, 1).data;
	return data;
	//return new Color([data[0], data[1], data[2]]);
}

Game.prototype.clearCanvas = function() {
	this.c.clearRect (0, 0, this.canvas.width, this.canvas.height);
}

Game.prototype.drawGrid = function() {

	this.c.drawImage(this.background, 0, 0, this.canvas.width, this.canvas.height);

	for (var row = 0; row < this.grid.width; row++) {
		for (var col = 0; col < this.grid.height; col++) {

			var tilePositionX = (row - col) * this.tile.height;
			// Center the grid horizontally
			tilePositionX += (this.canvas.width / 2) - (this.tile.width / 2);
			var tilePositionY = (row + col) * (this.tile.height / 2);

			if (this.tileMap[row] != null && this.tileMap[row][col] != null) {
				this.c.drawImage(this.dirt, Math.round(tilePositionX), Math.round(tilePositionY), this.dirt.width, this.dirt.height);
			} else {
				this.c.drawImage(this.tile, Math.round(tilePositionX), Math.round(tilePositionY), this.tile.width, this.tile.height);	
				if (row == 0 && col == 0) {
					this.c.drawImage(this.trees, Math.round(tilePositionX), Math.round(tilePositionY), this.tile.width, this.tile.height);	
				}
			}
		}	
	}
	
}

Game.prototype.drawGridWithScroll = function() {

	this.c.drawImage(this.background, 0, 0, this.canvas.width, this.canvas.height);

	for (var row = 0; row < this.grid.width; row++) {
		for (var col = 0; col < this.grid.height; col++) {

			var tilePositionX = (row - col) * this.tile.height;
			// Center the grid horizontally
			tilePositionX += (this.canvas.width / 2) - (this.tile.width / 2);
			var tilePositionY = (row + col) * (this.tile.height / 2);

			if (this.tileMap[row] != null && this.tileMap[row][col] != null) {
				this.c.drawImage(this.dirt, Math.round(tilePositionX+this.scroll.x), Math.round(tilePositionY+this.scroll.y), this.dirt.width, this.dirt.height);
			} else {
				this.c.drawImage(this.tile, Math.round(tilePositionX+this.scroll.x), Math.round(tilePositionY+this.scroll.y), this.tile.width, this.tile.height);	
			}
		}	
	}
	
}

Game.prototype.updateScrollOffset = function() {	
	if (this.inArray(Keys.UP, Keys.getDown)) {
		if (this.scroll.y < this.canvasHeight && (this.scroll.y + this.tile.height < this.canvasHeight)) { 
			this.scroll.y += this.tile.height;
		}
	}
	else if (this.inArray(Keys.DOWN, Keys.getDown)) {
		if (this.scroll.y >= 0 && (this.scroll.y - this.tile.height >= 0)) { 
			this.scroll.y -= ((this.scroll.y - this.tile.height) >= 0) ? this.tile.height : 0;
		}
	}
	else if (this.inArray(Keys.RIGHT, Keys.getDown)) {
		if (this.scroll.x >= 0 && (this.scroll.x - this.tile.width >= 0)) { 
			this.scroll.x -= ((this.scroll.x - this.tile.width) >= 0) ? this.tile.width : 0;
		}
	}
	else if (this.inArray(Keys.LEFT, Keys.getDown)) {
		if (this.scroll.x < this.canvasWidth && (this.scroll.x + this.tile.width < this.canvasWidth)) { 
			this.scroll.x += this.tile.width;
		}
	}
}

Game.prototype.drawGridLevel = function() {

	this.c.drawImage(this.background, 0, 0, this.canvas.width, this.canvas.height);

	for (var row = 0; row < this.grid.width; row++) {
		for (var col = 0; col < this.grid.height; col++) {

			var tilePositionX = (row - col) * this.tile.height;

			// Center the grid horizontally
			tilePositionX += (this.canvas.width / 2) - (this.dirt.width / 2);

			var tilePositionY = (row + col) * (this.dirt.height / 2);

			this.c.drawImage(this.dirt, Math.round(tilePositionX), Math.round(tilePositionY), this.dirt.width, this.dirt.height);
		}	
	}
	
}
