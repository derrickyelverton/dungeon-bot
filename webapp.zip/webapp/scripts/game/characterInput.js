function CharacterInput() {
	this.loggedIn = false;
	this.accessRequested = false;

	// set the user input 
	window.addEventListener('keydown', this.handleKeyDown, false);
	window.addEventListener('keyup', this.handleKeyUp, false);
	characterController.rollButtonEl.addEventListener('click', this.handleRollClick, false);
	characterController.raceSelectEl.addEventListener('change', this.handleRaceSelect, false);

	
}

CharacterInput.prototype.handleRaceSelect = function(e) {
	characterController.characterSprite = new Sprite('img/'+raceField.value+'.png', 32, 32, 0, 128, 4, 0, null, 0, 0);
	characterController.characterSprite.setPosition(characterController.characterSprite.Position.x, characterController.characterSprite.Position.y);
	characterController.characterSprite.animate(characterController.c, characterController.timer);
	characterController.characterSprite.draw(characterController.c);

}

CharacterInput.prototype.handleRollClick = function(e) {

	document.getElementById('strengthField').value = diceController.roll(2, 8);
	document.getElementById('dexterityField').value = diceController.roll(2, 8);
	document.getElementById('constitutionField').value = diceController.roll(2, 8);
	document.getElementById('intelligenceField').value = diceController.roll(2, 8);
	document.getElementById('wisdomField').value = diceController.roll(2, 8);
	document.getElementById('charismaField').value = diceController.roll(2, 8);

}


CharacterInput.prototype.handleInputCommand = function(userInputString) {

}

CharacterInput.prototype.handleKeyDown = function(e) {
	/*
	switch (e.keyCode) {
	    case Keys.ENTER:
		case Keys.SHIFT:
		case Keys.LEFT:
        case Keys.RIGHT:
		case Keys.UP:
		case Keys.DOWN:
		case Keys.R:
	}
	*/
}

CharacterInput.prototype.handleMouseDown = function(e) {
}

CharacterInput.prototype.handleKeyUp = function(e) {
}	
