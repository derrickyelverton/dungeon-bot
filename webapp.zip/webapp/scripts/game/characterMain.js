var diceController = null;
var characterController = null;
var characterInputController = null;

window.onload = function() {
    diceController = new Dice();
    characterController = new Character();
    characterInputController = new CharacterInput();
}
