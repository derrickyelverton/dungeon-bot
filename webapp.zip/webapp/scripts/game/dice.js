// A generic dice class

var Dice = function() {
	
}

Dice.prototype.roll = function(numberOfDice, sided) {
	var totalCount = 0;
	for (var d = 0; d < numberOfDice; d ++) { 
		var value = Math.random() * 10;
		totalCount = totalCount + Math.round(value);
	}
	return totalCount;
}
