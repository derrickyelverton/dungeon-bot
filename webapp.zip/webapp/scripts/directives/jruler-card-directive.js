/**
 * Created by saturn night on 06/22/2015.
 */
angular.module('BattleChasersWebApp').directive('jrulercard', function () {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/jrulercard.html",
        scope: {
            selected: "=",
            cardId: "=cardId"
        },
        link: function(scope) {
        	
        	scope.cardId;
        	
        	
        	
            scope.attackPoints      = 100;
            scope.defencePoints     = 100; 
       }
    }
});
