/**
 * Created by saturn night on 06/22/2015.
 */
angular.module('BattleChasersWebApp').directive('card', function () {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/card.html",
        scope: {
            selected: "=",
            cardId: "=cardId"
        },
        link: function(scope) {
        	
        	scope.cardId;
        	
        	
        	
            scope.attackPoints      = 100;
            scope.defencePoints     = 100; 
       }
    }
});
