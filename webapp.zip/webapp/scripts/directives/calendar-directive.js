/**
 * Created by dyelvert on 06/22/2015.
 */

    function _removeTime(date) {
        return new Date();// date.setHours(0).setMinutes(0).setSeconds(0).setMilliseconds(0);
    }

    function _buildMonth(scope, start, month) {
        scope.weeks = [];
        var done = false, date = $.extend({}, start), monthIndex = date.month(), count = 0;
        while (!done) {
            scope.weeks.push({ days: _buildWeek( $.extend({}, date), month) });
            date.add(1, "w");
            done = count++ > 2 && monthIndex !== date.month();
            monthIndex = date.month();
        }
    }

    function _buildWeek(date, month) {
        var days = [];
        for (var i = 0; i < 7; i++) {
            days.push({
                name: date.format("dd").substring(0, 1),
                number: date.getDate(),
                isCurrentMonth: date.getMonth() === month.getMonth(),
                isToday: date.isSame(new Date(), "day"),
                date: date
            });
            date =  $.extend({}, date);
            date.add(1, "d");
        }
        return days;
    }

    
angular.module('BattleChasersWebApp').directive('calendar', function () {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/calendar.html",
        scope: {
            selected: "="
        },
        link: function(scope) {
            scope.selected = _removeTime(scope.selected || new Date());
            scope.month =  $.extend({}, scope.selected);

            var start = $.extend({}, scope.selected);
            start.date(1);
            _removeTime(start.day(0));

            _buildMonth(scope, start, scope.month);

            scope.select = function(day) {
                scope.selected = day.date;  
            };

            scope.next = function() {
                var next = $.extend({}, scope.month);
                _removeTime(next.month(next.month()+1).date(1));
                scope.month.month(scope.month.month()+1);
                _buildMonth(scope, next, scope.month);
            };

            scope.previous = function() {
                var previous = $.extend({}, scope.month);
                _removeTime(previous.month(previous.month()-1).date(1));
                scope.month.month(scope.month.month()-1);
                _buildMonth(scope, previous, scope.month);
            };
       }
    }
});
