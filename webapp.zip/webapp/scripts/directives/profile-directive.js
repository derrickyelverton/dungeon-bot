/**
 * Created by saturn night on 06/22/2015.
 */
angular.module('BattleChasersWebApp').directive('profile', function () {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/profile.html",
        scope: {
            selected: "="
        },
        link: function(scope) {
   /*     	
            scope.hitPoints      = $rootScope.profile.hitPoints;
            scope.handCount      = $rootScope.profile.handCount; 
            scope.stoneCount     = $rootScope.profile.stoneCount;
            scope.deckCount      = $rootScope.profile.deckCount;
            scope.graveYardCount = $rootScope.profile.graveYardCount; 
            scope.lightCount     = $rootScope.profile.lightCount;
            scope.fireCount      = $rootScope.profile.fireCount;
            scope.waterCount     = $rootScope.profile.waterCount;
            scope.windCount      = $rootScope.profile.windCount;
            scope.darkCount      = $rootScope.profile.darCount;
            scope.voidCount      = $rootScope.profile.voidCount;
            scope.moonCount      = $rootScope.profile.moonCount;
   */     
        	
            scope.hitPoints      = 4000;
            scope.handCount      = 10; 
            scope.stoneCount     = 20;
            scope.deckCount      = 52;
            scope.graveYardCount = 30; 
            scope.lightCount     = 10;
            scope.fireCount      = 30;
            scope.waterCount     = 20;
            scope.windCount      = 10;
            scope.darkCount      = 20;
            scope.voidCount      = 10;
            scope.moonCount      = 40;
       }
    }
});
