/**
 * Created by saturn night on 06/22/2015.
 */
angular.module('BattleChasersWebApp').directive('scene', function () {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/scene.html",
        scope: {
            selected: "=",
            cardId: "=sceneId"
        },
        link: function(scope) {
       }
    }
});
