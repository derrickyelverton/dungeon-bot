/**
 * Created by saturn night on 06/22/2015.
 */
angular.module('BattleChasersWebApp').directive('background', function ($timeout) {
    return {
        restrict: "E",
        templateUrl: "scripts/directives/templates/background.html",
        scope: {
            selected: "=",
            backgroundlayerId: "=Id"
        },
        link: function(scope) {
            scope.actionTimeOut = 2000;
            // {"rock", "shake", "roll", "doNothing"}
            scope.actionType = "doNothing";

            if (scope.actionType=='rock') {
                $timeout(scope.rock, scope.actionTimeout);
            }
            else if (scope.actionType=='shake') {
                $timeout(scope.shake, scope.actionTimeout);
            }
            else if (scope.actionType=='roll') {
                $timeout(scope.roll, scope.actionTimeout);
            }
            else if (scope.actionType=='doNothing') {
                //$timeout(scope.doNothing, scope.actionTimeout);
            }   
            
            scope.rock = function() {
            	// back ground image should rock (move left then move right)
            };
            
            scope.shake = function() {
            	// back ground image should shake (move back and forth rapidly and a short distance
            };
            
            scope.roll = function() {
            	// back ground image should roll (move left up and right down (rotate) then right up and left down
            };
        
            scope.doNothing = function() {
            	// 
            };
        
        }
    }
});
