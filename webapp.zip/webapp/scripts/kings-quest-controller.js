/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('KingsQuestController', ['$scope', '$rootScope', '$stateParams', 'GameService', 'CanvasService', 'SpriteService',
    function ($scope, $rootScope, $stateParams, GameService, CanvasService, SpriteService) {

        'use strict';
        $rootScope.setShowBackButton($rootScope.isMobile);     
        
        // setup  canvas service calling
        $scope.getCanvas = function (canvasId) {
            // call the server to get parameter with that id
            CanvasService.getCanvas({id: canvasId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.canvas = response;
                        if ($scope.canvas) {
                          	$scope.setGameName($scope.canvas.gameName);
                        		$scope.setGameMode($scope.canvas.gameMode);
                        		$scope.setGameMap($scope.canvas.backgrounds);
                        		$scope.setGameMapHeatMap($scope.canvas.heatMaps);
                        		$scope.setGameItems($scope.canvas.items);
                        		$scope.setGameStores($scope.canvas.stores);
                        		$scope.setGameDialogs($scope.canvas.dialogs);
                        		$scope.setGameBadGuys($scope.canvas.badGuys);
                        		$scope.setGameBadGuys($scope.canvas.badGuys);
                        		$scope.setGameHero($scope.canvas.hero);
                        		$scope.setGameRows($scope.canvas.rows);
                        		$scope.startGame();
                        }
                    }
                },
                function (status) {           	
                		$scope.status = status;
                		if ($scope.status) {
            			}           	
                }
            );
        };   
        
        $scope.loadHero = function (heroId) {
	    	    if (heroId != null) {
	    	    		SpriteService.getSprite({id: heroId}).$promise.then(
                    function (response) {
                        if (response) {
                        		$scope.hero = response;
    	                        if ($scope.hero.id != null) {
	                        		var position = gameController.hero.Position;
	                        		var direction = gameController.hero.direction;
	                    			gameController.hero = gameController.createHero($scope.hero);
	                        		gameController.setupNewLevel();
                        			gameController.hero.Position = position;
                        			gameController.hero.direction = direction;
	                        }                        		
                        }
                    },
                    function (status) {
                    }
	            );	    	    	
	    	    }
        };
        
        $scope.setupHero = function () {
    			var position = gameController.hero.Position;
			var direction = gameController.hero.direction;
			gameController.hero = gameController.createHero($scope.hero);
			gameController.hero.Position = position;
			gameController.hero.direction = direction;        	
        };
        
        $scope.saveHero = function () {
        		$scope.hero = gameController.hero;
        	    if ($scope.hero.id == 12) {
        	    	    // 12 is the default hero sprite
        	    		// set id to null to create a new sprite from the default 
        	    		$scope.hero.id = null;
        	    }
        	    if ($scope.hero.id == null) {
    	            SpriteService.createSprite($scope.hero).$promise.then(
	                function (response) {
	                    if (response) {
	                        $scope.hero = response;
	                        if ($scope.hero.id != null) {
	                        		$scope.setupHero();
	                        }
	                    }
	                },
	                function (status) {	
	                		$scope.status = status;
	                		if ($scope.status) {
	                			alert("Server Error: creating sprite. " + status); 
	            			}
	                	
	                }
    		        );    	            
        	    }
        	    else {
	            SpriteService.updateSprite({id: $scope.hero.id}, $scope.hero).$promise.then(
	                function (response) {
	                    if (response) {
	                        $scope.hero = response;
	                        if ($scope.hero.id != null) {
	                        		$scope.setupHero();
	                        }
	                    }
	                },
	                function (status) {	
	                		$scope.status = status;
	                		if ($scope.status) {
	                			alert("Server Error: updating sprite. " + status); 
	            			}
	                	
	                }
	            );
        	    }
        }; 
        
        $scope.getCanvas(1);
        
        $scope.setGameRows = function(gameRows) {
       		$scope.gameRows = gameRows;
        };        
        
        $scope.setGameName = function(gameName) {
    			$scope.gameName = gameName;
        };
        
        $scope.setGameMode = function(gameMode) {
   			$scope.gameMode = gameMode;
        };
        
        $scope.setGameHero = function(gameHero) {
   			$scope.gameHero = gameHero;
        };
        
        $scope.setGameMap = function(gameMap) {
  			$scope.gameMap = gameMap;
        };

        $scope.setGameMapHeatMap = function(gameMapHeatMap) {
    			$scope.gameMapHeatMap = gameMapHeatMap;
        };
        
        $scope.setGameItems = function(gameItems) {
   			$scope.gameItems = gameItems;
	    };	
		
        $scope.setGameStores = function(gameStores) {
    			$scope.gameStores = gameStores;
	    };

        $scope.setGameDialogs = function(gameDialogs) {
    		    $scope.gameDialogs = [
    			    [[],[],[],[],[],[],[],[]],
    			    [[],[],[],[],[],[],[],[]],
    			    [[],[],[],[],[],[],[],[]],
    			    [[],[],[],[],[],[],[],[]],
    			    [[],[],[],[],[],[],[],[]],
    			    [[],[],[],[],[],[],[],[]],
    			];	   			
	    };
			
        $scope.setGameBadGuys = function(gameBadGuys) {
			$scope.gameBadGuys = gameBadGuys;
  	
	    };
		
        $scope.startGame = function() {
	        	//alert("Starting the game! Welcome to " + gameName + "." );
	        //	constantUtils = new ConstantUtils();
	        	// create the game
	        	gameController = new Game($scope.gameName, $scope.gameMode, $scope.gameMap, $scope.gameMapHeatMap, 
	        			$scope.gameItems, $scope.gameStores, $scope.gameDialogs, $scope.gameBadGuys, $scope.gameHero, $scope.gameRows, $scope.saveHero, $scope.loadHero);
	            //create the input
	        	inputController = new Input();
	
	        	document.getElementById('newGameButton').onclick = function() {
	        		gameController.setupNewGame();
	        		document.getElementById('statusClockStart').innerHTML = "";
	        	}
	
	        	document.getElementById('showHeatMapButton').onclick = function() {
	        		gameController.showHeatMap();
	        	}
	
	        	document.getElementById('showBackgroundButton').onclick = function() {
	        		gameController.showBackground();
	        	}
	
	        	document.getElementById('nextBoardButton').onclick = function() {
	        		gameController.setupNewLevel();
	        	}
	        	
	        	document.getElementById('saveGameButton').onclick = function() {
	        		gameController.saveGame();
	        	}
	
	        	document.getElementById('loadGameButton').onclick = function() {
	        		gameController.loadGame();
	        	}
	        	
	        	// setup a interval of 5 mil to have the game redraw itself 
	        	setInterval(function() {
	        		// draw
	        		if (gameController.timer != undefined) {
	        			if (document.getElementById('statusClockStart').innerHTML == "") {
	        				document.getElementById('statusClockStart').innerHTML = gameController.timer.getSeconds();
	        			}
	        			gameController.draw(gameController.timer.getSeconds());
	        			// update health and magic bar
	        			document.getElementById('healthBar').style = 'height:25px;width:'+gameController.hero.health+'%;background-color:red;';
	        			document.getElementById('magicBar').style = 'height:25px;width:'+gameController.hero.magic+'%;background-color:blue;';
	        			document.getElementById('experienceBar').style = 'height:25px;width:'+gameController.hero.experience+'%;background-color:green;';
	        			document.getElementById('statusPlayerGold').innerHTML = gameController.hero.inventory.gold;
	        			// update status
	        			document.getElementById('statusCanvasWidth').innerHTML = Constants.canvasWidth;
	        			document.getElementById('statusCanvasHeight').innerHTML = Constants.canvasHeight;
	        			document.getElementById('statusClockRun').innerHTML = gameController.timer.getSeconds() - document.getElementById('statusClockStart').innerHTML;
	        			document.getElementById('statusClock').innerHTML = gameController.timer.getSeconds();
	        			if (gameController.timer.getSeconds() != Constants.lastSecond) {
	        				Constants.lastSecond = gameController.timer.getSeconds();
	        				document.getElementById('statusFPS').innerHTML = Constants.runTime - Constants.lastRunTime;
	        				Constants.lastRunTime = Constants.runTime;
	        			}
	        			document.getElementById('statusGameTime').innerHTML = Constants.runTime;
	        			document.getElementById('statusPlayerHealth').innerHTML = gameController.hero.health;
	        			document.getElementById('statusPlayerMagic').innerHTML = gameController.hero.magic;
	        			document.getElementById('statusPlayerExperience').innerHTML = gameController.hero.experience;
	        			document.getElementById('statusPlayerLevel').innerHTML = gameController.hero.level;
	        			
	        			document.getElementById('statusPlayerBoard').innerHTML = Constants.boardLevel;
	        			document.getElementById('statusPlayerMapRow').innerHTML = Constants.mapCurrentRow;
	        			document.getElementById('statusPlayerMapColumn').innerHTML = Constants.mapCurrentColumn;
	        			document.getElementById('statusPlayerX').innerHTML = gameController.hero.Position.x;
	        			document.getElementById('statusPlayerY').innerHTML = gameController.hero.Position.y;
	        			
	        		}
	        	}, 10);        	
        
        }

    }
   
]);

