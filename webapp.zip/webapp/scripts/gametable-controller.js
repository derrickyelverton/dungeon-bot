/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('GameTableController', ['$scope', '$rootScope', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $stateParams, GameService) {

        'use strict';
/*
        $scope.startGame = function() {
	    	// create the game
	    	gameController = new Game();
	        //create the input
	    	inputController = new Input();
	    	document.getElementById('statusClockStart').innerHTML = gameController.timer.getSeconds();
	
	    	// setup a interval of 5 mil to have the game redraw itself 
	    	setInterval(function() {
	    		// draw
	    		gameController.draw(gameController.timer.getSeconds());
	    		// update health and magic bar
	    		document.getElementById('healthBar').style = 'height:25px;width:'+gameController.hero.health+'%;background-color:red;';
	    		document.getElementById('magicBar').style = 'height:25px;width:'+gameController.hero.magic+'%;background-color:blue;';
	    		document.getElementById('experienceBar').style = 'height:25px;width:'+gameController.hero.experience+'%;background-color:green;';
	    		// update status
	    		document.getElementById('statusCanvasWidth').innerHTML = gameController.canvasWidth;
	    		document.getElementById('statusCanvasHeight').innerHTML = gameController.canvasHeight;
	    		document.getElementById('statusClockRun').innerHTML = gameController.timer.getSeconds() - document.getElementById('statusClockStart').innerHTML;
	    		document.getElementById('statusClock').innerHTML = gameController.timer.getSeconds();
	    		if (gameController.timer.getSeconds() != gameController.lastSecond) {
	    			gameController.lastSecond = gameController.timer.getSeconds();
	    			document.getElementById('statusFPS').innerHTML = gameController.runTime - gameController.lastRunTime;
	    			gameController.lastRunTime = gameController.runTime;
	    		}
	    		document.getElementById('statusGameTime').innerHTML = gameController.runTime;
	    		document.getElementById('statusPlayerHealth').innerHTML = gameController.hero.health;
	    		document.getElementById('statusPlayerMagic').innerHTML = gameController.hero.magic;
	    		document.getElementById('statusPlayerExperience').innerHTML = gameController.hero.experience;
	    		document.getElementById('statusPlayerLevel').innerHTML = gameController.hero.level;
	    		document.getElementById('statusScrollXOffset').innerHTML = gameController.scroll.x;
	    		document.getElementById('statusScrollYOffset').innerHTML = gameController.scroll.y;
	    	}, 5);
        };
        
        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Game';
        
		// flow
		// 1 create user
		// 2 login - validate the user against db
		// 3 select or create player
		// 4 select or create deck, 5 view cards
		// 6 create deck - 7 add cards to deck
		// 8 select or create game, 9 settings
		// 10 game
		// 11 game over
		// back to 4
   
        // setup get attribute service calling
        $scope.getGame = function (gameId) {
            // call the server to get parameter with that id
            GameService.getGame({id: gameId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.game = response;
                        if ($scope.game != null) {
                        }
                    }
                },
                function (status) {
                }
            );
        };

        $scope.getGame(1);
        
        $scope.startGame();
*/
}
]);

