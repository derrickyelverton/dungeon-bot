(function () {

	'use strict';

	var BattleChasersWebApp = angular.module('BattleChasersWebApp' , ['ngRoute', 'ngResource', 'ngCookies', 'ngSanitize', 'ui.router', /*'kendo.directives'*/]);
	BattleChasersWebApp.config(['$stateProvider', '$urlRouterProvider',
		function ($stateProvider, $urlRouterProvider) {

			$urlRouterProvider.otherwise('/map');
		
			$stateProvider
			.state('map', {
				url: '/map',
				templateUrl: './views/map.html',
				controller: 'GeoController',
				isSecure: true
			});
					
		}
	]);


}());