/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('ArcadeGameListController', ['$scope', '$rootScope', '$state', '$stateParams', 'GameService', 'CanvasHeroService',
    function ($scope, $rootScope, $state, $stateParams, GameService, CanvasHeroService) {

        'use strict';

        $scope.gameList = null;
        
        $scope.joinGame = function() {
        		//add user to the game then navigate to that game
        		var selectedGameId = $('input[name=gameField]:checked' ).val();
        		if (selectedGameId && $scope.heroId) {
        			// join game
        			var gameObj = null;
        			for (var g=0;g<$scope.gameList;g++) {
        				var gameObj = $scope.gameList[g];
        				if (gameObj.id == selectedGameId) {
        					break;
        				}
        			}
                CanvasHeroService.addHero({canvasId: gameObj.canvasId, heroId: $scope.heroId}).$promise.then(
                    function (response) {
                        if (response) {
                        		$state.go('canvas',{id: gameObj.canvasId, heroId: $scope.heroId});
                        }
                    },
                    function (status) {
                        if (status) {
                        }
                    }
                );        			
        		}
        };
        
        $scope.getGames = function () {
            var params = {
            	filter: "",
                sort: '{"field":"name","dir":"asc"}',
                offset: 0,
                count: 100
            };
            GameService.getGames(params).$promise.then(
                function (response) {
                    if (response) {
                    		$scope.gameList = response.content;
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };        
        
        // setup get attribute service calling
        $scope.getGame = function (gameId) {
            // call the server to get parameter with that id
            GameService.getGame({id: gameId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.game = response;
                        if ($scope.game != null) {
                        }
                    }
                },
                function (status) {
                }
            );
        };
        
        $scope.loadHero = function (heroId) {
	    	    if (heroId != null) {
	    	    		SpriteService.getSprite({id: heroId}).$promise.then(
	                function (response) {
	                    if (response) {
	                    		$scope.hero = response;
	                    }
	                },
	                function (status) {
	                }
	            );	    	    	
	    	    }
        };        

        $scope.loadHero();
        $scope.getGames();

    }
]);

