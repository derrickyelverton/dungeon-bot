/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('BattleChasersController', ['$scope', '$rootScope', '$stateParams', 'GameService', 'SystemUserService', 'PlayerService', 'DeckService', 'AttributeService',  
    function ($scope, $rootScope, $stateParams, GameService, SystemUserService, PlayerService, DeckService, AttributeService) {

        'use strict';
        $scope.selectedUserId = 1;
        $scope.selectedPlayerId = 1;
        $scope.selectedDeckId = 1;
        $scope.selectedCardId = 1;
        $scope.selectedGameId = 1;

        $scope.selectedUserInput = "";
        $scope.selectedPlayerInput = "";
        $scope.selectedDeckInput = "";
        
		$scope.goHome = function() {
			$rootScope.$state.go('cardGame');
		};
		
		$scope.showAbout = function() {
			$rootScope.$state.go('about');
		};

		$scope.createPlayer = function() {
			$rootScope.$state.go('addAnPlayer');
		};

		$scope.showPlayerList = function() {
			$rootScope.$state.go('playerList');
		};

		$scope.editAnPlayer = function() {
			$rootScope.$state.go('editAnPlayer', {playerId: $scope.selectedPlayerId});
		};
		
		$scope.createDeck = function() {
			$rootScope.$state.go('addAnDeck');
		};
		
		$scope.showDeckList = function() {
			$rootScope.$state.go('deckList');
		};
		
		$scope.editAnDeck = function() {
			$rootScope.$state.go('editAnDeck', {deckId: $scope.selectedDeckId});
		};
		
		$scope.showCardList = function() {
			$rootScope.$state.go('cardList');
		};
		
		$scope.createCard = function() {
			$rootScope.$state.go('addAnCard');
		};
		
		$scope.editAnCard = function() {
			$rootScope.$state.go('editAnCard', {cardId: $scope.selectedCardId});
		};
		
		$scope.showUserList = function() {
			$rootScope.$state.go('userList');
		};
		
		$scope.createUser = function() {
			$rootScope.$state.go('addAnUser');
		};
		
		$scope.editAnUser = function() {
			$rootScope.$state.go('editAnUser', {userId: $scope.selectedUserId});
		};		
		
		$scope.showGameList = function() {
			$rootScope.$state.go('gameList');
		};
		
		$scope.createGame = function() {
			$rootScope.$state.go('addAnGame');
		};
		
		$scope.editAnGame = function() {
			$rootScope.$state.go('editAnGame', {gameId: $scope.selectedGameId});
		};			
	
		$scope.loadGame = function() {
			var someId = 1;
			$scope.getGameAndStart(someId);	
		};		
		
		$scope.startGame = function() {
			// create the game
			gameController = new Game();
		    //create the input
			inputController = new Input();
			document.getElementById('statusClockStart').innerHTML = gameController.timer.getSeconds();

			// setup a interval of 5 mil to have the game redraw itself 
			setInterval(function() {
				// draw
				gameController.draw(gameController.timer.getSeconds());
				// update health and magic bar
				document.getElementById('healthBar').style = 'width:'+gameController.hero.health+'%;background-color:red;';
				document.getElementById('magicBar').style = 'width:'+gameController.hero.magic+'%;background-color:blue;';
				document.getElementById('experienceBar').style = 'width:'+gameController.hero.experience+'%;background-color:green;';
				// update status
				document.getElementById('statusCanvasWidth').innerHTML = gameController.canvasWidth;
				document.getElementById('statusCanvasHeight').innerHTML = gameController.canvasHeight;
				document.getElementById('statusClockRun').innerHTML = gameController.timer.getSeconds() - document.getElementById('statusClockStart').innerHTML;
				document.getElementById('statusClock').innerHTML = gameController.timer.getSeconds();
				if (gameController.timer.getSeconds() != gameController.lastSecond) {
					gameController.lastSecond = gameController.timer.getSeconds();
					document.getElementById('statusFPS').innerHTML = gameController.runTime - gameController.lastRunTime;
					gameController.lastRunTime = gameController.runTime;
				}
				document.getElementById('statusGameTime').innerHTML = gameController.runTime;
				document.getElementById('statusPlayerHealth').innerHTML = gameController.hero.health;
				document.getElementById('statusPlayerMagic').innerHTML = gameController.hero.magic;
				document.getElementById('statusPlayerExperience').innerHTML = gameController.hero.experience;
				document.getElementById('statusPlayerLevel').innerHTML = gameController.hero.level;
				document.getElementById('statusScrollXOffset').innerHTML = gameController.scroll.x;
				document.getElementById('statusScrollYOffset').innerHTML = gameController.scroll.y;
			}, 5);

		};
        
        $rootScope.setShowBackButton($rootScope.isMobile);
        $scope.title = 'Card Game';
        
		// flow
		// 1 create user
		// 2 login - validate the user against db
		// 3 select or create player
		// 4 select or create deck, 5 view cards
		// 6 create deck - 7 add cards to deck
		// 8 select or create game, 9 settings
		// 10 game
		// 11 game over
		// back to 4
   
        // setup get attribute service calling
        $scope.getGame = function (gameId) {
            // call the server to get parameter with that id
            GameService.getGame({id: gameId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.game = response;
                        if ($scope.game != null) {
                        }
                    }
                },
                function (status) {
                }
            );
        };

        $scope.getGameAndStart = function (gameId) {
            // call the server to get parameter with that id
            GameService.getGame({id: gameId}).$promise.then(
                function (response) {
                    if (response) {
                        $scope.game = response;
                        if ($scope.game != null) {
                        	$scope.startGame($scope.game);
                        }
                    }
                },
                function (status) {
                }
            );
        };
        
/*
        $("#userSelection").kendoAutoComplete({
            animation: {
        	   close: {
        	     effects: "fadeOut zoom:out",
        	     duration: 300
        	   },
        	   open: {
        	     effects: "fadeIn zoom:in",
        	     duration: 300
        	   }
        	}
        });      
*/
        
        $scope.getAttribute = function () {
        	var filter = null;
            var params = {
                filter: '{"logic":"OR", "filters":[{"field":"attribute.name","operator":"contains","value":"' + $scope.selectedUserInput  + '"} ]}',
                sort: {field:"name",dir:"asc"},
                offset: 0,
                count: 100
            };
            AttributeService.getAttributes(params).$promise.then(
                function (response) {
                    if (response) {
                    	$rootScope.attributesList = response.content;
                    	$rootScope.attriubtes = {
                            dataTextField: "name",
                            dataValueField: "id",
                            dataSource: new kendo.data.DataSource({
                                data: $rootScope.attributesList
                            }),
                            optionLabel: "Select an attribute"
                        };
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };
          
        
        $scope.getGames = function () {
        	var filter = null;
            var params = {
                filter: '{"logic":"OR", "filters":[{"field":"game.name","operator":"contains","value":"' + $scope.selectedGameInput  + '"} ]}',
                sort: {field:"name",dir:"asc"},
                offset: 0,
                count: 100
            };
            GameService.getGames(params).$promise.then(
                function (response) {
                    if (response) {
                    	$rootScope.gamesList = response.content;
                    	$rootScope.games = {
                            dataTextField: "name",
                            dataValueField: "id",
                            dataSource: new kendo.data.DataSource({
                                data: $rootScope.gamesList
                            }),
                            optionLabel: "Select an game"
                        };
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };
  

        $scope.getUsers = function () {
        	var filter = null;
            var params = {
                filter: '{"logic":"OR", "filters":[{"field":"user.name","operator":"contains","value":"' + $scope.selectedUserInput  + '"} ]}',
                sort: {field:"name",dir:"asc"},
                offset: 0,
                count: 100
            };
            SystemUserService.getUsers(params).$promise.then(
                function (response) {
                    if (response) {
                    	$rootScope.usersList = response.content;
                    	$rootScope.users = {
                            dataTextField: "name",
                            dataValueField: "id",
                            dataSource: new kendo.data.DataSource({
                                data: $rootScope.usersList
                            }),
                            optionLabel: "Select an user"
                        };
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };
        
        $scope.getPlayers = function () {
        	var filter = null;
            var params = {
                filter: '{"logic":"OR", "filters":[{"field":"players.name","operator":"contains","value":"' + $scope.selectedPlayerInput  + '"} ]}',
                sort: {field:"name",dir:"asc"},
                offset: 0,
                count: 100
            };
            PlayerService.getPlayers(params).$promise.then(
                function (response) {
                    if (response) {
                    	$rootScope.playersList = response.content;
                    	$rootScope.players = {
                            dataTextField: "name",
                            dataValueField: "id",
                            dataSource: new kendo.data.DataSource({
                                data: $rootScope.playersList
                            }),
                            optionLabel: "Select an player"
                        };
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };
        
        $scope.getDecks = function () {
        	var filter = null;
            var params = {
                filter: '{"logic":"OR", "filters":[{"field":"deck.name","operator":"contains","value":"' + $scope.selectedDeckInput  + '"} ]}',
                sort: {field:"name",dir:"asc"},
                offset: 0,
                count: 100
            };
            DeckService.getDecks(params).$promise.then(
                function (response) {
                    if (response) {
                    	$rootScope.decksList = response.content;
                    	$rootScope.decks = {
                            dataTextField: "name",
                            dataValueField: "id",
                            dataSource: new kendo.data.DataSource({
                                data: $rootScope.decksList
                            }),
                            optionLabel: "Select an deck"
                        };
                    }
                },
                function (status) {
                    if (status) {
                    }
                }
            );
        };        
        
        $scope.getUsers();
        $scope.getPlayers();
        $scope.getDecks();
        /*
        $("#userSelection").kendoAutoComplete({
            dataSource: new kendo.data.DataSource({
                transport: {
                    read: function (options) {
                        var filterSearchParam = $("#userSelection").data("kendoAutoComplete").value().toLowerCase();
                        var params = {
                            filter: {filters:[{logic:"AND",field:"name",operator:"contains",value:filterSearchParam}]},
                            sort: {field:"name",dir:"asc"},
                            offset: 0,
                            count: 100
                        };
                        SystemUserService.getUsers(params).$promise.then(
                            function (response) {
                                if (response) {
                                    $scope.userList = response.content;
                                    options.success(response);
                                }
                            },
                            function (status) {
                                  $rootScope.showFeedbackMessage("Oops. Something went wrong getting the users.", "Get departments error", true);
                            }
                        );
                    }
                },
                schema: {
                    data: "content"
                },
                serverFiltering: true
            }),
            minLength: 3,
            filter: "startswith",
            dataValueField: "id",
            dataTextField: "name",
            template: "<div>#:name#</div>",
            placeholder: "Search by dept name",
            select: function(e) {
                $rootScope.selectedUser = this.dataItem(e.item.index());
            },
            change: function(e) {
            }
        });        
        
        */
        //$scope.getGame(1);
        
        //$scope.startGame();
        
    }
]);

