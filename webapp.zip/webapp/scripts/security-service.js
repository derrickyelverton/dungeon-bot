'use strict';

/* Authentication & Authorization service/controller */

var security_service = angular.module('SATURNNIGHT.security_service', [ 'ngResource' ]);

security_service.config(['$httpProvider',
    function ($httpProvider) {

        $httpProvider.interceptors.push(['$q', 'authService', '$rootScope', '$log', function ($q, authService ,$rootScope, $log) {
            return {
                responseError: function (rejection) {
                    var status = rejection.status;
                    //var config = rejection.config;
                    //var method = config.method;
                    //var url = config.url;
                    if (status == 401) {
                        authService.loginRequired();
                        $log.log('401 received .... ');
                    } else if (status == 403) {
                        authService.notAuthorized();
                    } else {
                        $rootScope.$broadcast("event:error", rejection);
                    }

                    return $q.reject(rejection);
                }
            };
        }]);

    }
]);

security_service.factory('AuthenticationSharedService', ['$rootScope', '$http', 'BrowserLocalData', '$q' , 'authService', 'UserService', 'Session',
    function ($rootScope, $http, BrowserLocalData, $q, authService, UserService, Session) {
        return {
            login: function (param) {
                var data = "username=" + param.username + "&password=" + param.password + "&remember-me=" + param.rememberMe + "&submit=Login";
                $http.post('login/submit', data, {
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    }
                }).success(function (data, status, headers, config) {
                    $rootScope.authenticationError = false;


                    //Find logged in user and set in Session
                    UserService.get(function (data) {
                        Session.loggedInUser = data;
                        $rootScope.loggedInUser = data;
                        $rootScope.authenticated = true;
                        authService.loginConfirmed(data);
                        BrowserLocalData.set('userFullName', data.firstName + " " + data.lastName);
                        BrowserLocalData.set('userLoginId', data.loginId);
                        BrowserLocalData.set('userId', data.id);
                    }, function(){
                        // error retrieving user
                    })

                }).error(function (data, status, headers, config) {
                    $rootScope.authenticationError = true;
                    $rootScope.$broadcast("event:authenticationError", status);
                    $rootScope.authenticated = false;
                    Session.invalidate();
                });

            },
            isAuthenticated: function () {
            	var deferred = $q.defer();
            	var urlCalls = [];
            	urlCalls.push($http.get('protected/authentication_check.gif'));
            	if(!Session.loggedInUser) {
            		urlCalls.push($http.get('rest/security/user'));
            	}
            	
            	$q.all(urlCalls)
            		.then(
        				function(results){
        					if(!Session.loggedInUser) {
        						var data = results[1].data;
	        					Session.loggedInUser = data;
	                            $rootScope.loggedInUser = data;
	                            $rootScope.authenticated = true;
	                            BrowserLocalData.set('userFullName', data.firstName + " " + data.lastName);
	                            BrowserLocalData.set('userLoginId', data.loginId);
	                            BrowserLocalData.set('userId', data.id);
                                $rootScope.$broadcast('event:auth-loginConfirmed');
        					}
        					deferred.resolve(true);
        				}, function(errors){
        					$rootScope.authenticated = false;
                            $rootScope.$broadcast('event:auth-loginRequired', errors);
                            deferred.resolve(false);
        				});
            	
            	return deferred.promise;
            },

            isAuthorized: function (authorizedRoles) {
                /*
                 // TODO
                 */
                return true;
            },

            logout: function () {
                $http.get('app/logout').then(function() {
                	$rootScope.authenticationError = false;
                    $rootScope.loggedInUser = null;
                    $rootScope.authenticated = false;
                    Session.invalidate();
                    authService.userLoggedOut();
                });
            }
        };
    }]);

security_service.factory('authService', ['$rootScope', 'Session', function ($rootScope, Session) {
    return {

        loginConfirmed: function (data, configUpdater) {
            $rootScope.$broadcast('event:auth-loginConfirmed', data);
        },

        loginCancelled: function () {
            $rootScope.$broadcast('event:auth-loginCancelled');
        },

        loginRequired: function () {
            Session.invalidate();
            $rootScope.authenticated = false;
            $rootScope.$broadcast("event:auth-loginRequired");
        },

        notAuthorized: function() {
            $rootScope.$broadcast("event:auth-notAuthorized");
        },

        userLoggedOut: function () {
            $rootScope.$broadcast('event:userLoggedOut');
        }
    };
}]);

security_service.factory('Session', function () {
    return {
        loggedInUser: null,
        //authToken: null,
        invalidate: function () {
            this.loggedInUser = null;
            //this.authToken = null;
        }
    };
});


security_service.factory('BrowserLocalData', [function () {
    return {
        set: function(key, value) {
            localStorage.setItem(key, JSON.stringify(value));
        },
        get: function(key){
            return  ((localStorage.getItem(key) != "undefined")?JSON.parse(localStorage.getItem(key)):null);
        },
        keys: function() {
            return 0;
        },
        remove: function(key) {
            localStorage.removeItem(key);
        },
        invalidate: function () {
            localStorage.clear();
        }
    };
}]);

security_service.factory('UserService', ['$resource', function ($resource) {
    return $resource('rest/security/user', {}, {});
}]);