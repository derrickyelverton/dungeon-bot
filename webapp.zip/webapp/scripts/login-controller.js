/**
 * Created by dyelvert on 12/16/2014.
 */
angular.module('BattleChasersWebApp').controller('LoginController', ['$scope', '$rootScope', '$state', 'AuthenticationSharedService',
    function ($scope, $rootScope, $state, AuthenticationSharedService) {


    	$scope.title = 'Sign in';
    	$rootScope.setShowBackButton(false);

    	/*
        if (BrowserLocalData.get('userFullName') != null && BrowserLocalData.get('userLoginId') != null && BrowserLocalData.get('userId') != null) {
            $scope.username = BrowserLocalData.get('userLoginId');
            $scope.fullName = BrowserLocalData.get('userFullName');
            $scope.userId = BrowserLocalData.get('userId');
            //$scope.userImageUrl = "https://www.saturnnight.com/imageService/rest/person/photo/E/" + $scope.userId + "/150x150";
            $scope.userFoundInCooke = true;
        } else {
        */
            $scope.username = null;
            $scope.fullName = null;
            $scope.userId = null;
            //$scope.userImageUrl = "https://www.saturnnight.com/imageService/rest/person/photo/E/XYZ/150x150";
            $scope.userFoundInCooke = false;
       // }

        $scope.login = function () {
            AuthenticationSharedService.login({
                username: $scope.username,
                password: $scope.password,
                rememberMe: $scope.rememberMe
            });
        };
        
        $scope.goCreateUser = function() {
        	    $state.go('addAnUser');
        };
        
        $scope.differentUser = function () {
          //  BrowserLocalData.remove('userFullName');
          //  BrowserLocalData.remove('userLoginId');
          //  BrowserLocalData.remove('userId');
            $scope.username = null;
            $scope.fullName = null;
            $scope.userId = null;
            //$scope.userImageUrl = "https://www.saturnnight.com/imageService/rest/person/photo/E/XYZ/150x150";
            $scope.userFoundInCooke = false;
        }
    }
]);
