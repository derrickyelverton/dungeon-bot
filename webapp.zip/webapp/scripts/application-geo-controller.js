
angular.module('BattleChasersWebApp').controller('ApplicationGeoController', ['$scope', '$rootScope', '$state', '$stateParams', 
    function ($scope, $rootScope, $state, $stateParams) {

            'use strict';

            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;

            $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {

                    $rootScope.backButton = null;
                    if(toState.name != "/" && toState.name != "home" ) {
                            $rootScope.backButton = "true";
                            $rootScope.previousStateParams = fromParams;
                    }
            });
             
    }]
);
