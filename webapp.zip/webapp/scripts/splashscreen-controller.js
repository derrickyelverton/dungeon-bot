/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('SplashScreenController', ['$scope', '$rootScope', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $stateParams, GameService) {

        'use strict';

		var utils = new Utils();
		var playerName = utils.getRequestParameter("playerName");
		
		document.getElementById('playGauntletGameButton').onclick = function() {
			window.location = "gauntlet.html?playerName=" + playerName;
		}

		document.getElementById('continueGauntletGameButton').onclick = function() {
			window.location = "gauntlet.html?loadGame=true&playerName=" + playerName;
		}        

    }
]);

