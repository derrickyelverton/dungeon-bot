/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('GauntletSplashScreenController', ['$scope', '$rootScope', '$state', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $state, $stateParams, GameService) {

        'use strict';
		$scope.gameName = "Gauntlet";      
        
        $scope.startGauntlet = function() {
//        	   $state.go('gauntlet', {playerName: document.getElementById('playerName').value});
        	   $state.go('gauntlet');
        };
		
        $scope.continueGauntlet = function() {
     	   $state.go('gauntlet');
        };
        
    }
]);

