/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('KingsQuestSplashScreenController', ['$scope', '$rootScope', '$state', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $state, $stateParams, GameService) {

        'use strict';

		$scope.gameName = "Kings Quest";      
        
        $scope.startKingsQuest = function() {
//        	   $state.go('kings-quest', {playerName: document.getElementById('playerName').value});
        	   $state.go('kings-quest');
        };        
        
        $scope.continueGauntlet = function() {
     	   $state.go('kings-quest');
        };
        
    }
]);

