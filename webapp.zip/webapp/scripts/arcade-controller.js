/**
 * Created by dyelvert on 06/22/2015.
 */
angular.module('BattleChasersWebApp').controller('ArcadeController', ['$scope', '$rootScope', '$state', '$stateParams', 'GameService', 
    function ($scope, $rootScope, $state, $stateParams, GameService) {

        'use strict';

		$scope.gameName = "Welcome to The Arcade";      
        
        $scope.loadKingsQuest = function() {
//     	   $state.go('kings-quest-splashscreen', {playerName: document.getElementById('playerName').value});
        	   $state.go('kings-quest-splashscreen');
        };
		
        $scope.loadGauntlet = function() {
     	   $state.go('gauntlet-splashscreen');
        };
        
        $scope.loadBattleChasers = function() {
      	   $state.go('battle-chasers-splashscreen');
         };
        
        $scope.loadGameList = function() {
      	   $state.go('arcade-game-list');
         };

	}
]);

