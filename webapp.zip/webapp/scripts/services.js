(function () {
    'use strict';

angular.module('BattleChasersWebApp').factory('DialogService', [ '$resource', function ($resource) {

    return $resource('rest/dialogs/:id', {}, {
        createDialog: { method: 'POST' },
        updateDialog: { method: 'PUT' },
        deleteDialog: { method: 'DELETE' },
        getDialog:    { method: 'GET' },
        getDialogs:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('BackgroundService', [ '$resource', function ($resource) {

    return $resource('rest/backgrounds/:id', {}, {
        createBackground: { method: 'POST' },
        updateBackground: { method: 'PUT' },
        deleteBackground: { method: 'DELETE' },
        getBackground:    { method: 'GET' },
        getBackgrounds:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('PositionService', [ '$resource', function ($resource) {

    return $resource('rest/positions/:id', {}, {
        createPosition: { method: 'POST' },
        updatePosition: { method: 'PUT' },
        deletePosition: { method: 'DELETE' },
        getPosition:    { method: 'GET' },
        getPositions:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('PlayerPositionService', [ '$resource', function ($resource) {

    return $resource('/players/{playerId}/position', {}, {
        updatePlayerPosition: { method: 'POST' },
        getPlayerPosition:    { method: 'GET' }
    });

}]);

angular.module('BattleChasersWebApp').factory('CanvasHeroService', [ '$resource', function ($resource) {

    return $resource('rest/canvass/:id/hero/:heroId', {}, {
        createCanvas: { method: 'POST' },
        updateCanvas: { method: 'PUT' },
        deleteCanvas: { method: 'DELETE' },
        getCanvas:    { method: 'GET' },
        getCanvass:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('CanvasService', [ '$resource', function ($resource) {

    return $resource('rest/canvass/:id', {}, {
        createCanvas: { method: 'POST' },
        updateCanvas: { method: 'PUT' },
        deleteCanvas: { method: 'DELETE' },
        getCanvas:    { method: 'GET' },
        getCanvass:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('SpriteService', [ '$resource', function ($resource) {

    return $resource('rest/sprites/:id', {}, {
        createSprite: { method: 'POST' },
        updateSprite: { method: 'PUT' },
        deleteSprite: { method: 'DELETE' },
        getSprite:    { method: 'GET' },
        getSprites:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('StoreService', [ '$resource', function ($resource) {

    return $resource('rest/stores/:id', {}, {
        createStore: { method: 'POST' },
        updateStore: { method: 'PUT' },
        deleteStore: { method: 'DELETE' },
        getStore:    { method: 'GET' },
        getStores:   { method: 'GET', timeout: 3000 }
    });

}]);   
    
angular.module('BattleChasersWebApp').factory('AttributeService', [ '$resource', function ($resource) {

    return $resource('rest/attributes/:id', {}, {
        createAttribute: { method: 'POST' },
        updateAttribute: { method: 'PUT' },
        deleteAttribute: { method: 'DELETE' },
        getAttribute:    { method: 'GET' },
        getAttributes:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('CardService', [ '$resource', function ($resource) {

    return $resource('rest/cards/:id', {}, {
        createCard: { method: 'POST' },
        updateCard: { method: 'PUT' },
        deleteCard: { method: 'DELETE' },
        getCard:    { method: 'GET' },
        getCards:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('CategoryService', [ '$resource', function ($resource) {

    return $resource('rest/categories/:id', {}, {
        createCategory: { method: 'POST' },
        updateCategory: { method: 'PUT' },
        deleteCategory: { method: 'DELETE' },
        getCategory:    { method: 'GET' },
        getCategoriess:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('DeckService', [ '$resource', function ($resource) {

    return $resource('rest/decks/:id', {}, {
        createDeck: { method: 'POST' },
        updateDeck: { method: 'PUT' },
        deleteDeck: { method: 'DELETE' },
        getDeck:    { method: 'GET' },
        getDecks:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('EventService', [ '$resource', function ($resource) {

    return $resource('rest/events/:id', {}, {
        createEvent: { method: 'POST' },
        updateEvent: { method: 'PUT' },
        deleteEvent: { method: 'DELETE' },
        getEvent:    { method: 'GET' },
        getEvents:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('EventTypeService', [ '$resource', function ($resource) {

    return $resource('rest/eventtypes/:id', {}, {
        createEventType: { method: 'POST' },
        updateEventType: { method: 'PUT' },
        deleteEventType: { method: 'DELETE' },
        getEventType:    { method: 'GET' },
        getEventTypes:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('GameService', [ '$resource', function ($resource) {

    return $resource('rest/games/:id', {}, {
        createGame: { method: 'POST' },
        updateGame: { method: 'PUT' },
        deleteGame: { method: 'DELETE' },
        getGame:    { method: 'GET' },
        getGames:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('HandService', [ '$resource', function ($resource) {

    return $resource('rest/hands/:id', {}, {
        createHand: { method: 'POST' },
        updateHand: { method: 'PUT' },
        deleteHand: { method: 'DELETE' },
        getHand:    { method: 'GET' },
        getHands:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('ImageService', [ '$resource', function ($resource) {

    return $resource('rest/images/:id', {}, {
        createImage: { method: 'POST' },
        updateImage: { method: 'PUT' },
        deleteImage: { method: 'DELETE' },
        getImage:    { method: 'GET' },
        getImages:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('OperationService', [ '$resource', function ($resource) {

    return $resource('rest/operations/:id', {}, {
        createOperation: { method: 'POST' },
        updateOperation: { method: 'PUT' },
        deleteOperation: { method: 'DELETE' },
        getOperation:    { method: 'GET' },
        getOperations:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('PlayerService', [ '$resource', function ($resource) {

    return $resource('rest/players/:id', {}, {
        createPlayer: { method: 'POST' },
        updatePlayer: { method: 'PUT' },
        deletePlayer: { method: 'DELETE' },
        getPlayer:    { method: 'GET' },
        getPlayers:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('RepeatTypeService', [ '$resource', function ($resource) {

    return $resource('rest/repeattypes/:id', {}, {
        createRepeatType: { method: 'POST' },
        updateRepeatType: { method: 'PUT' },
        deleteRepeatType: { method: 'DELETE' },
        getRepeatType:    { method: 'GET' },
        getRepeatypes:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('SettingService', [ '$resource', function ($resource) {

    return $resource('rest/settings/:id', {}, {
        createSetting: { method: 'POST' },
        updateSetting: { method: 'PUT' },
        deleteSetting: { method: 'DELETE' },
        getSetting:    { method: 'GET' },
        getSettings:   { method: 'GET', timeout: 3000 }
    });

}]);

angular.module('BattleChasersWebApp').factory('SystemUserService', [ '$resource', function ($resource) {

    return $resource('rest/systemusers/:id', {}, {
        createUser: { method: 'POST' },
        updateUser: { method: 'PUT' },
        deleteUser: { method: 'DELETE' },
        getUser:    { method: 'GET' },
        getUsers:   { method: 'GET', timeout: 3000 } 
    });

}]);

}());