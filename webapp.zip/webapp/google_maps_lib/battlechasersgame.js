//var global game variable once created
var battleChasersController = null;
var map = null;

//Game object
function BattleChasersGame(gameName, gameMode, gameMap, gameMapHeatMap, gameItems, gameStores, gameDialogs, gameBadGuys, gameHero, gameRows, saveHeroCallback, loadHeroCallback, saveSpriteCallBack) {
    this.saveSprite = saveSpriteCallBack;
	// game stuff
	this.saveHero = saveHeroCallback;
	this.loadHero = loadHeroCallback;
	
	//initialize the game
	this.gameName = gameName;
	this.gameMode = gameMode;
	this.gameMap = gameMap;
	this.gameMapHeatMap = gameMapHeatMap;
    this.gameRows = gameRows;
	this.gameItems = gameItems;
	this.gameStores = gameStores;
    this.gameBadGuys = gameBadGuys;
    this.gameHero = gameHero;
	this.gameDialogs = [];
	    
    // google map stuff
    this.userLocation          = null;
    this.radius                = 10;
    this.geoCoder              = new google.maps.Geocoder();
    this.markerCount           = 0;
    //this.markerMap             = [];
    this.infoWindowList        = [];
  
    this.mapStyler             = [
        {
            "elementType": "geometry",
            "stylers": [
                { 
                    "visibility": "on" 
                }
            ]
        }
    ];  
     
	this.initialize();
}

BattleChasersGame.prototype.initialize = function() {
	this.getUserLocation();
}

BattleChasersGame.prototype.initializeMap = function() { 

    var latitudeLongitude = ( (this.userLocation) ? new google.maps.LatLng(this.userLocation.coords.latitude, this.userLocation.coords.longitude) : new google.maps.LatLng(0, 0) );
    
    map = new google.maps.Map(
    		document.getElementById("map"), 
    		{           
	        center: latitudeLongitude,
	        minZoom: 1,
	        maxZoom: 20,
	        zoom: 10,
	        zoomControl: true,
	        mapTypeControl: true,
	        scaleControl: true,
	        streetViewControl: true,
	        rotateControl: true,
	        fullscreenControl: false
    		}
    	); 

}

BattleChasersGame.prototype.initializeView = function() { 
	this.infoWindowList = [];

    document.getElementById('map').className = 'canvas';
    var container = document.getElementById('chasers');
    container.innerHTML = "";    
    
    this.initializeMap();
    
    // create hero sprite
    this.hero = this.createHero(this.gameHero);
    	//setup new game
    	this.setupNewGame(true);
    // perform save check
    	this.saveCheck();
 
}

BattleChasersGame.prototype.getUserLocation = function() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(this.setUserLocation, this.setUserLocationError);
    } 
    else {
        document.getElementById('chasers').innerHTML = "The browser you are using does not support Geolocation. Update your browser and enable location services for the game to work. Thank you!";
    }
}

BattleChasersGame.prototype.setUserLocation = function(position) {
	battleChasersController.userLocation = position;
	battleChasersController.initializeView();
}    

BattleChasersGame.prototype.setUserLocationError = function(error) {
	this.initializeView();
    var container = document.getElementById('chasers');
    // if the user has not started interacting with the map display the location error message
    if (container.innerHTML == '') {
        switch(error.code) {
            case error.PERMISSION_DENIED:
                container.innerHTML = "Geolocation is supported by this browser; however, User denied the request for Geolocation."
                break;
            case error.POSITION_UNAVAILABLE:
                container.innerHTML = "Geolocation is supported by this browser; however, Location information is unavailable."
                break;
            case error.TIMEOUT:
                container.innerHTML = "Geolocation is supported by this browser; however, The request to get user location timed out."
                break;
            case error.UNKNOWN_ERROR:
                container.innerHTML = "Geolocation is supported by this browser; however, An unknown error occurred."
                break;
        }        
    }
}

BattleChasersGame.prototype.createLatLng = function ( latitude, longitude ) {
    return new google.maps.LatLng(latitude,longitude);
}

BattleChasersGame.prototype.getLat = function(latLong) {
    return latLong.lat();
}

BattleChasersGame.prototype.getLong = function(latLong) {
	return latLong.lng();        
}

BattleChasersGame.prototype.saveCheck = function() {
	this.ableToSave = false;
	if (typeof(Storage) !== "undefined") {
	    // Code for localStorage/sessionStorage.
		this.ableToSave = true;
	} else {
	    // Sorry! No Web Storage support..
	}	
}

BattleChasersGame.prototype.createHero = function(gameHero) {
    // create hero sprite
    var sprite = new Sprite(gameHero.source, gameHero.width, gameHero.height, gameHero.offsetX, gameHero.offsetY, gameHero.frames, gameHero.duration, gameHero.spriteType, gameHero.startPositionLatitude, gameHero.startPositionLongitude, gameHero.health, gameHero.experience, gameHero.level, gameHero.healthOverlayShown, gameHero.isGold, gameHero.gold, gameHero.name, gameHero.id, gameHero.totalExperience, map, false);
    sprite.inventory = this.createInventory(gameHero);
    return sprite;
}

BattleChasersGame.prototype.createInventory = function(gameHero) {
    // create hero sprite
    var inventory = null;
    if (gameHero.inventory != undefined) {
    		inventory = new Inventory(null, gameHero.inventory.id, gameHero.inventory.gold, gameHero.inventory.items);
    }
    else {
		inventory = new Inventory(null, 1, 0, []);
    }
    return inventory;
}

BattleChasersGame.prototype.draw = function(timeStamp) {
	//if game has started
	if (this.timer != undefined && !this.isGameOver()) {
		
		//increase run time
		Constants.runTime = Constants.runTime + 1;
		this.timer.update();	
		
     	//draw draw items, if any
		this.drawItems();
		//draw bad guys, if any
		this.drawBadguys();
		//draw stores, if any
		this.drawStores();
		//draw hero
		if (!this.isGameOver()) {	
			this.updateHero();
			this.drawHero();
		}
		// draw dialogs, if any
		this.drawDialogs();
		//draw Inventory Screen, if open
		this.drawInventoryScreen();
		
	}
}

BattleChasersGame.prototype.drawStores = function() {
	var stores = this.stores;
	if (stores != null && stores != undefined) {
		for (var i=0; i < stores.length; i++) {
			var store = stores[i];
			store.draw(this.convasContext);
		}
	}	
}

BattleChasersGame.prototype.drawInventoryScreen = function() {
	var dialogs = this.gameDialogs;
	if (dialogs != null && dialogs != undefined) {
		for (var i=0; i < dialogs.length; i++) {
			var dialog = dialogs[i];
			dialog.displayMessage();
			if (dialog.displayTime <= 0) {
				Constants.removeFromArray(dialog, this.gameDialogs[i]);
			}
		}
	}	
}

BattleChasersGame.prototype.drawDialogs = function() {
	var dialogs = this.gameDialogs;
	if (dialogs != null && dialogs != undefined) {
		for (var i=0; i < dialogs.length; i++) {
			var dialog = dialogs[i];
			dialog.displayMessage();
			if (dialog.displayTime <= 0) {
				Constants.removeFromArray(dialog, this.gameDialogs[i]);
			}
		}
	}	
}

BattleChasersGame.prototype.updateHero = function() {
	//update hero and fire ball, punch and kick position 
	this.calculateSpriteOffset(this.hero, this.hero.Speed.latitude, this.hero.Speed.longitude);
	this.calculateSpriteDirection(this.hero);
	this.caculateSpritePosition(this.hero);	
	this.caculateSpriteFireball(this.hero);
	this.caculateSpritePunch(this.hero);
	this.caculateSpriteKick(this.hero);
	this.caculateSpritePickupOrSearch(this.hero);
	this.caculateSpriteOpenStore(this.hero);
	this.caculateSpriteOpenInventory(this.hero);
	this.caculateSpritePuchase(this.hero);
	//this.saveHero();
}

BattleChasersGame.prototype.drawHero = function() {
	//draw fir eballs and hero
    this.drawSpriteFireBalls(this.hero);
	this.hero.animate(this.convasContext, this.timer);
	this.hero.draw(this.convasContext);
}

BattleChasersGame.prototype.drawBadguys = function() {
	//draw all the bad guys
	if ( this.badguys != null && this.badguys != undefined) {
		for (var b=0; b < this.badguys.length; b++) {
			var badguy = this.badguys[b];
			// if bad guy is not dead
			if (!badguy.dead) {
				// collision detection and hit 
				if (this.hero.health > 0) {
					if (badguy.collisionDection(this.hero.longitude, this.hero.latitude)) {
						this.hero.hit(badguy.damage);
						if (this.hero.health <= 0) {
							this.gameOver();
						}
					}
					// hero attacks bad guy ( via fire ball)
					var hitCount = this.hero.attack(badguy.longitude, badguy.latitude)
					if (hitCount > 0) {
						// hero hit the bad guy
						badguy.hit(hitCount * this.hero.damage);
						// if bad guy is now dead
						if (badguy.health <= 0) {
							this.setHeroExperience(badguy.experience);
							//save hero
							this.saveHero();
							
							badguy.dead = true;
							badguy.shown = false;
							Constants.removeFromArray(badguy, this.badguys); 
						}
					}
				}
				if (badguy.health > 0) {
					// calculate new position and draw
					badguy = this.caculateBadGuyPosition(badguy);			
					badguy.animate(this.convasContext, this.timer);
					badguy.draw(this.convasContext);	
					
					var newLatLng = new google.maps.LatLng(badguy.Position.latitude, badguy.Position.longitude);
					if (badguy.marker) {
						badguy.marker.setPosition(newLatLng);
						badguy.marker.setMap(map);
					}
					
				}
			}
		}
	}
}

BattleChasersGame.prototype.drawItems = function() {
	//draw all the items
	if (this.items != null && this.items != undefined) {
		for (var i=0; i < this.items.length; i++) {
			var item = this.items[i];
			item.animate(this.convasContext, this.timer);
			item.draw(this.convasContext);	
		}
	}
}

BattleChasersGame.prototype.setHeroExperience = function(experience) {
	this.hero.experience = this.hero.experience + experience;
	if (this.hero.experience > 100) {
		this.hero.level = this.hero.level + 1;
		this.hero.totalExperience = this.hero.totalExperience + this.hero.experience;
		this.hero.experience = 0;
	}	
}

BattleChasersGame.prototype.getColorAtPoint = function(context, x, y) {
	return context.getImageData(x, y, 1, 1).data;
}

BattleChasersGame.prototype.isValidPath = function(sprite, xOffset, yOffset) {
	/*
	var validFound     = false;
	// calculate the future postion of the sprite
	var futurePositionX = sprite.Position.x+xOffset;
	var futurePositionY = sprite.Position.y+yOffset;
	// get the future position point color
	//this is a costly call
	var pointColor = Constants.getColorAtPoint(this.heatMapCanvasContext, futurePositionX + Constants.spritePositionX, futurePositionY + Constants.spritePositionY);			

	document.getElementById('statusFutureRGB').innerHTML = "Future RGB: (" + pointColor[0] + " " + pointColor[1] +" "+ pointColor[2] + ")";	
	
	//if color is yellow - scene change moving down (row + 1) and in the grid and hero sprite
	if (pointColor[0] == 254 && pointColor[1] == 240 && pointColor[2] == 53 && Constants.mapCurrentRow+1 < this.gameRows.length && sprite.spriteType == 12) {
		// valid location to move to down
		Constants.mapCurrentRow = Constants.mapCurrentRow + 1;
		this.setupNewLevel();		
	}	
	//if color is green - scene change moving right (column + 1) and in the grid and hero sprite
	else if (pointColor[0] == 16 && pointColor[1] == 127 && pointColor[2] == 67 && Constants.mapCurrentColumn+1 < this.gameRows[Constants.mapCurrentRow].scenes.length && sprite.spriteType == 12) {
		// valid location to move to right
		Constants.mapCurrentColumn = Constants.mapCurrentColumn + 1;
		this.setupNewLevel();	
	}	
	//if color is purple - scene change moving up (row - 1) and in the grid and hero sprite
	else if (pointColor[0] == 127 && pointColor[1] == 37 && pointColor[2] == 251 && Constants.mapCurrentRow >= 0 && sprite.spriteType == 12) {
		// valid location to move to up
		Constants.mapCurrentRow = Constants.mapCurrentRow - 1;
		this.setupNewLevel();		
	}	
	//if color is orange - scene change moving left (column -1 )  and in the grid and hero sprite
	else if (pointColor[0] == 253 && pointColor[1] == 127 && pointColor[2] == 54 && Constants.mapCurrentColumn >= 0 && sprite.spriteType == 12) {
		// valid location to move to left
		Constants.mapCurrentColumn = Constants.mapCurrentColumn - 1;
		this.setupNewLevel();		
	}	
	//if color is red - can not move
	else if (pointColor[0] == 252 && pointColor[1] == 13 && pointColor[2] == 27) {
		validFound = false;
	}
	//if color is blue - can move
	else if (pointColor[0] == 11 && pointColor[1] == 36 && pointColor[2] == 251) {
		// valid location to move to
		validFound = true;
	}
	else if (pointColor[0] == 0 && pointColor[1] == 0 && pointColor[2] == 0) {
		// valid location to move to
		validFound = true;
	}
	else {
//		alert("strange color found: " + pointColor[0] + ",  " + pointColor[1] + ",  " + pointColor[2]);
	}
	
    	return validFound;
    	*/
	return true;
}

BattleChasersGame.prototype.calculateSpriteOffset = function(sprite, latitude, longitude) {
	if (latitude === 0 && longitude === 0) { // standing still
		sprite.setOffset(0, 128);
		sprite.setFrames(1);
		sprite.setDuration(0);
	} 
	else if (latitude > 0 && longitude === 0) { // East
		if (sprite.offsetY !== 192) {
			sprite.setOffset(0, 192);
			sprite.setFrames(6);
			sprite.setDuration(500);
		}
	} 
	else if (latitude < 0 && longitude === 0) { // West
		if (sprite.offsetY !== 224) {
			sprite.setOffset(0, 224);
			sprite.setFrames(6);
			sprite.setDuration(500);
		}
	} 
	else if (latitude === 0 && longitude > 0) { // South
		if (sprite.offsetY !== 128 || sprite.frames !== 4) {
			sprite.setOffset(0, 128);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (latitude === 0 && longitude < 0) { // North
		if (sprite.offsetY !== 160) {
			sprite.setOffset(0, 160);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (latitude > 0 && longitude < 0) { // North East
		if (sprite.offsetY !== 0) {
			sprite.setOffset(0, 0);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (latitude > 0 && longitude > 0) { // South East
		if (sprite.offsetY !== 32) {
			sprite.setOffset(0, 32);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (latitude < 0 && longitude < 0) { // North West
		if (sprite.offsetY !== 64) {
			sprite.setOffset(0, 64);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	} 
	else if (latitude < 0 && longitude > 0) { // South West
		if (sprite.offsetY !== 96) {
			sprite.setOffset(0, 96);
			sprite.setFrames(4);
			sprite.setDuration(500);
		}
	}
}

BattleChasersGame.prototype.calculateSpriteDirection = function(sprite) {
	
	// Calculate X speed
	if (Constants.inArray(Constants.Keys.RIGHT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.D, Constants.Keys.getDown)) {
		sprite.Speed.longitude += (sprite.Speed.longitude <= sprite.Speed.MAX) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.RIGHT;
	} 
	else if (Constants.inArray(Constants.Keys.LEFT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.A, Constants.Keys.getDown)) {
		sprite.Speed.longitude -= (sprite.Speed.longitude >= (sprite.Speed.MAX * -1)) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.LEFT;
	} 
	else if (sprite.Speed.longitude > 0) { // No right / left keys are being pressed
		sprite.Speed.longitude += sprite.Speed.FRICTION * -1;
		sprite.Speed.longitude = (sprite.Speed.longitude < 0) ? 0 : sprite.Speed.longitude;
	}
	else if (sprite.Speed.longitude < 0) {
		sprite.Speed.longitude += sprite.Speed.FRICTION;
		sprite.Speed.longitude = (sprite.Speed.longitude > 0) ? 0 : sprite.Speed.longitude;
	}

	// Calculate Y speed
	if (Constants.inArray(Constants.Keys.DOWN, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.S, Constants.Keys.getDown)) {
		sprite.Speed.latitude += (sprite.Speed.latitude <= sprite.Speed.MAX) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.DOWN;
	} 
	else if (Constants.inArray(Constants.Keys.UP, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.W, Constants.Keys.getDown)) {
		sprite.Speed.latitude -= (sprite.Speed.latitude >= (sprite.Speed.MAX * -1)) ? sprite.Speed.INCREASE : 0;
		sprite.direction = Constants.Direction.UP;
	} 
	else if (sprite.Speed.latitude > 0) { // No up / down keys are being pressed
		sprite.Speed.latitude += sprite.Speed.FRICTION * -1;
		sprite.Speed.latitude = (sprite.Speed.latitude < 0) ? 0 : sprite.Speed.latitude;
	} 
	else if (sprite.Speed.latitude < 0) {
		sprite.Speed.latitude += sprite.Speed.FRICTION;
		sprite.Speed.latitude = (sprite.Speed.latitude > 0) ? 0 : sprite.Speed.latitude;
	}
	
}

BattleChasersGame.prototype.caculateSpritePosition = function(sprite) {
	// need to add check for lat and long and see if the path is valid or if we need to move the view to recenter on the sprite
	// update sprite lat and lng
	if (sprite.latitude) {
		sprite.latitude -= (sprite.Speed.latitude/1000);
	} 
	if (sprite.longitude) {
		sprite.longitude += (sprite.Speed.longitude/1000);		
	}
	
	//this.saveSprite(sprite);
	/*
	this.SpriteService.updateSprite({id: sprite.id}, sprite).$promise.then(
        function (response) {
            if (response) {
                sprite = response;
                if (sprite.id != null) {
                		sprite = new Sprite(sprite.source, sprite.width, sprite.height, sprite.offsetX, sprite.offsetY, sprite.frames, sprite.duration, sprite.spriteType, sprite.startPositionLatitude, sprite.startPositionLongitude, sprite.health, sprite.experience, sprite.level, sprite.healthOverlayShown, sprite.isGold, sprite.gold, sprite.name, sprite.id, sprite.totalExperience, map, true);

                }
            }
        },
        function (status) {	
        		if (status) {
        			alert("Server Error: updating sprite. " + status); 
    			}
        	
        }
    );
	*/
	if (sprite.marker) {
		var newLatLng = new google.maps.LatLng(sprite.latitude, sprite.longitude);
		sprite.marker.setPosition(newLatLng);
		sprite.marker.setMap(map);
	}	
}

BattleChasersGame.prototype.caculateSpritePuchase = function(hero) {
	var stores = this.stores;
	if (stores != null && stores != undefined) {
		for (var i=0; i < stores.length; i++) {
			var store = stores[i];
			if (store.displayInventory) {
				//for all stores inventory 
				for (var i=0; i < store.inventory.inventory.length; i++) {
					var items = store.inventory.inventory[i];
					for (var c=0; c < items.length; c++) {
						var item = items[c];
						if (item.saleNumber && Constants.NumberKeyLookup[item.saleNumber] && Constants.inArray(Constants.NumberKeyLookup[item.saleNumber], Constants.Keys.getDown)) {
							Constants.removeFromArray(Constants.NumberKeyLookup[item.saleNumber], Constants.Keys.getDown);	
							store.customerBuysItem(hero, item);
							//save hero
							this.saveHero();
						}
					}
				}	
			}
		}
	}
}

BattleChasersGame.prototype.caculateSpriteOpenInventory = function(hero) {
	if (Constants.inArray(Constants.Keys.I, Constants.Keys.getDown)) {
		//draw Inventory Background Image
		this.convasContext.drawImage(this.inventoryBackgroundImage, 
     			0, 
	     		0,
				400,
				400, 
				100, 
				100, 
				400, 
				400);		
		
		//for all heros inventory 
		for (var i=0; i < this.hero.inventory.inventory.length; i++) {
			var items = this.hero.inventory.inventory[i];
			for (var c=0; c < items.length; c++) {
				var item = items[c];
				item.draw();
			}
		}
	}
}

BattleChasersGame.prototype.caculateSpriteOpenStore = function(hero) {
	if (Constants.inArray(Constants.Keys.T, Constants.Keys.getDown)) {
		var stores = this.stores;
		if (stores != null && stores != undefined) {
			for (var i=0; i < stores.length; i++) {
				var store = stores[i];
				if (store.collisionDection(this.longitude, this.hero.latitude)) {
					store.displayInventory = !store.displayInventory;
					Constants.removeFromArray(Constants.Keys.T, Constants.Keys.getDown);	
				}
			}
		}	
	}
}

BattleChasersGame.prototype.caculateSpritePickupOrSearch = function(hero) {
	if (Constants.inArray(Constants.Keys.F, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.P, Constants.Keys.getDown)) {
		for (var i=0; i < this.items.length; i++) {
			var item = this.items[i];
			if (item.collisionDection(this.hero.longitude, this.hero.latitude)) {
				if ( item.isGold == 1 ) {
					this.hero.inventory.addGold(item.inventory.gold);
					var scoreOverlay = new Dialog(this.convasContext, item.latitude, item.longitude, item.elevation, "You found " + item.inventory.gold + " gold pieces.", null);
					this.gameDialogs.push( scoreOverlay );
					scoreOverlay.displayMessage(map, item.marker);					
					//save hero
					this.saveHero();			
				}
				else {
					var itemTypeOverlay = new Dialog(this.convasContext, item.latitude, item.longitude, item.elevation, "You found a " + item.name + '.', null);
					this.gameDialogs.push( itemTypeOverlay );
					itemTypeOverlay.displayMessage(map, item.marker);
					if (item.spriteType == Constants.SpriteType.EasterEgg) {
						//save hero
						this.saveHero();
						this.gameWon();
					}
					else {
						this.hero.inventory.addInventoryItem(item);
					}

				}
				item.shown = false;
				
				Constants.removeFromArray(item, this.items);		
			}
		}
	}
}

BattleChasersGame.prototype.caculateSpriteFireball = function(sprite) {
	if (Constants.inArray(Constants.Keys.SHIFT, Constants.Keys.getDown) || Constants.inArray(Constants.Keys.SPACE, Constants.Keys.getDown)) {
		                              //     src                      w    h oX oY  f  d gameHero.spriteType, gameHero.startPositionX, gameHero.startPositionY, gameHero.health, gameHero.experience, gameHero.level, gameHero.healthOverlayShown, gameHero.isGold, gameHero.gold, gameHero.name, gameHero.id, gameHero.totalExperience, map, false);
		sprite.shootFireball( new Sprite('game_lib/img/fireball.png', 36, 36, 0, 0, 5, 0, 10, this.hero.latitude, this.hero.longitude, 1, 1, 1, false, false, 0, 'Fire Ball', 11, 0, map, false), this.hero.latitude, this.hero.longitude, this.hero.direction);

	}
}

BattleChasersGame.prototype.drawSpriteFireBalls = function(sprite) {
	if (sprite.fireballCount > 0) {
		for (var f = 0; f < sprite.fireballs.length; f++) {
			var fb = sprite.fireballs[f];
			if (fb) {
				if (this.getDistance(fb.latitude, fb.longitude, fb.startPositionLatitude, fb.startPositionLongitude) < 100) {
					if (fb.latitude) {
						sprite.latitude -= (sprite.Speed.latitude/1000);
					} 
					if (fb.longitude) {
						fb.longitude = ((fb.direction == Constants.Direction.LEFT) ? fb.longitude -= (fb.Speed.longitude/1000) : fb.longitude += (fb.Speed.longitude/1000));		
					}
					
					if (fb.marker) {
						var newLatLng = new google.maps.LatLng(fb.latitude, fb.longitude);
						fb.marker.setPosition(newLatLng);
						fb.marker.setMap(map);
					}	

				}
				else {
					Constants.removeFromArray(fb, sprite.fireballs);
					sprite.fireballCount = sprite.fireballCount - 1;
					sprite.magic = sprite.magic + 10;
				}
			}
		}
	}
}

BattleChasersGame.prototype.caculateSpriteKick = function(sprite) {
	if (sprite.action == Constants.Action.KICK && sprite.actionCount == 0) {
		sprite.action = Constants.Action.STANDING;
	}
	else if (Constants.inArray(Constants.Keys.K, Constants.Keys.getDown)) {
		if (sprite.direction == Constants.Direction.RIGHT) {
			sprite.setOffset(0, 256);
		}
		else if (sprite.direction == Constants.Direction.LEFT) {
			sprite.setOffset(0, 288);
		}
		sprite.setFrames(4);
		sprite.setDuration(500);
		sprite.action = Constants.Action.KICK;
		sprite.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (sprite.action == Constants.Action.KICK) {
		sprite.actionCount = sprite.actionCount - 1; 
	}	
}

BattleChasersGame.prototype.caculateSpritePunch = function(sprite) {
	if (sprite.action == Constants.Action.PUNCH && sprite.actionCount == 0) {
		sprite.action = Constants.Action.STANDING;
	}
	else if (Constants.inArray(Constants.Keys.P, Constants.Keys.getDown)) {
		if (sprite.direction == Constants.Direction.RIGHT) {
			sprite.setOffset(0, 320);
		}
		else if (sprite.direction == Constants.Direction.LEFT) {
			sprite.setOffset(0, 352);
		}
		sprite.setFrames(4);
		sprite.setDuration(500);
		sprite.action = Constants.Action.PUNCH;
		sprite.actionCount = 4; // number of Frames  (timeout for the action)
	}
	else if (sprite.action == Constants.Action.PUNCH) {
		sprite.actionCount = sprite.actionCount - 1; 
	}	
}

BattleChasersGame.prototype.getDistance = function(lat, long, compareLat, compareLong) {
    var d2r = 0.0174532925199433;
    var dlong = (compareLong - long) * d2r;
    var dlat = (compareLat - lat) * d2r;
    var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = 3956 * c; 
    return d;        
}

BattleChasersGame.prototype.getDistanceFromUser = function(compareLat, compareLong) {
    var d2r = 0.0174532925199433;
    var lat = this.hero.latitude;
    var lng = this.hero.longitude;
    var dlong = (compareLong - lng) * d2r;
    var dlat = (compareLat - lat) * d2r;
    var a = Math.pow(Math.sin(dlat/2.0), 2) + Math.cos(lat*d2r) * Math.cos(compareLat*d2r) * Math.pow(Math.sin(dlong/2.0), 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = 3956 * c; 
    return d;        
}

BattleChasersGame.prototype.caculateBadGuyPosition = function(badguy) {
    // line of sight? or maybe distance
	//var distance = this.getDistanceFromUser(badguy.latitude, badguy.longitude);

	// x y distance
    // var distance = Constants.pointDistance(badguy.Position.x, badguy.Position.y, this.hero.Position.x, this.hero.Position.y);
    //if (distance <= 200) {
//		var bX = badguy.longitude;
//		var bY = badguy.latitude;
//		var hX = this.hero.longitude;
//		var hY = this.hero.latitude;

		var bX = badguy.Position.longitude;
		var bY = badguy.Position.latitude;
		var hX = this.hero.Position.longitude;
		var hY = this.hero.Position.latitude;
			
		var futurePositionBX = 0;
		var futurePositionBY = 0;
		
		var changeFound = false;
		if (hX > bX && hY > bY) {
			futurePositionBX = +1;
			futurePositionBY = +1;
			changeFound = true;			
		}
		if (!changeFound && hX < bX && hY < bY) {
			futurePositionBX = -1;
			futurePositionBY = -1;
			changeFound = true;			
		}
		if (!changeFound && hX == bX && hY > bY) {
			futurePositionBX = 0;
			futurePositionBY = +1;
			changeFound = true;			
		}
		if (!changeFound && hX == bX && hY < bY) {	
			futurePositionBX = 0;
			futurePositionBY = -1;
			changeFound = true;			
		}	
		if (!changeFound && hX > bX && hY < bY) {
			futurePositionBX = +1;
			futurePositionBY = -1;
			changeFound = true;			
		}
		if (!changeFound && hX < bX && hY > bY) {
			futurePositionBX = -1;
			futurePositionBY = +1;
			changeFound = true;			
		}
		if (!changeFound && hX > bX && hY == bY) {
			futurePositionBX = +1;
			futurePositionBY = 0;
			changeFound = true;			
		}
		if (!changeFound && hX < bX && hY == bY) {
			futurePositionBX = -1;
			futurePositionBY = 0;
			changeFound = true;			
		}
		this.setBadguyPosition(badguy, (futurePositionBX/100), (futurePositionBY/100));
    //}
	return badguy;
}

BattleChasersGame.prototype.setBadguyPosition = function(badguy, latitude, longitude) {
	badguy.setPosition(badguy.Position.latitude + latitude, badguy.Position.longitude + longitude);	
}

BattleChasersGame.prototype.isGameOver = function() {
	// no badguys left
    if (this.badguys != undefined && this.badguys != null && this.badguys.length == 0 && this.gameMode == 'kill') {
    	   Constants.boardLevel = Constants.boardLevel + 1;
    	   this.setupNewLevel();
	}	
	return this.hero.dead;
}

BattleChasersGame.prototype.gameOver = function() {
	this.hero.dead = true;
	this.hero.shown = false;

	//invert background image color
	var imgData=this.convasContext.getImageData(0 ,0 ,Constants.canvasWidth ,Constants.canvasHeight);
	// invert colors
	for (var i=0;i<imgData.data.length;i+=4)
	  {
	  imgData.data[i]=255-imgData.data[i];
	  imgData.data[i+1]=255-imgData.data[i+1];
	  imgData.data[i+2]=255-imgData.data[i+2];
	  imgData.data[i+3]=255;
	  }
	this.convasContext.putImageData(imgData,0,0);
	
	alert("Game Over");	
}

BattleChasersGame.prototype.gameWon = function() {
	alert("You Win!!!");	
	// call window reload
	window.location.reload();
	
}

BattleChasersGame.prototype.saveGame = function() {
	//save the hero and bad guy states to be able to load a game
	if (this.ableToSave) {
		localStorage.setItem("heroId", this.hero.id);
		//localStorage.setItem("gameLastRunTime", Constants.lastRunTime);
		//localStorage.setItem("gameLastSecond", Constants.lastSecond);
		//localStorage.setItem("gameRunTime", Constants.runTime);
		localStorage.setItem("gameBoardLevel", Constants.boardLevel);
		localStorage.setItem("gameBoardRow", Constants.mapCurrentRow);
		localStorage.setItem("gameBoardColumn", Constants.mapCurrentColumn);
		alert("Game Saved.");
	}
	else {
		alert("Your browser does not support location storage. Update your browser.")
	}
}

BattleChasersGame.prototype.loadGame = function() {
	if (localStorage.getItem("gameBoardLevel")) {
		this.loadHero(parseInt(localStorage.getItem("heroId")));
		Constants.boardLevel = parseInt(localStorage.getItem("gameBoardLevel"));		
		Constants.mapCurrentRow = parseInt(localStorage.getItem("gameBoardRow"));		
		Constants.mapCurrentColumn = parseInt(localStorage.getItem("gameBoardColumn"));	
		alert("Game Loaded.");
	}
}

BattleChasersGame.prototype.setBadguys = function(badguys) {
    if (badguys) {
	    this.badguys = badguys;
		for (var g=0;g<badguys.length;g++) {
		    var gameBadGuy = badguys[g];
		    if (typeof gameBadGuy == "object" && Object.getPrototypeOf(gameBadGuy) !== Sprite.prototype ) {
		    		this.badguys[g] = new Sprite(gameBadGuy.source, gameBadGuy.width, gameBadGuy.height, gameBadGuy.offsetX, gameBadGuy.offsetY, gameBadGuy.frames, gameBadGuy.duration, gameBadGuy.spriteType, gameBadGuy.startPositionLatitude, gameBadGuy.startPositionLongitude, gameBadGuy.health, gameBadGuy.experience, gameBadGuy.level, gameBadGuy.healthOverlayShown, gameBadGuy.isGold, gameBadGuy.gold, gameBadGuy.name, gameBadGuy.id, gameBadGuy.totalExperience, map, true);
		    }		
		}
	}  	
}

BattleChasersGame.prototype.setItems = function(items) {
    if (items) {
	    this.items = items;
		for (var g=0;g<items.length;g++) {
		    var gameItem = items[g];
		    if (typeof gameItem == "object" && Object.getPrototypeOf(gameItem) !== Sprite.prototype ) {
		    		this.items[g] = new Sprite(gameItem.source, gameItem.width, gameItem.height, gameItem.offsetX, gameItem.offsetY, gameItem.frames, gameItem.duration, gameItem.spriteType, gameItem.startPositionLatitude, gameItem.startPositionLongitude, gameItem.health, gameItem.experience, gameItem.level, gameItem.healthOverlayShown, gameItem.isGold, gameItem.gold, gameItem.name, gameItem.id, gameItem.totalExperience, map, true); 
		    }		
		}
	}  	
}

BattleChasersGame.prototype.setStores = function(stores) {
    if (stores) {
	    this.stores = stores;
		for (var g=0;g<stores.length;g++) {
		    var gameStore = stores[g];
		    if (typeof gameStore == "object" && Object.getPrototypeOf(gameStore) !== Store.prototype ) {
		    		var inventory = new Inventory();
		    	    this.stores[g] = new Store(gameStore.source, gameStore.width, gameStore.height, gameStore.offsetX, gameStore.offsetY, gameStore.spriteType, gameStore.startPositionLatitude, gameStore.startPositionLongitude, gameStore.gold, gameStore.name, inventory, map, true);
		    }		
		}
	}  	
}

BattleChasersGame.prototype.resetGame = function() {
	for (var f = this.hero.fireballs.length-1; f >= 0; f--) {
		var fb = this.hero.fireballs[f];
		Constants.removeFromArray(fb, this.hero.fireballs);
	}

	for (var f = Constants.Keys.getDown.length-1; f >= 0; f--) {
		var kd = Constants.Keys.getDown[f];
		Constants.removeFromArray(kd, Constants.Keys.getDown);
	}	

	for (var f = this.gameDialogs.length-1; f >= 0 ; f--) {
		var kd = this.gameDialogs[f];
		Constants.removeFromArray(kd, this.gameDialogs);
	}	
	
	this.hero.Position.x = 400;
	this.hero.Position.y = 300;	
}

BattleChasersGame.prototype.intilizeCanvas = function() {
	this.setBadguys(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].badguys);
	this.setStores(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].stores);
	this.setItems(this.gameRows[Constants.mapCurrentRow].scenes[Constants.mapCurrentColumn].items);
}

BattleChasersGame.prototype.setupNewGame = function() {
	Constants.boardLevel = 1;
	Constants.runTime = 1;
	Constants.mapCurrentRow = 0;
	Constants.mapCurrentColumn = 0;
	this.intilizeCanvas();
	// setup game timer
	this.timer = new Timer();
}

BattleChasersGame.prototype.setupNewLevel = function() {
	this.resetGame();
	this.intilizeCanvas();
}

